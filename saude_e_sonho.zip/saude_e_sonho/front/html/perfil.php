<?php
session_start();
if (isset($_SESSION['email_paciente'])) {
  require '../../dashboard/assets/php/env.php';
  require '../../dashboard/assets/php/controllers/pacientes.php';
  require '../../dashboard/assets/php/controllers/produtos.php';
  $paciente->dadosPacientes($BD);
  $produto = $produtos->show($BD);
} else {
  header('location:./');
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <meta http-equiv="X-UA-Compatible" content="ie=edge">

  <meta name="copyright" content="MACode ID, https://macodeid.com/">

  <title>Perfil - Saude e sonho</title>

  <link rel="stylesheet" href="../assets/css/maicons.css">

  <link rel="stylesheet" href="../assets/css/bootstrap.css">

  <link rel="stylesheet" href="../assets/vendor/owl-carousel/css/owl.carousel.css">

  <link rel="stylesheet" href="../assets/vendor/animate/animate.css">

  <link rel="stylesheet" href="../assets/css/theme.css">

  <link href="../../dashboard/assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
</head>

<body class="bg-light">

  <!-- Back to top button -->
  <div class="back-to-top"></div>

  <header class="fixed-top w-100 bg-white">
    <div class="topbar">
      <div class="container">
        <div class="row">
          <div class="col-sm-8 text-sm">
            <div class="site-info">
              <a href="#"><span class="mai-call text-primary"></span> +244 900 000 000</a>
              <span class="divider">|</span>
              <a href="#"><span class="mai-mail text-primary"></span> mail@example.com</a>
            </div>
          </div>
          <div class="col-sm-4 text-right text-sm">
            <div class="social-mini-button">
              <a href="#"><span class="mai-logo-facebook-f"></span></a>
              <a href="#"><span class="mai-logo-twitter"></span></a>
              <a href="#"><span class="mai-logo-dribbble"></span></a>
              <a href="#"><span class="mai-logo-instagram"></span></a>
            </div>
          </div>
        </div> <!-- .row -->
      </div> <!-- .container -->
    </div> <!-- .topbar -->

    <nav class="navbar navbar-expand-lg navbar-light shadow-sm">
      <div class="container">
        <a class="navbar-brand" href="#"><span class="text-primary">Saúde </span>& Sonho</a>

        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupport" aria-controls="navbarSupport" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupport">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item">
              <a class="nav-link" href="index.php">Home</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="about.php">Sobre nós</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="doctors.php">Médicos</a>
            </li>
            <li class="nav-item active">
              <a class="nav-link" href="blog.php">Consultas</a>
            </li>

            <li class="nav-item">
              <a class="nav-link" href="contact.php">Contactos</a>
            </li>
            <li class="nav-item">

            <li class="nav-item">
              <?php

              if (isset($_SESSION['email_paciente'])) { ?>
                <div class=" ml-lg-3 rounded rounded-2">
                  <a href="./perfil.php" class="btn bg-dark text-white nav-link" style="border-radius: 50px !important;"> <?= explode(" ", $paciente->getNome())[0] ?></a>
                </div>
              <?php

              } else { ?>
                <a class="btn btn-primary ml-lg-3" href="../../dashboard/registro-pacientes.php">Login / Register</a>
              <?php
              }

              ?>
            </li>
          </ul>
        </div> <!-- .navbar-collapse -->
      </div> <!-- .container -->
    </nav>
  </header>
  <br><br><br>

  <!-- MAIN MENU -->
  <main class="container bg-white shadow mt-5">
    <div class="row">

      <div class="col-lg-3 shadow-sm alert-dark">
        <div class="alert mt-2 alert-light rounded-0">
          <button type="button" class="btn bg-transparent position-relative">
            Minhas consultas
            <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger text-light ctt"></span>
          </button>
        </div>

        <ul class="list-group list-group-flush">
          <li class="list-group-item">
            <a href="#" class="nav-link _0 bi-x-circle-fill" onclick="verConsultas(0, <?= $paciente->getId() ?>)" ondblclick="estado(0, <?= $paciente->getId() ?>)">
              <span class="ml-2">
                Canceladas
                <span class="badge bg-danger text-light float-right badge-pill cc"></span>
              </span>
            </a>
          </li>
          <li class="list-group-item">
            <a href="#" class="nav-link _1 bi-exclamation-circle-fill" onclick="verConsultas(1, <?= $paciente->getId() ?>)" ondblclick="estado(1, <?= $paciente->getId() ?>)">
              <span class="ml-2">
                Pendentes
                <span class="badge bg-danger text-light float-right badge-pill cp"></span>
              </span>
            </a>
          </li>
          <li class="list-group-item">
            <a href="#" class="nav-link _2 bi-calendar-check-fill" onclick="verConsultas(2, <?= $paciente->getId() ?>)" ondblclick="estado(2, <?= $paciente->getId() ?>)">
              <span class="ml-2">
                Agendadas
                <span class="badge bg-danger text-light float-right badge-pill ca"></span>
              </span>
            </a>
          </li>
          <li class="list-group-item">
            <a href="#" class="nav-link _3 bi-check-circle-fill" onclick="verConsultas(3, <?= $paciente->getId() ?>)" ondblclick="estado(3, <?= $paciente->getId() ?>)">
              <span class="ml-2">
                Marcadas
                <span class="badge bg-danger text-light float-right badge-pill cm"></span>
              </span>
            </a>
          </li>
          <li class="list-group-item">
            <a href="#" class="nav-link _4 bi-check2-all" onclick="verConsultas(4, <?= $paciente->getId() ?>)" ondblclick="estado(4, <?= $paciente->getId() ?>)">
              <span class="ml-2">
                Realizadas
                <span class="badge bg-danger text-light float-right badge-pill cr"></span>
              </span>
            </a>
          </li>
          <li class="list-group-item">
            <a href="#" class="nav-link _5 bi-card-checklist" onclick="verConsultas(5, <?= $paciente->getId() ?>)" ondblclick="estado(5, <?= $paciente->getId() ?>)">
              <span class="ml-2">
                Preescritas
                <span class="badge bg-danger text-light float-right badge-pill cs"></span>
              </span>
            </a>
          </li>
        </ul>
        <!--  <div class="alert mt-2 alert-danger rounded-0 sair">
          <h5 class="bi-door-open"> <span class="ml-2">Sair</span></h5>
        </div> -->
      </div>

      <!-- Coluna do meio -->
      <div class="col-lg-6">

        <!-- MENU NAVEGAÇÃO DOPERFIL -->
        <div class="card rounded-0 border-0 mt-2">
          <div class="card-header border-0">
            <div class="btn-group" role="group" aria-label="Basic example">
              <button type="button" class="btn btn-outline-primary btn-sm border-0 position-relative btn-carrinho">
                <span class="bi-cart-fill"></span>
                <span class="text-white position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger num-produto">
                </span>
              </button>
              <button type="button" class="btn btn-outline-primary btn-sm border-0 farmacia">
                <span class="bi-shop"></span>
                <span class="ml-2">Fármacia</span>
              </button>

              <button type="button" class="btn btn-outline-primary btn-sm border-0 dd">
                <span class="bi-person-fill"></span>
                <span class="ml-2">Meus dados</span>
              </button>

              <button type="button" class="btn alert-danger sair">
                <span class="bi-door-open"></span>
                <span class="ml-2">sair</span>
              </button>
            </div>
          </div>
        </div><!-- FIM MENU NAVEGAÇÃO DOPERFIL -->

        <!-- Exbir produtos no carrinho -->
        <div class="compras-carriinho ss" style="display:none; max-height:100%; height:420px;overflow:hidden; overflow-y:scroll">
          <div class="card mt-2">
            <div class="card-header bg-white">
              <h5 class="card-title">Produtos no carrinho</h5>
            </div>
            <div class="card-body">
              <?php
              try {
                $total = 0;
                $q = $BD->query(
                  "SELECT *FROM compras
                    INNER JOIN pacientes ON compras.id_cliente = pacientes.idpacientes
                    INNER JOIN produtos ON compras.id_produto = produtos.idproduto
                    WHERE id_cliente ='" . $paciente->getId() . "' AND estado_compra = '0' AND quantidade > 0"
                );
                $query =
                  "SELECT *FROM compras
                    INNER JOIN pacientes ON compras.id_cliente = pacientes.idpacientes
                    INNER JOIN produtos ON compras.id_produto = produtos.idproduto
                    WHERE id_cliente ='" . $paciente->getId() . "' AND estado_compra = '0' AND quantidade > 0";

                $executar = $BD->query($query)->fetchAll();
                if ($executar) {
                  foreach ($executar as $vendio) {
                    $total =  $BD->query("SELECT sum(total) as tt FROM compras WHERE id_cliente = '" . $paciente->getId() . "' AND estado_compra = '0' AND quantidade > 0")->fetch()->tt;
              ?>
                    <div class="alert alert-secondary shadow-sm rounded-0 shadow-sm">
                      <div class="float-right">
                        <a href="#!" class="btn-sm rounded-3" style="font-size: 25px; color: #000; font-weight:bold;" onclick="removeDoCarrinho(<?= $vendio->idcompra ?>)">
                          <b class="bi-patch-minus-fill"></b>
                        </a>
                      </div>
                      <span><?= $vendio->nome_produto ?> -- <b>(<?= $vendio->quantidade ?>)x </b> </span>
                      <br>
                      <small>
                        <b class="ms-2"><?= number_format($vendio->preco_produto, 0, ',', '.') ?> Kzs - Total: (<?= $vendio->total ?> kzs)</b>
                      </small>
                    </div>
              <?php
                    //break;
                  }
                }
                if ($q->rowCount() > 0) {
                  echo '<div class="text-right">
                      <span class="btn badge rounded-pill bg-dark text-white">Total geral: '  . number_format($total, 3, '.', ',') . ' kzs </span>
                     
                      <a href="#!" class="btn badge rounded-pill btn-success bi-check" onClick="enviarPedido(' . $paciente->getId() . ')"><span class="ml-2">enviar o pedido</span> </a>
                       </div>';
                }
              } catch (PDOException $th) {
                return $th->getMessage();
              }

              ?>

            </div>
          </div>
        </div><!-- FIM exibir produtos no carrinho -->

        <!-- EXIBIR PRODUTOS FARMÁCIA -->
        <div class="pro ss" style="max-height:100%; height:420px;overflow:hidden; overflow-y:scroll">
          <div class="bg-light">
            <div class="card-header bg-white">
              <div class="card-title">
                <h5 class="text-center wow fadeInUp">Produtos da farmácia </h5>
              </div>
            </div>

            <div class="row p-2">

              <?php
              foreach ($produto as $valor) { ?>
                <div class="col-lg-6 py-1 wow zoomIn">
                  <div class="card-blog h-100 shadow">
                    <div class="header">

                      <a href="blog-details.php" class="post-thumb">
                        <img src="../../dashboard/assets/img/produtos/<?= $valor->foto_produto ?>" alt="">
                      </a>
                    </div>
                    <div class="body">
                      <h5 class="post-title text-center"><?= $valor->nome_produto ?></h5>
                      <div class="text-center">
                        <a href="#!" class="badge bg-dark badge-pill text-white"><?= number_format($valor->preco_produto, 2, ",", ".") ?> Kzs</a>
                      </div>
                      <div class="site-info text-center">
                        <?= $valor->descricao ?>
                      </div>

                      <div class="form-group text-center mt-2 mb-2">
                        <a href="#" class="nav-item btn-md bg-dark text-white bi-dash rounded roundd-circle btn-menos" title="<?= $valor->idproduto ?>" name="<?= $paciente->getId() ?>"></a>
                        <input type="text" class="border-0 cqtd campo-qtd-<?= $valor->idproduto ?>" value="0" style="width: 25px; margin-left:4px;" disabled readonly>
                        <a href="#" class="nav-item btn-md bg-dark text-white bi-plus rounded roundd-circle btn-mais" title="<?= $valor->idproduto ?>" name="<?= $paciente->getId() ?>"></a>
                      </div>

                      <div class=" text-center">
                        <button class="d-none btn-sm btn-success btn-add-<?= $valor->idproduto ?> btn-adicionar-produto-<?= $valor->idproduto ?> ">
                          <i class=" bi-cart"></i>
                          Adicionar
                        </button>
                      </div>

                      <input type="hidden" class="id-cliente-<?= $valor->idproduto ?>">

                    </div>
                  </div>
                </div>
              <?php }
              ?>

            </div>
          </div>
        </div><!-- FIM EXIBIR PRODUTOS FARMACIA -->

        <!-- EXI^BIR CONSULTAS CONSULTAS -->
        <div class="consul ss" style="display:none; max-height:100%; height:420px;overflow:hidden; overflow-y:scroll">
          <!-- LISTA CONSULTAS -->
          <div class="card rounded-0 border-0 estados">

          </div>
          <!-- FIM LISTA CONSULTA -->
        </div><!-- FIM EXIBIR CONSULTAS -->

        <!-- EXIBIR COMPRAS EFETUADAS -->
        <div class="compras-efetuadas ss" style="display:none; max-height:100%; height:420px;overflow:hidden; overflow-y:scroll">
          <div class="card mt-2">
            <div class="card-header bg-white">
              <h5 class="card-title">Compras efetuadas</h5>
            </div>
            <div class="card-body compra-div">
              <div class="alert alert-success rounded-0 shadow-sm">
                teste
              </div>
            </div>
          </div>
        </div> <!-- FIM EXIBIR COMPRAS EFETUADAS -->

        <!-- EXIBIR DADOS DO PACIENTE -->
        <div class="dados ss" style="display:none;max-height:100%; height:400px;overflow:hidden; overflow-y:scroll">
          <div class="card rounder-0 mt-2">
            <div class="card-header bg-white">
              <div class="card-title">
                <h5>Meus Dados</h5>
              </div>
            </div>
            <div class="card-body">
              <form action="" method="post" class="form-edit-paciente">

                <div class="">
                  <label for="formGroupExampleInput" class="form-label">Nome</label>
                  <input type="text" name="nome" class="form-control rounded-0 border-0" id="formGroupExampleInput" required placeholder="<?= $paciente->getNome() ?>">
                </div>

                <div class="">
                  <label for="formGroupExampleInput2" class="form-label">Telefone</label>
                  <input type="text" name="telefone" class="form-control rounded-0 border-0" id="formGroupExampleInput2" required placeholder="<?= $paciente->getTelefone() ?>">
                </div>

                <div class="">
                  <label for="formGroupExampleInput3" class="form-label">E-mail</label>
                  <input type="text" name="email" class="form-control rounded-0 border-0" id="formGroupExampleInput3" required placeholder="<?= $paciente->getEmail() ?>">
                </div>

                <div class="">
                  <label for="formGroupExampleInput4" class="form-label">B.I</label>
                  <input type="text" name="bi" class="form-control rounded-0 border-0" id="formGroupExampleInput4" placeholder="<?= $paciente->getBI() ?>">
                </div>

                <div class="mt-2 mb-2 text-center ress"></div>

                <div class="form-group float-right">
                  <button type="submit" class="btn btn-success bi-pencil">
                    <span class="text-right">Confirmar</span>
                  </button>
                  <input type="hidden" name="acao" value="editar">
                  <input type="hidden" name="emaill" value="<?= $paciente->getEmail() ?>">
                </div>

              </form>

            </div>
            <br>
          </div>
        </div>
        <!-- FIM EXIBIR DADOSPACUENTE -->

      </div><!-- Fim coluna do meio -->

      <!-- Coluna da direita -->
      <div class="col-lg-3 shadow-sm alert-dark">

        <div class="alert mt-2 alert-light rounded-0">
          <button type="button" class="btn bg-transparent position-relative">
            Minhas compras
            <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger text-light">

            </span>
          </button>
        </div>
        <ul class="list-group list-group-flush">
          <?php
          $query = "SELECT data_venda, COUNT(data_venda) FROM compras WHERE estado_compra = '2' AND id_cliente = '" . $paciente->getId() . "' GROUP BY data_venda HAVING COUNT(data_venda)>0";
          $execute = $BD->query($query);
          while ($compra = $execute->fetch()) : ?>
            <li class="list-group-item">
              <a href="#" class="nav-link _4 bi-cash-stack mostar-compra-por-data d-<?= $compra->data_venda ?>" title="Compras de <?= $compra->data_venda ?>" name="<?= $compra->data_venda ?>" onmouseover="mostrarCompras(<?= $paciente->getId() ?>, '<?= $compra->data_venda ?>')">
                <span class=" ml-2"><?= $compra->data_venda ?></span>
              </a>
            </li>
          <?php endwhile; ?>
        </ul>

      </div><!-- fim coluna direita -->

    </div>

  </main>

  <br><br><br><br><br> <br><br><br><br><br>
  <!-- Button trigger modal -->
  <button type="button" class="btn bg-transparent modalC" data-toggle="modal" data-target="#exampleModal">
  </button>

  <!-- Modal -->
  <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-body">
          <div class="text-center">
            <div class="alert alert-light vv">
              <h1 class="bi-check-circle-fill text-success"></h1>
              <h5 class="text-success">Pedido enviado</h5>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <footer class="page-footer">
    <div class="container">
      <hr>
      <p id="copyright">Copyright &copy; <?= date('Y') ?> <a href=#/" target="_blank">Feito por Odeth Franco</a>. Todos direitos reservados</p>
    </div>
  </footer>


  <script src="../assets/js/jquery-3.5.1.min.js"></script>

  <script src="../assets/js/"></script>

  <script src="../assets/js/bootstrap.bundle.min.js"></script>

  <script src="../assets/vendor/owl-carousel/js/owl.carousel.min.js"></script>

  <script src="../assets/vendor/wow/wow.min.js"></script>

  <script src="../assets/js/theme.js"></script>

  <script>
    document.querySelector('.sair').addEventListener('click', () => {
      window.location.href = "sair.php"
    })

    // mostra as compras de acordoa data selecionada
    function passarDados(cliente, data_venda) {
      var dados = "";
      var comp_div = document.querySelector('.compra-div')
      // dados = `<div class="alert alert-success rounded-0 shadow-sm"> TESTADO DO JS ${cliente} ${data_venda}</div>`

      fetch(`.././../dashboard/assets/php/controllers/compras.php?acao=listar-vendidos&cliente=${cliente}&data=${data_venda}`)
        .then(res => res.text())
        .then((data) => {
          comp_div.innerHTML = data
        })
    }

    function mostrarCompras(cliente, data_venda) {

      passarDados(cliente, data_venda)

    }

    // Remove do carrinho
    function removeDoCarrinho(idCompra) {

      /*     var c = document.querySelectorAll(`.c-${idCompra}`)
          c.classList.add('d-none') */
      fetch(`../../dashboard/assets/php/controllers/compras.php?acao=menos-no-carrinho&idcompra=${idCompra}`)
        .then(res => res.text())
        .then((data) => {

          if (data == 200) {
            setTimeout(() => {
              window.location.reload()
            }, 1500);
          } else {
            alert(data)
          }
        })
    }

    // contar pendentes não vistos
    async function contarCacelados(idpaciente) {
      await fetch(`../../dashboard/assets/php/controllers/consultas.php?acao=cancelados-nao-lidos&idpaciente=${idpaciente}`)
        .then(response => response.text())
        .then((value) => {
          if (value != 0) {
            $('.cc').html(value)
          } else {
            $('.cc').html('')
          }
        })
    }
    // contar cancelados não vistos
    async function contarPendentes(idpaciente) {
      await fetch(`../../dashboard/assets/php/controllers/consultas.php?acao=pendentes-nao-lidos&idpaciente=${idpaciente}`)
        .then(response => response.text())
        .then((value) => {
          if (value != 0) {
            $('.cp').html(value)
          } else {
            $('.cp').html('')
          }
        })
    }
    // contar agendados não vistos
    async function contarAgendadas(idpaciente) {
      await fetch(`../../dashboard/assets/php/controllers/consultas.php?acao=agendadas-nao-lidos&idpaciente=${idpaciente}`)
        .then(response => response.text())
        .then((value) => {
          if (value != 0) {
            $('.ca').html(value)
          } else {
            $('.ca').html('')
          }
        })
    }
    // contar Marcadas não vistos
    async function contarMarcadas(idpaciente) {
      await fetch(`../../dashboard/assets/php/controllers/consultas.php?acao=marcadas-nao-lidos&idpaciente=${idpaciente}`)
        .then(response => response.text())
        .then((value) => {
          if (value != 0) {
            $('.cm').html(value)
          } else {
            $('.cm').html('')
          }
        })
    }
    // contar Realizados não vistos
    async function contarRealizadas(idpaciente) {
      await fetch(`../../dashboard/assets/php/controllers/consultas.php?acao=realizadas-nao-lidos&idpaciente=${idpaciente}`)
        .then(response => response.text())
        .then((value) => {
          if (value != 0) {
            $('.cr').html(value)
          } else {
            $('.cr').html('')
          }
        })
    }
    // contar Preescrito não vistos
    async function contarPreescritas(idpaciente) {
      await fetch(`../../dashboard/assets/php/controllers/consultas.php?acao=preescritas-nao-lidos&idpaciente=${idpaciente}`)
        .then(response => response.text())
        .then((value) => {
          if (value != 0) {
            $('.cs').html(value)
          } else {
            $('.cs').html('')
          }
        })
    }
    async function contarTodasConsutas(idpaciente) {
      await fetch(`../../dashboard/assets/php/controllers/consultas.php?acao=todas&idpaciente=${idpaciente}`)
        .then(response => response.text())
        .then((value) => {
          $('.ctt').html(value)
        })
    }
    async function verConsultas(estado, idpaciente) {
      await fetch(`../../dashboard/assets/php/controllers/consultas.php?acao=visualizar&idpaciente=${idpaciente}&estado=${estado}`)
    }

    var form_edit_paciente = document.querySelector('.form-edit-paciente')
    form_edit_paciente.addEventListener('submit', (e, dados) => {
      e.preventDefault()
      dados = new FormData(form_edit_paciente)
      fetch('../../dashboard/assets/php/controllers/pacientes.php', {
          method: 'POST',
          body: dados
        })
        .then(res => res.text())
        .then((value) => {
          if (value == 200) {
            $('.ress').html('<span class="text-success">Dados alterados</span>')
            alert('Dados alterados, por favor faça login novamente')
            window.location.href = "./sair.php"
          } else {
            $('.ress').html(`<span class="text-success">${value}</span>`)
          }
        })
    })

    setInterval(() => {
      contarMarcadas(<?= $paciente->getId() ?>)
      contarCacelados(<?= $paciente->getId() ?>)
      contarPendentes(<?= $paciente->getId() ?>)
      contarAgendadas(<?= $paciente->getId() ?>)
      contarRealizadas(<?= $paciente->getId() ?>)
      contarPreescritas(<?= $paciente->getId() ?>)
      contarTodasConsutas(<?= $paciente->getId() ?>)
    }, 2000);

    function estado(estado, idpaciente) {
      fetch(`../../dashboard/assets/php/controllers/consultas.php?acao=estados&idpaciente=${idpaciente}&estado=${estado}`)
        .then(res => res.text())
        .then((value) => {
          /* alert(value) */
          if (value == 200) {
            $('.estados').html(value)
          } else {
            $('.estados').html(`<span class="text-danger">${value}</span>`)
          }
        })
    }
    /*  $('.modalC').click() */
    async function enviarPedido(id) {
      fetch(`../../dashboard/assets/php/controllers/compras.php?acao=enviar-pedido&idpaciente=${id}`)
        .then(res => res.text())
        .then((value) => {
          if (value == 200) {

            $('.modalC').click()
            setTimeout(() => {
              window.location.reload()
            }, 5000);
          } else {
            $('.modalC').click()
            $('.vv').html('<span class="text-danger">' + value + '</span>')
          }
        })

    }
  </script>

  <input type="hidden" class="cli" value="<?= $paciente->getId() ?>">

  <script>
    $(document).ready(function() {
      var link_1, link_2, link_3, link_4, link_5, link_0;
      var div_1, div_2, div_3, div_4, div_5, div_5, div_0;
      var card_consultas = $('.card-consultas')
      var pro = $('.pro')
      var consul = $('.consul')
      var farmacia = $('.farmacia')
      var data_compra = $('.mostar-compra-por-data')
      var div_compras = $('.compras-efetuadas')
      var btn_carrinho = $('.btn-carrinho')
      var produtos_carrinho = $('.compras-carriinho')
      var dados = $('.dados')
      var dd = $('.dd')

      link_0 = $('._0')
      link_1 = $('._1')
      link_2 = $('._2')
      link_3 = $('._3')
      link_4 = $('._4')
      link_5 = $('._5')

      div_1 = $('.consulta-1').fadeOut('fast')
      div_2 = $('.consulta-2').fadeOut('fast')
      div_3 = $('.consulta-3').fadeOut('fast')
      div_4 = $('.consulta-4').fadeOut('fast')
      div_5 = $('.consulta-5').fadeOut('fast')
      div_0 = $('.consulta-0').fadeOut('fast')

      dd.click(function() {
        card_consultas.fadeIn('fast')
        div_0.fadeIn('fast');
        div_1.fadeOut('fast')
        div_2.fadeOut('fast')
        div_3.fadeOut('fast')
        div_4.fadeOut('fast')
        div_5.fadeOut('fast')
        pro.fadeOut('fast')
        consul.fadeOut('fast')
        div_compras.fadeOut('fast')
        dados.fadeIn('fast')
        produtos_carrinho.fadeOut('fast')
      })


      btn_carrinho.click(function() {
        card_consultas.fadeOut('fast')
        div_1.fadeOut('fast')
        div_2.fadeOut('fast')
        div_3.fadeOut('fast')
        div_4.fadeOut('fast')
        div_5.fadeOut('fast')
        div_0.fadeOut('fast')
        consul.fadeOut('fast')
        pro.fadeOut('fast')
        div_compras.fadeOut('fast')
        dados.fadeOut('fast')
        produtos_carrinho.fadeIn('fast')
      })

      data_compra.hover(function() {
        card_consultas.fadeOut('fast')
        produtos_carrinho.fadeOut('fast')
        div_1.fadeOut('fast')
        div_2.fadeOut('fast')
        div_3.fadeOut('fast')
        div_4.fadeOut('fast')
        div_5.fadeOut('fast')
        div_0.fadeOut('fast')
        var data_venda = $(this).attr('name')
        d = $('.d-' + data_venda)
        d.click(function() {
          consul.fadeOut('fast')
          pro.fadeOut('fast')
          div_compras.fadeIn()
        })

      })

      farmacia.click(function() {
        pro.fadeIn('fast')
        consul.fadeOut('fast')
        div_compras.fadeOut('fast')
        dados.fadeOut('fast')
        produtos_carrinho.fadeOut('fast')
      })

      link_0.click(function() {
        card_consultas.fadeIn('fast')
        div_0.fadeIn('fast');

        div_1.fadeOut('fast')
        div_2.fadeOut('fast')
        div_3.fadeOut('fast')
        div_4.fadeOut('fast')
        div_5.fadeOut('fast')
        pro.fadeOut('fast')
        consul.fadeIn('fast')
        div_compras.fadeOut('fast')
        dados.fadeOut('fast')
        produtos_carrinho.fadeOut('fast')

      })

      link_1.click(function() {
        card_consultas.fadeIn('fast')
        div_1.fadeIn('fast');

        div_0.fadeOut('fast')
        div_2.fadeOut('fast')
        div_3.fadeOut('fast')
        div_4.fadeOut('fast')
        div_5.fadeOut('fast')
        pro.fadeOut('fast')
        consul.fadeIn('fast')
        div_compras.fadeOut('fast')
        dados.fadeOut('fast')
        produtos_carrinho.fadeOut('fast')
      })

      link_2.click(function() {
        card_consultas.fadeIn('fast')
        div_2.fadeIn('fast');

        div_0.fadeOut('fast')
        div_1.fadeOut('fast')
        div_3 = $('.consulta-3').fadeOut('fast')
        div_4 = $('.consulta-4').fadeOut('fast')
        div_5 = $('.consulta-5').fadeOut('fast')
      })

      link_3.click(function() {
        card_consultas.fadeIn('fast')
        div_3.fadeIn('fast');

        div_0.fadeOut('fast')
        div_1.fadeOut('fast')
        div_2.fadeOut('fast')
        div_4.fadeOut('fast')
        div_5.fadeOut('fast')
        pro.fadeOut('fast')
        consul.fadeIn('fast')
        div_compras.fadeOut('fast')
        dados.fadeOut('fast')
        produtos_carrinho.fadeOut('fast')
      })

      link_4.click(function() {
        card_consultas.fadeIn('fast')
        div_4.fadeIn('fast');

        div_0.fadeOut('fast')
        div_1.fadeOut('fast')
        div_2.fadeOut('fast')
        div_3.fadeOut('fast')
        div_5.fadeOut('fast')
        pro.fadeOut('fast')
        consul.fadeIn('fast')
        div_compras.fadeOut('fast')
        dados.fadeOut('fast')
        produtos_carrinho.fadeOut('fast')
      })

      link_5.click(function() {
        card_consultas.fadeIn('fast')
        div_5.fadeIn('fast');

        div_0.fadeOut('fast')
        div_1.fadeOut('fast')
        div_2.fadeOut('fast')
        div_3.fadeOut('fast')
        div_4.fadeOut('fast')
        pro.fadeOut('fast')
        consul.fadeIn('fast')
        div_compras.fadeOut('fast')
        dados.fadeOut('fast')
        produtos_carrinho.fadeOut('fast')
      })


      /* ========================================= */
      /* ============== LOJA ==================== */

      var btn_menos = $('.btn-menos')
      var btn_mais = $('.btn-mais')
      var campo_qtd
      var qtd, id;
      var btn

      // adiciona no carsrinho
      function addCarrinho(acao, idcliente, idProduto, qtdProduto) {
        $.ajax({
          url: '../../dashboard/assets/php/controllers/produtos.php',
          method: 'POST',
          data: {
            produto: idProduto,
            cliente: idcliente,
            quantidade: qtd,
            acao: acao
          },
          success: (data) => {
            if (data == 200) {

            }
          }
        })
      }

      // acoes nos botoes

      btn_mais.click(function() {

        id = $(this).attr('title')

        var botao_add = $('.btn-adicionar-produto-' + id)

        campo_qtd = $('.campo-qtd-' + id)

        btn = $('.btn-add-' + id)

        qtd = parseInt(campo_qtd.val()) + 1

        /*  btn.removeClass('d-none')
         btn.addClass('d-inline') */

        if (qtd >= 11) {

          campo_qtd.val(qtd - 1)


        } else {

          campo_qtd.val(qtd)

          if (qtd <= 0) {

            /* btn.removeClass('d-inline')
            btn.addClass('d-none') */

          }
          var idcliente = $(this).attr('name')
          var idProduto = id
          addCarrinho("plus", idcliente, idProduto, qtd)

        }


      })



      btn_menos.click(function() {

        id = $(this).attr('title')


        var botao_add = $('.btn-adicionar-produto-' + id)

        campo_qtd = $('.campo-qtd-' + id)

        qtd = parseInt(campo_qtd.val()) - 1


        btn = $('.btn-add-' + id)

        if (qtd <= 0) {

          /*  btn.removeClass('d-inline')
           btn.addClass('d-none') */
          campo_qtd.val(-1)

          var idcliente = $(this).attr('name')
          var idProduto = id
          addCarrinho("minus", idcliente, idProduto, qtd)

        } else {

          /* btn.removeClass('d-none')
          btn.addClass('d-inline') */

          campo_qtd.val(qtd)

          var idcliente = $(this).attr('name')
          var idProduto = id
          addCarrinho("minus", idcliente, idProduto, qtd)

        }

      })


      /* ===== conta produtos no carrinho ==================== */

      setInterval(() => {
        var cliente = $('.cli').val();

        $.ajax({
          url: '../../dashboard/assets/php/controllers/compras.php?acao=count&idcliente=' + cliente,
          success: (data) => {
            $('.num-produto').html(data)
          }
        })
      }, 2000);

    })
  </script>

</body>

</html>