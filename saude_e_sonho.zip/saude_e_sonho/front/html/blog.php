<?php
session_start();
if (isset($_SESSION['email_paciente'])) {
  require '../../dashboard/assets/php/env.php';
  require '../../dashboard/assets/php/controllers/pacientes.php';
  $paciente->dadosPacientes($BD);
} else {
  header('location:../../dashboard/login-pacientes.php');
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <meta http-equiv="X-UA-Compatible" content="ie=edge">

  <meta name="copyright" content="MACode ID, https://macodeid.com/">

  <title>Macação de Consulta - Saude e sonho</title>

  <link rel="stylesheet" href="../assets/css/maicons.css">

  <link rel="stylesheet" href="../assets/css/bootstrap.css">

  <link rel="stylesheet" href="../assets/vendor/owl-carousel/css/owl.carousel.css">

  <link rel="stylesheet" href="../assets/vendor/animate/animate.css">

  <link rel="stylesheet" href="../assets/css/theme.css">
</head>

<body>

  <!-- Back to top button -->
  <div class="back-to-top"></div>
  <header class="fixed-top w-100 bg-white">
    <div class="topbar">
      <div class="container">
        <div class="row">
          <div class="col-sm-8 text-sm">
            <div class="site-info">
              <a href="#"><span class="mai-call text-primary"></span> +244 900 000 000</a>
              <span class="divider">|</span>
              <a href="#"><span class="mai-mail text-primary"></span> mail@example.com</a>
            </div>
          </div>
          <div class="col-sm-4 text-right text-sm">
            <div class="social-mini-button">
              <a href="#"><span class="mai-logo-facebook-f"></span></a>
              <a href="#"><span class="mai-logo-twitter"></span></a>
              <a href="#"><span class="mai-logo-dribbble"></span></a>
              <a href="#"><span class="mai-logo-instagram"></span></a>
            </div>
          </div>
        </div> <!-- .row -->
      </div> <!-- .container -->
    </div> <!-- .topbar -->

    <nav class="navbar navbar-expand-lg navbar-light shadow-sm">
      <div class="container">
        <a class="navbar-brand" href="#"><span class="text-primary">Saúde </span>& Sonho</a>

        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupport" aria-controls="navbarSupport" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupport">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item">
              <a class="nav-link" href="index.php">Home</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="about.php">Sobre nós</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="doctors.php">Médicos</a>
            </li>
            <li class="nav-item active">
              <a class="nav-link" href="blog.php">Consultas</a>
            </li>

            <li class="nav-item">
              <a class="nav-link" href="contact.php">Contactos</a>
            </li>
            <li class="nav-item">

            <li class="nav-item">
              <?php

              if (isset($_SESSION['email_paciente'])) { ?>
                <div class=" ml-lg-3 rounded rounded-2">
                  <a href="./perfil.php" class="btn bg-dark text-white nav-link" style="border-radius: 50px !important;"> <?= explode(" ", $paciente->getNome())[0] ?></a>
                </div>
              <?php

              } else { ?>
                <a class="btn btn-primary ml-lg-3" href="../../dashboard/registro-pacientes.php">Login / Register</a>
              <?php
              }

              ?>
            </li>
          </ul>
        </div> <!-- .navbar-collapse -->
      </div> <!-- .container -->
    </nav>
  </header>

  <div class="page-banner overlay-dark bg-image" style="background-image: url(../assets/img/bg_image_1.jpg);">
    <div class="banner-section">
      <div class="container text-center wow fadeInUp">
        <nav aria-label="Breadcrumb">
          <ol class="breadcrumb breadcrumb-dark bg-transparent justify-content-center py-0 mb-2">
            <li class="breadcrumb-item"><a href="index.php">Home</a></li>
            <li class="breadcrumb-item active" aria-current="page">Consultas</li>
          </ol>
        </nav>
        <h1 class="font-weight-normal">Marque</h1>
      </div> <!-- .container -->
    </div> <!-- .banner-section -->
  </div> <!-- .page-banner -->

  <div class="page-section">
    <div class="container">
      <h1 class="text-center wow fadeInUp">Marcação de consulta</h1>
      <?= $paciente->dadosPacientes($BD) ?>
      <form class="main-form form-consulta">
        <div class="alert alert-success">
          Após preencher os dados correctamente, deverá aguardar e receber um e-mail com e-mail fornecedido,
          ou ainda um SMS apartir do terminal telefónico fornecido. Contendo informações acerca da sua solicitação de consulta.
          Por isso fica atento a sua caixa de entreda de ou caixa de spam do seu email.
        </div>
        <div class="row mt-5 ">
          <div class="col-12 col-sm-6 py-2 wow fadeInLeft">
            <input type="text" class="form-control" placeholder="<?= $paciente->getNome() ?>" required readonly disabled>
            <input type="hidden" value="<?= $paciente->getId() ?>" name="nome">
          </div>
          <div class="col-12 col-sm-6 py-2 wow fadeInRight">
            <input type="text" class="form-control" placeholder="<?= $paciente->getEmail() ?>" required disabled readonly>
          </div>
          <div class="col-12 col-sm-6 py-2 wow fadeInLeft" data-wow-delay="300ms">
            <select name="clinica" class="custom-select">
              <option selected>Clínica</option>
              <?php

              $l = $BD->query("SELECT *FROM clinicas ORDER BY designacao_clinica");
              while ($local = $l->fetch()) {
                echo '<option value="' . $local->idclinicas . '">' . $local->designacao_clinica
                  . '</option>';
              }
              ?>
            </select>
          </div>
          <div class="col-12 col-sm-6 py-2 wow fadeInRight" data-wow-delay="300ms">
            <select name="area" class="custom-select">
              <option selected disabled readonly>Área</option>
              <?php

              $l = $BD->query("SELECT *FROM especialidades ORDER BY designacao_especialidade");
              while ($local = $l->fetch()) {
                echo '<option value="' . $local->idespecialidades . '">' . $local->designacao_especialidade
                  . '</option>';
              }
              ?>
            </select>
          </div>
          <div class="col-6 py-2 wow fadeInUp" data-wow-delay="300ms">
            <input type="tel" class="form-control" placeholder="<?= $paciente->getTelefone() ?>" required disabled readonly>
          </div>
          <div class="col-6 py-2 wow fadeInUp" data-wow-delay="300ms">
            <input type="text" class="form-control" name="endereco" placeholder="Seu endereço" required>
          </div>
          <div class="col-12 py-2 wow fadeInUp" data-wow-delay="300ms">
            <textarea name="motivo" id="message" class="form-control" rows="3" placeholder="Descreva o motivo da consulta"></textarea>
          </div>
        </div>
        <div class="text-center mt-4 resposta"></div>
        <div class="text-center">
          <input type="hidden" name="acao" value="save">
          <button type="submit" class="btn btn-primary mt-3 wow zoomIn">Solicitar a consulta</button>
        </div>

      </form>
    </div>
  </div> <!-- .page-section -->

  <div class="page-section banner-home bg-image" style="background-image: url(../assets/img/banner-pattern.svg);">
    <div class="container py-5 py-lg-0">
      <div class="row align-items-center">
        <div class="col-lg-4 wow zoomIn">
          <div class="img-banner d-none d-lg-block">
            <img src="../assets/img/mobile_app.png" alt="">
          </div>
        </div>
        <div class="col-lg-8 wow fadeInRight">
          <h1 class="font-weight-normal mb-3">Baixe o nosso aplicativo para uma melhor interação</h1>
          <a href="#"><img src="../assets/img/google_play.svg" alt=""></a>
          <a href="#" class="ml-2"><img src="../assets/img/app_store.svg" alt=""></a>
        </div>
      </div>
    </div>
  </div> <!-- .banner-home -->

  <div class="maps-container wow fadeInUp">
    <div id="google-maps"></div>
  </div>



  <footer class="page-footer">
    <div class="container">
      <hr>
      <p id="copyright">Copyright &copy; <?= date('Y') ?> <a href=#/" target="_blank">Feito por Odeth Franco</a>. Todos direitos reservados</p>
    </div>
  </footer>

  <script>
    var form_consulta = document.querySelector('.form-consulta')
    var resposta = document.querySelector('.resposta')
    form_consulta.addEventListener('submit', (e, dados) => {
      dados = new FormData(form_consulta)
      e.preventDefault()
      fetch('../../dashboard/assets/php/controllers/consultas.php', {
          method: 'POST',
          body: dados
        })
        .then(res => res.text())
        .then(data => {
          if (data == 200) {
            resposta.innerHTML = '<div class="alert alert-success"><b>Consulta solicitada, receberá em breve um e-mail. Obrigado.</b></div>';
            form_consulta.reset()
          } else {
            resposta.innerHTML = '<div class="alert alert-danger"><b>' + data + '</b></div>';
          }
        })
    })
  </script>

  <script src="../assets/js/jquery-3.5.1.min.js"></script>

  <script src="../assets/js/"></script>

  <script src="../assets/js/bootstrap.bundle.min.js"></script>

  <script src="../assets/vendor/owl-carousel/js/owl.carousel.min.js"></script>

  <script src="../assets/vendor/wow/wow.min.js"></script>

  <script src="../assets/js/theme.js"></script>

<!--   <script>
    document.querySelector('.sair').addEventListener('click', () => {
      window.location.href = "sair.php"
    })
  </script> -->

</body>

</html>