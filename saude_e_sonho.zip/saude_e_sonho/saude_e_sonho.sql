-- phpMyAdmin SQL Dump
-- version 5.1.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 06-Out-2022 às 19:09
-- Versão do servidor: 10.4.24-MariaDB
-- versão do PHP: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `saude_e_sonho`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `categoria_funcionarios`
--

CREATE TABLE `categoria_funcionarios` (
  `idcategoria_funcionarios` int(11) NOT NULL,
  `designacao_categoria` varchar(45) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Extraindo dados da tabela `categoria_funcionarios`
--

INSERT INTO `categoria_funcionarios` (`idcategoria_funcionarios`, `designacao_categoria`) VALUES
(1, 'Médico'),
(2, 'Secretaria'),
(3, 'Admnistrador');

-- --------------------------------------------------------

--
-- Estrutura da tabela `certificacoes`
--

CREATE TABLE `certificacoes` (
  `idcertificacoes` int(11) NOT NULL,
  `tipo_certificacso` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `designacao_certificacao` varchar(45) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Extraindo dados da tabela `certificacoes`
--

INSERT INTO `certificacoes` (`idcertificacoes`, `tipo_certificacso`, `designacao_certificacao`) VALUES
(1, '', 'Medicina dentária'),
(3, '', 'Psicoteria'),
(6, '', 'viva');

-- --------------------------------------------------------

--
-- Estrutura da tabela `clinicas`
--

CREATE TABLE `clinicas` (
  `idclinicas` int(11) NOT NULL,
  `designacao_clinica` varchar(45) NOT NULL,
  `id_localidade` varchar(45) NOT NULL,
  `NIF` varchar(45) NOT NULL,
  `email_clinica` varchar(45) NOT NULL,
  `telefone_clinica` varchar(45) NOT NULL,
  `id_especialidade` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `clinicas`
--

INSERT INTO `clinicas` (`idclinicas`, `designacao_clinica`, `id_localidade`, `NIF`, `email_clinica`, `telefone_clinica`, `id_especialidade`) VALUES
(1, 'Saude e sonho', 'Luanda Angola.', '000025LA000', 'saude@yahoo.com', '942481988', 1),
(2, 'Saúde-camama', 'Talatona, bairro camama.', '000025LA000', 'saude-camama@gmail.com', '931312217', 2),
(3, 'clínica girassol', 'Chimbicato camama', '0004557hh142', 'girassol@gmail.com', '930303030', 4),
(4, 'Endiama', 'Alvalade', '0004557hh142', 'endiama@gmail.com', '930303030', 1),
(5, 'Júlio Keta', 'Murro Bento', '000025LA000', 'julio@outlook.com', '920000004', 4);

-- --------------------------------------------------------

--
-- Estrutura da tabela `compras`
--

CREATE TABLE `compras` (
  `idcompra` int(11) NOT NULL,
  `id_cliente` int(11) NOT NULL,
  `id_produto` int(11) NOT NULL,
  `quantidade` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `local_entrega` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `estado_compra` enum('0','1','2') COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `data_compra` date NOT NULL,
  `data_venda` date NOT NULL,
  `preco` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `total` varchar(200) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Extraindo dados da tabela `compras`
--

INSERT INTO `compras` (`idcompra`, `id_cliente`, `id_produto`, `quantidade`, `local_entrega`, `estado_compra`, `data_compra`, `data_venda`, `preco`, `total`) VALUES
(17, 1, 7, '6', 'Local fictício', '2', '2022-09-17', '2022-09-17', '3500', '21.000,00'),
(18, 1, 7, '6', 'Local fictício', '1', '2022-09-17', '0000-00-00', '3500', '21.000,00'),
(19, 1, 11, '9', 'Local fictício', '1', '2022-09-17', '0000-00-00', '1500', '13.500,00'),
(20, 1, 11, '9', 'Local fictício', '1', '2022-09-17', '0000-00-00', '1500', '13.500,00'),
(21, 1, 7, '6', 'Local fictício', '1', '2022-09-17', '0000-00-00', '3500', '21.000,00'),
(22, 1, 11, '9', 'Local fictício', '1', '2022-09-17', '0000-00-00', '1500', '13.500,00'),
(23, 1, 11, '9', 'Local fictício', '1', '2022-09-17', '0000-00-00', '1500', '13.500,00'),
(24, 1, 7, '6', 'Local fictício', '1', '2022-09-17', '0000-00-00', '3500', '21.000,00'),
(25, 1, 11, '9', 'Local fictício', '1', '2022-09-17', '0000-00-00', '1500', '13.500,00'),
(26, 1, 11, '1', 'Local fictício', '1', '2022-09-17', '0000-00-00', '1500', '1.500,00'),
(27, 1, 7, '6', 'Local fictício', '2', '2022-09-17', '2022-09-17', '3500', '21.000,00'),
(28, 1, 11, '1', 'Local fictício', '1', '2022-09-17', '0000-00-00', '1500', '1.500,00');

-- --------------------------------------------------------

--
-- Estrutura da tabela `conta_funcionario`
--

CREATE TABLE `conta_funcionario` (
  `idconta_funcionario` int(11) NOT NULL,
  `id_funcionario` int(11) DEFAULT NULL,
  `email` varchar(455) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura da tabela `especialidades`
--

CREATE TABLE `especialidades` (
  `idespecialidades` int(11) NOT NULL,
  `designacao_especialidade` varchar(405) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Extraindo dados da tabela `especialidades`
--

INSERT INTO `especialidades` (`idespecialidades`, `designacao_especialidade`) VALUES
(1, 'Medicina Natural'),
(2, 'Urologia'),
(4, 'Plantologia'),
(5, 'Triologia');

-- --------------------------------------------------------

--
-- Estrutura da tabela `funcionarios`
--

CREATE TABLE `funcionarios` (
  `idfuncionarios` int(11) NOT NULL,
  `nome_funcionario` varchar(45) NOT NULL,
  `id_categoria_funcionario` int(11) NOT NULL,
  `email_funcionario` varchar(45) NOT NULL,
  `telefone_funcionario` varchar(45) NOT NULL,
  `senha` varchar(405) NOT NULL,
  `morada` longtext NOT NULL,
  `foto` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `funcionarios`
--

INSERT INTO `funcionarios` (`idfuncionarios`, `nome_funcionario`, `id_categoria_funcionario`, `email_funcionario`, `telefone_funcionario`, `senha`, `morada`, `foto`) VALUES
(1, 'Odete Franco', 3, 'odete@yahoo.com', '935555500', '6add84506c86a658bc85038f91e35ce7', 'Gamek\r\nBenfinca', '1660988910.jpg'),
(2, 'Joãp Ninguém', 1, 'johndoe@gmail.com', '945151527', '6add84506c86a658bc85038f91e35ce7', 'Camama, bairro 4 de abril.', '1660253783.jpg');

-- --------------------------------------------------------

--
-- Estrutura da tabela `localidades`
--

CREATE TABLE `localidades` (
  `idlocalidades` int(11) NOT NULL,
  `provincia` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bairro` varchar(405) COLLATE utf8_unicode_ci DEFAULT NULL,
  `municipio` varchar(405) COLLATE utf8_unicode_ci DEFAULT NULL,
  `distrito` varchar(405) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rua` varchar(405) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Extraindo dados da tabela `localidades`
--

INSERT INTO `localidades` (`idlocalidades`, `provincia`, `bairro`, `municipio`, `distrito`, `rua`) VALUES
(3, 'Luanda', '4 de Abril', 'Belas', 'Camama', '12'),
(4, 'Bengo', 'Benfica', 'Belas', 'Camama', '12'),
(5, 'Luanda', 'Benfica', 'sei lá', 'kilamba kiaxi', '12'),
(6, 'Malanje', 'Kalandula', 'Negas', 'Camama', '12');

-- --------------------------------------------------------

--
-- Estrutura da tabela `marcacao_consultas`
--

CREATE TABLE `marcacao_consultas` (
  `idmarcacaoconsultaa` int(11) NOT NULL,
  `id_especialidade` int(11) NOT NULL,
  `id_paciente` int(11) NOT NULL,
  `id_clinica` int(11) NOT NULL,
  `id_medico` int(11) NOT NULL DEFAULT 1,
  `estado` int(11) NOT NULL DEFAULT 1,
  `motivo` longtext COLLATE utf8_unicode_ci NOT NULL,
  `info` longtext COLLATE utf8_unicode_ci NOT NULL,
  `endereco` longtext COLLATE utf8_unicode_ci NOT NULL,
  `data_solicitação_consulta` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `data_feedback` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `visto` enum('0','1') COLLATE utf8_unicode_ci NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Extraindo dados da tabela `marcacao_consultas`
--

INSERT INTO `marcacao_consultas` (`idmarcacaoconsultaa`, `id_especialidade`, `id_paciente`, `id_clinica`, `id_medico`, `estado`, `motivo`, `info`, `endereco`, `data_solicitação_consulta`, `data_feedback`, `visto`) VALUES
(1, 5, 1, 4, 2, 2, 'Estamos testando', 'hfdhdhdhfhdfhd', 'camama', '20-08-22 00:24:44', '2022-09-07 22:17:55', '1'),
(2, 2, 1, 3, 2, 4, 'rotina', 'popopc<br />\r\ndgpdgidogidgdgjdgjdog<br />\r\nfdbdkpbdokbpdbk gjkdgjldgngnnbdjhf', 'Luanda camama', '21-08-22 03:52:06', '2022-09-06 23:09:47', '1'),
(3, 2, 1, 5, 2, 5, 'rotina', 'urturrj<br />\r\ndh<br />\r\nb<br />\r\nh<br />\r\nh<br />\r\nrhr<br />\r\nj<br />\r\njt', 'camama', '21-08-22 17:12:50', '2022-09-06 23:09:06', '1');

-- --------------------------------------------------------

--
-- Estrutura da tabela `medicos`
--

CREATE TABLE `medicos` (
  `idmedicos` int(11) NOT NULL,
  `nome_medico` varchar(225) COLLATE utf8_unicode_ci NOT NULL,
  `email_medico` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `BI_medico` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `telefone_medico` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `id_especialidade` int(11) NOT NULL,
  `localidade` longtext COLLATE utf8_unicode_ci NOT NULL,
  `id_certificacoes` int(11) NOT NULL,
  `id_clinica` int(11) NOT NULL,
  `descricao` longtext COLLATE utf8_unicode_ci NOT NULL,
  `foto` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `data_nascimento` date NOT NULL,
  `numero_ordem` varchar(45) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Extraindo dados da tabela `medicos`
--

INSERT INTO `medicos` (`idmedicos`, `nome_medico`, `email_medico`, `BI_medico`, `telefone_medico`, `id_especialidade`, `localidade`, `id_certificacoes`, `id_clinica`, `descricao`, `foto`, `data_nascimento`, `numero_ordem`) VALUES
(1, 'Alexandre Ngunza', 'alexandrengunza@gmail.com', '000936LA0147', '930303030', 1, 'Chimbicato camama', 1, 2, '', '1660193161.jpg', '1989-06-11', '14305');

-- --------------------------------------------------------

--
-- Estrutura da tabela `mensagens`
--

CREATE TABLE `mensagens` (
  `idmensagens` int(11) NOT NULL,
  `nome_remetente` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `email_remetente` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `assunto` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `mensagens` longtext COLLATE utf8_unicode_ci NOT NULL,
  `estado` enum('0','1') COLLATE utf8_unicode_ci NOT NULL,
  `data_envio` varchar(100) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Extraindo dados da tabela `mensagens`
--

INSERT INTO `mensagens` (`idmensagens`, `nome_remetente`, `email_remetente`, `assunto`, `mensagens`, `estado`, `data_envio`) VALUES
(1, 'Nzongo Pedro', 'nzongopedro3@gmail.com', 'Polo', 'fjgjgjj', '0', '0'),
(2, 'Nzongo Pedro', 'nzongopedro3@gmail.com', 'Polo', 'fjgjgjj', '0', '16/06/2022'),
(3, 'Nzongo Pedro', 'nzongopedro3@gmail.com', 'Polo', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Molestias possimus ullam cumque sapiente iure quo ab expedita facere, dolorem molestiae autem a quidem dolore repellat exercitationem! Perspiciatis, explicabo! Praesentium, accusamus?', '0', '16/06/2022'),
(4, 'Nzongo Pedro', 'nzongopedro3@gmail.com', 'Polo', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Molestias possimus ullam cumque sapiente iure quo ab expedita facere, dolorem molestiae autem a quidem dolore repellat exercitationem! Perspiciatis, explicabo! Praesentium, accusamus?', '0', '16/06/2022'),
(5, 'Nzongo Pedro', 'nzongopedro3@gmail.com', 'Polo', ' setTimeout(() =&gt; {<br />\r\n              resposta.innerHTML = &quot;&quot;<br />\r\n            }, 2000);', '0', '16/06/2022'),
(6, 'Nzongo Pedro', 'nzongopedro3@gmail.com', 'Polo', 'ssssssssssssssss', '0', '16/06/2022'),
(7, 'Modieu Francisco', 'rita@gmail.com', 'Polo', 'Viva a vida com cuidado', '0', '16/06/2022'),
(8, 'Mbiyanga Pedro', 'mby@gmail.com', 'Testando ', 'Boa tarde, queria saber como chegar aí... <br />\r\nEstou no golf II.<br />\r\nPreciso mesmo de uma consulta vossa.', '0', '17/06/2022'),
(9, 'Luciano Gonçalves ', 'Luciano@gmail.com', 'Doença ', 'Olá estou doente.<br />\r\nPreciso de ajuda.', '0', '21/06/2022');

-- --------------------------------------------------------

--
-- Estrutura da tabela `pacientes`
--

CREATE TABLE `pacientes` (
  `idpacientes` int(11) NOT NULL,
  `nome_paciente` varchar(225) COLLATE utf8_unicode_ci NOT NULL,
  `telefone_paciente` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `BI_paciente` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `email_paciente` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `descricao_doenca` longtext COLLATE utf8_unicode_ci NOT NULL,
  `senha` longtext COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Extraindo dados da tabela `pacientes`
--

INSERT INTO `pacientes` (`idpacientes`, `nome_paciente`, `telefone_paciente`, `BI_paciente`, `email_paciente`, `descricao_doenca`, `senha`) VALUES
(1, 'Francisco Pedro', '935555501', '000056986LA017', 'afranio77@yahoo.com', '', 'dd4b21e9ef71e1291183a46b913ae6f2'),
(3, 'Jardel Lutumba', '948424248', '00009256LA04814', 'jardel@yahoo.com', '', 'dd4b21e9ef71e1291183a46b913ae6f2'),
(4, 'Pedro Nzongo', '942481988', '0098678LM366A', 'nzongopedro3@gmail.com', '', 'dd4b21e9ef71e1291183a46b913ae6f2'),
(5, 'Maria Nzongo', '922321619', '000936LA01472', 'maria@yahoo.com', '', 'dd4b21e9ef71e1291183a46b913ae6f2'),
(6, 'Silvio Pedro', '920000000', '000056986LA018', 'afranio770@yahoo.com', '', 'dd4b21e9ef71e1291183a46b913ae6f2'),
(7, 'Silvia Pedro', '930000000', '000056986LA0174', 'afranio707@yahoo.com', '', 'dd4b21e9ef71e1291183a46b913ae6f2');

-- --------------------------------------------------------

--
-- Estrutura da tabela `produtos`
--

CREATE TABLE `produtos` (
  `idproduto` int(11) NOT NULL,
  `nome_produto` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `preco_produto` float NOT NULL DEFAULT 0,
  `descricao` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `foto_produto` varchar(45) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Extraindo dados da tabela `produtos`
--

INSERT INTO `produtos` (`idproduto`, `nome_produto`, `preco_produto`, `descricao`, `foto_produto`) VALUES
(7, 'Babosa', 3500, 'Faz ficar inteligente. Aumenta o QI até 20%.', '1661011912.jpg'),
(9, 'Makala katsunga', 5000, 'ajuda com impertensão.', '1661039531.jpg'),
(11, 'Folha de Louro', 1500, 'ajuda com impertensão.', '1662237192.jpg');

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `categoria_funcionarios`
--
ALTER TABLE `categoria_funcionarios`
  ADD PRIMARY KEY (`idcategoria_funcionarios`);

--
-- Índices para tabela `certificacoes`
--
ALTER TABLE `certificacoes`
  ADD PRIMARY KEY (`idcertificacoes`);

--
-- Índices para tabela `clinicas`
--
ALTER TABLE `clinicas`
  ADD PRIMARY KEY (`idclinicas`),
  ADD KEY `fk_clinixa_especialidade_idx` (`id_especialidade`);

--
-- Índices para tabela `compras`
--
ALTER TABLE `compras`
  ADD PRIMARY KEY (`idcompra`),
  ADD KEY `compra_produto_idx` (`id_produto`),
  ADD KEY `conpra_cliente_idx` (`id_cliente`);

--
-- Índices para tabela `conta_funcionario`
--
ALTER TABLE `conta_funcionario`
  ADD PRIMARY KEY (`idconta_funcionario`),
  ADD KEY `fk_conta_funcionarios_idx` (`id_funcionario`);

--
-- Índices para tabela `especialidades`
--
ALTER TABLE `especialidades`
  ADD PRIMARY KEY (`idespecialidades`);

--
-- Índices para tabela `funcionarios`
--
ALTER TABLE `funcionarios`
  ADD PRIMARY KEY (`idfuncionarios`),
  ADD KEY `fk_funcionario_xategoria_idx` (`id_categoria_funcionario`);

--
-- Índices para tabela `localidades`
--
ALTER TABLE `localidades`
  ADD PRIMARY KEY (`idlocalidades`);

--
-- Índices para tabela `marcacao_consultas`
--
ALTER TABLE `marcacao_consultas`
  ADD PRIMARY KEY (`idmarcacaoconsultaa`),
  ADD KEY `fk_marcacao_especialidade_idx` (`id_especialidade`),
  ADD KEY `fk_marcacao_clinica_idx` (`id_clinica`),
  ADD KEY `fk_mr_paciente_idx` (`id_paciente`);

--
-- Índices para tabela `medicos`
--
ALTER TABLE `medicos`
  ADD PRIMARY KEY (`idmedicos`),
  ADD KEY `fk_medicos_especialidad_idx` (`id_especialidade`),
  ADD KEY `fk_medico_certificacao_idx` (`id_certificacoes`),
  ADD KEY `fk_medico_clinica_idx` (`id_clinica`);

--
-- Índices para tabela `mensagens`
--
ALTER TABLE `mensagens`
  ADD PRIMARY KEY (`idmensagens`);

--
-- Índices para tabela `pacientes`
--
ALTER TABLE `pacientes`
  ADD PRIMARY KEY (`idpacientes`);

--
-- Índices para tabela `produtos`
--
ALTER TABLE `produtos`
  ADD PRIMARY KEY (`idproduto`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `categoria_funcionarios`
--
ALTER TABLE `categoria_funcionarios`
  MODIFY `idcategoria_funcionarios` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT de tabela `certificacoes`
--
ALTER TABLE `certificacoes`
  MODIFY `idcertificacoes` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de tabela `clinicas`
--
ALTER TABLE `clinicas`
  MODIFY `idclinicas` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de tabela `compras`
--
ALTER TABLE `compras`
  MODIFY `idcompra` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT de tabela `conta_funcionario`
--
ALTER TABLE `conta_funcionario`
  MODIFY `idconta_funcionario` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `especialidades`
--
ALTER TABLE `especialidades`
  MODIFY `idespecialidades` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de tabela `funcionarios`
--
ALTER TABLE `funcionarios`
  MODIFY `idfuncionarios` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT de tabela `localidades`
--
ALTER TABLE `localidades`
  MODIFY `idlocalidades` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de tabela `marcacao_consultas`
--
ALTER TABLE `marcacao_consultas`
  MODIFY `idmarcacaoconsultaa` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de tabela `medicos`
--
ALTER TABLE `medicos`
  MODIFY `idmedicos` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de tabela `mensagens`
--
ALTER TABLE `mensagens`
  MODIFY `idmensagens` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT de tabela `pacientes`
--
ALTER TABLE `pacientes`
  MODIFY `idpacientes` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT de tabela `produtos`
--
ALTER TABLE `produtos`
  MODIFY `idproduto` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- Restrições para despejos de tabelas
--

--
-- Limitadores para a tabela `clinicas`
--
ALTER TABLE `clinicas`
  ADD CONSTRAINT `fk_clinixa_especialidade` FOREIGN KEY (`id_especialidade`) REFERENCES `especialidades` (`idespecialidades`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Limitadores para a tabela `compras`
--
ALTER TABLE `compras`
  ADD CONSTRAINT `compra_produto` FOREIGN KEY (`id_produto`) REFERENCES `produtos` (`idproduto`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `conpra_cliente` FOREIGN KEY (`id_cliente`) REFERENCES `pacientes` (`idpacientes`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Limitadores para a tabela `conta_funcionario`
--
ALTER TABLE `conta_funcionario`
  ADD CONSTRAINT `fk_conta_funcionarios` FOREIGN KEY (`id_funcionario`) REFERENCES `funcionarios` (`idfuncionarios`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Limitadores para a tabela `funcionarios`
--
ALTER TABLE `funcionarios`
  ADD CONSTRAINT `fk_funcionario_xategoria` FOREIGN KEY (`id_categoria_funcionario`) REFERENCES `categoria_funcionarios` (`idcategoria_funcionarios`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Limitadores para a tabela `marcacao_consultas`
--
ALTER TABLE `marcacao_consultas`
  ADD CONSTRAINT `fk_marcacao_clinica` FOREIGN KEY (`id_clinica`) REFERENCES `clinicas` (`idclinicas`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_marcacao_especialidade` FOREIGN KEY (`id_especialidade`) REFERENCES `especialidades` (`idespecialidades`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_mr_paciente` FOREIGN KEY (`id_paciente`) REFERENCES `pacientes` (`idpacientes`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Limitadores para a tabela `medicos`
--
ALTER TABLE `medicos`
  ADD CONSTRAINT `fk_medico_certificacao` FOREIGN KEY (`id_certificacoes`) REFERENCES `certificacoes` (`idcertificacoes`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_medico_clinica` FOREIGN KEY (`id_clinica`) REFERENCES `clinicas` (`idclinicas`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_medicos_especialidad` FOREIGN KEY (`id_especialidade`) REFERENCES `especialidades` (`idespecialidades`) ON DELETE NO ACTION ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
