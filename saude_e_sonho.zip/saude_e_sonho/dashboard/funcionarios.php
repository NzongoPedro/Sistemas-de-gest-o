<?php
session_start();
if (!isset($_SESSION['email_funcionario'])) {
  header("location: ./sair.php");
}
require './assets/./php/./env.php';



?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Gerenciar funcionário | Saúde e sonho</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.gstatic.com" rel="preconnect">
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/quill/quill.snow.css" rel="stylesheet">
  <link href="assets/vendor/quill/quill.bubble.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/simple-datatables/style.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: NiceAdmin - v2.2.2
  * Template URL: https://bootstrapmade.com/nice-admin-bootstrap-admin-html-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>

  <!-- ======= Header ======= -->
  <!-- End Header -->
  <?php require './assets/./php/./adm-includes/./important/./header.php'; ?>
  <!-- End Header -->

  <!-- ======= Sidebar ======= -->
  <?php require './assets/./php/./adm-includes/./important/./lesft-menu.php'; ?>
  <!-- ======= Sidebar ======= -->

  <!-- End Sidebar-->

  <main id="main" class="main">

    <div class="pagetitle" id="novo">
      <h1>Funcionários</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="index.html">Home</a></li>
          <li class="breadcrumb-item">Funcionários</li>

        </ol>
      </nav>
    </div><!-- End Page Title -->

    <div class="pagetitle">

      <section class="section">
        <div class="row">
          <div class="col-lg-12">

            <div class="card">
              <div class="card-body">
                <div class="card-title">
                  Tabela de funcionários
                  <div class="float-end">
                    <button type="button" class="btn btn-sm bg-btn mf" data-bs-toggle="modal" data-bs-target="#staticBackdrop"><i class="bi bi-plus mt-1"></i> Novo</button>
                    <a href="./docs/funcionarios.php?funcionarios" class="btn btn-sm bg-btn" target="_blank"><i class="bi bi-file-pdf mt-1"></i> Exportar PDF</a>
                    <!--   <button type="button" class="btn btn-sm bg-btn trucate-funcionario"><i class="bi bi-trash mt-1"></i> Apagar todos</button> -->
                  </div>
                </div>


                <!--   <div class="search-bar">
                  <form class="search-form d-flex align-items-center pesquisar-funcionario">
                    <input class="campo-pesquisa-funcionario" type="search" name="query" placeholder="Pesquisar Funcionário" title="pesquisar">
                    <button type="button" title="Search" class="bg-btn"><i class="bi bi-search"></i></button>
                  </form>
                </div> -->
                <!-- Table with stripped rows -->
                <table class="table table-striped table-sm datatable">
                  <thead>
                    <tr>
                      <th scope="col">#</th>
                      <th scope="col">Nome</th>
                      <th scope="col">Categoria</th>
                      <th scope="col">Email</th>
                      <th scope="col">Telefone</th>
                      <th scope="col">Opções</th>
                    </tr>
                  </thead>
                  <tbody class="data-table-funcionari">
                    <?= $funcionario->viewFuncionario($BD) ?>
                  </tbody>

                </table>
                <!-- End Table with stripped rows -->

              </div>
            </div>

          </div>
        </div>
      </section>
      <section class="section">
        <div class="row">

          <div class="col-lg-6" id="categorias">
            <div class="card">
              <div class="card-body">
                <h5 class="card-title">Adicionar categoria de funcionário </h5>

                <!-- Multi Columns Form -->
                <form class="row g-3 form-nova-categoria">
                  <div class="col-md-12">
                    <label for="inputName5" class="form-label">Designação da categoria</label>
                    <input type="text" class="form-control" name="categoria" required>
                  </div>
                  <div class="text-center response-categorias mt-4 mb-2"></div>
                  <div class="text-center mt-4">
                    <input type="hidden" name="acao" value="save-categoria">
                    <button type="submit" class="btn btn-sm bg-btn">Adicionar</button>
                  </div>
                </form><!-- End Multi Columns Form -->

              </div>
            </div>
          </div>

          <div class="col-lg-6">

            <div class="card">
              <div class="card-body">
                <h5 class="card-title">Todas as categorias</h5>
                <form action="" class="row form-edit-categoria" style="display:none">
                  <div class="form-group col-8 mb-3">
                    <input type="text" name="designacao" class="form-control form-control-sm campo" placeholder=" Categoria" required minlength="3">
                  </div>
                  <div class="mb-3 col-auto">
                    <button type="submit" class="btn btn-sm bg-btn btn-edit">salvar</button>
                    <input type="hidden" name="id" class="campo-id">
                    <input type="hidden" name="acao" value="update-categoria">
                  </div>
                </form>
                <!-- Vertical Form -->
                <div class="ss" tabindex="0" style="max-height: 155px; overflow:hidden; overflow-y: scroll;">

                  <table class="table table-borderless table-striped table-hover">
                    <thead>
                      <tr>
                        <th scope="col">#</th>
                        <th scope="col">Desginação</th>
                        <th scope="col">Ação</th>

                      </tr>
                    </thead>
                    <tbody class="data-table-categoriaa">
                      <?= $funcionario->viewcategoria($BD) ?>
                    </tbody>
                  </table>
                </div>

              </div>
            </div>

          </div>
        </div>
      </section>
    </div>

  </main><!-- End #main -->

  <?php require './assets/./php/./modals/./funcionario-add.php'; ?>



  <!-- ======= Footer ======= -->
  <footer id="footer" class="footer">
    <div class="copyright">
      &copy; Copyright <strong><span>Saúde e sonho</span></strong>. Todos os direitos reservados
    </div>
    <div class="credits">
      <!-- All the links in the footer should remain intact. -->
      <!-- You can delete the links only if you purchased the pro version. -->
      <!-- Licensing information: https://bootstrapmade.com/license/ -->
      <!-- Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/nice-admin-bootstrap-admin-html-template/ -->
      Feito por <a href="#">IOS</a>
    </div>
  </footer><!-- End Footer -->

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>


  <!-- Vendor JS Files -->
  <script src="assets/vendor/apexcharts/apexcharts.min.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/chart.js/chart.min.js"></script>
  <script src="assets/vendor/echarts/echarts.min.js"></script>
  <script src="assets/vendor/quill/quill.min.js"></script>
  <script src="assets/vendor/simple-datatables/simple-datatables.js"></script>
  <script src="assets/vendor/tinymce/tinymce.min.js"></script>
  <script src="assets/vendor/jquery/jquery.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

  <!-- REQUESTS JS FILE -->
  <script src="assets/js/requests.js"></script>


  <script>

  </script>

</body>

</html>