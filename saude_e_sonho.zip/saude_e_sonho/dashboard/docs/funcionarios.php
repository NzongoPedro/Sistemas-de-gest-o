<?php
require '../assets/php/env.php';
require '../dompdf/autoload.inc.php';

use Dompdf\Dompdf;
use Dompdf\Options;

$options = new Options();

$options->set('isRemoteEnabled', true);

$dompdf = new DOMPDF($options);

// A few settings
$image = '../assets/./img/./logo.png';

// Read image path, convert to base64 encoding
$imageData = base64_encode(file_get_contents($image));

// Format the image SRC:  data:{mime};base64,{data};
$src = 'data:' . mime_content_type($image) . ';base64,' . $imageData;


#================= APRESENTAR TODOS OS ALUNOS ==============================
if (isset($_GET['funcionarios'])) {

  $thead2 = "";
  $contar = "";

  $contar = $BD->query("SELECT COUNT(idfuncionarios) AS TOTAL FROM funcionarios");

  $busca = $BD->query("SELECT *FROM funcionarios
    INNER JOIN categoria_funcionarios
    ON categoria_funcionarios.idcategoria_funcionarios = funcionarios.id_categoria_funcionario ORDER BY nome_funcionario ASC");

  while ($funcionario = $busca->fetch()) :
    $thead2 .= "<tr>";
    $thead2 .= '<td>' . $funcionario->idfuncionarios . '</td>';
    $thead2 .= '<td>' . $funcionario->nome_funcionario . '</td>';
    $thead2 .= '<td>' . $funcionario->designacao_categoria . '</td>';
    $thead2 .= '<td>' . $funcionario->email_funcionario . '</td>';
    $thead2 .= '<td>' . $funcionario->telefone_funcionario . '</td>';
    $thead2 .= '<td>' . $funcionario->morada . '</td>';
    $thead2 .= "</tr>";
  endwhile;

  $thead =
    '
  <!DOCTYPE html>
  <html lang="pt-br">
  <head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- BOOTSTRAP -->
    

    <title>Lista de funcionários do saude e sonho</title>
    <style>
    body{
      background:#fbfbfb; padding:1px;}
    table{
      background:#ddd;
      padding: 0px
      }

      table thead{
        background: #999;
      }
    
      table tr th{
        padding:3px;
        background: #444;
        color: #fff;
        font-family: sans-serif;
        text-transform:uppercase
      }
      table tbody tr td{
        font-family: sans-serif;
        font-size: 14px;
        text-align:center
      } 
      table tbody tr:nth-child(odd){
        padding:1px;
      }
      table tbody tr:nth-child(even){
        background: #999;
        padding:1px;
      }
      
      h5,h2{text-align:center; font-family:sans-serif}
      h5{ color: #253D4B !important;}
      h2{ color: #222;}
      h2 b{ color: #444; font-size:12px}
      div.flex{
        display:flex !important;
        justify-content:center;
        items-align:center;

      }
      img{
        max-width:100%;
        padding:2px
      }
      h4 span{
        font-family:sans-serif;
        display:block
        }
        b{
          font-family:sans-serif;
    </style>
  </head>

  <body class="fundo">
    <div class="card-body">
      <center>
        <img src="' . $src . '">
        <h4>
          <span>SAÚDE E SONHO</span>       
          <span>SERVIÇOS DE SAÚDE E MEDICINA NATURAL E CONSULTA  ONLINE</span>
        </h4>
        <h2>LISTA DE FUNCIONÁRIOS</h2> </h2>
      </center>
    </div>

    <table>
      <thead>
        <tr>
          <th>#</th>
          <th>NOME</th>
          <th>FUNÇÃO</th>
          <th>E-MAIL</th>
          <th>TELEFONE</th>
          <th>MORADA</th>
        </tr>
      </thead>
      <tbody>' . $thead2 . '</tbody>
    </table>

  </body>
</html>

  ';


  $dompdf->loadhtml($thead);
  $dompdf->setPaper('A4', 'portaitil');
  # outr ORIEnTAÇÃO (PORTAITIL)

  //Renderizar o html
  $dompdf->render();

  //Exibibir a página
  $dompdf->stream(
    "Lista de funcoionários (saúde e sonho).pdf",
    array(
      "Attachment" => false //Para realizar o download somente alterar para true
    )

  );
}
