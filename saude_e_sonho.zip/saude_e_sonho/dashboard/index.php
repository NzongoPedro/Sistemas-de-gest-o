<?php
session_start();
if (!isset($_SESSION['email_funcionario'])) {
  header("location: ./sair.php");
}
require './assets/php/env.php';
require './assets/php/controllers/clinicas.php';
require './assets/php/controllers/consultas.php';

?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Dashboard - Saúde e Sonho</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.gstatic.com" rel="preconnect">
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/quill/quill.snow.css" rel="stylesheet">
  <link href="assets/vendor/quill/quill.bubble.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/simple-datatables/style.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: NiceAdmin - v2.2.2
  * Template URL: https://bootstrapmade.com/nice-admin-bootstrap-admin-html-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>



  <!-- ======= Header ======= -->

  <!-- End Header -->

  <?php require './assets/./php/./adm-includes/./important/./header.php'; ?>
  <!-- ======= Sidebar ======= -->
  <?php require './assets/./php/./adm-includes/./important/./lesft-menu.php'; ?>
  <!-- End Sidebar-->

  <main id="main" class="main">

    <div class="pagetitle">
      <h1>Dashboard </h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="index.php">Home</a></li>
          <li class="breadcrumb-item active">Dashboard</li>
        </ol>
      </nav>
    </div><!-- End Page Title -->

    <section class="section dashboard">
      <div class="row">

        <!-- Left side columns -->
        <div class="col-lg-12">
          <div class="row">

            <!-- Sales Card -->
            <div class="col-xxl-4 col-md-4">
              <div class="card info-card sales-card">
                <div class="card-body">
                  <h5 class="card-title">
                    <a href="#" class="text-decoration-none" data-bs-toggle="modal" data-bs-target="#mcc"> Consultas</a>
                  </h5>

                  <div class="d-flex align-items-center">
                    <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                      <i class="bi bi-heart-half"></i>
                    </div>
                    <div class="ps-3">
                      <span><?= $consultas->contarConsultas($BD, $funcionario->getId()) ?> Registros</span>
                    </div>
                  </div>
                </div>

              </div>
            </div><!-- End Sales Card -->

            <!-- Revenue Card -->
            <div class="col-xxl-4 col-md-4">
              <div class="card info-card revenue-card">
                <div class="card-body">
                  <h5 class="card-title">
                    <a href="#" class="text-deciration_none" data-bs-toggle="modal" data-bs-target="#mc"> Clínicas</a>
                  </h5>
                  <div class="d-flex align-items-center">
                    <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                      <i class="bi bi-thermometer-half"></i>
                    </div>
                    <div class="ps-3">
                      <span><?= $clinica->contarClinicas($BD) ?> Registros</span>
                    </div>
                  </div>
                </div>

              </div>
            </div><!-- End Revenue Card -->

            <!-- Customers Card -->
            <?php
            if ($_SESSION['categoria_funcionario'] == 'Admnistrador') { ?>
              <div class="col-xxl-4 col-md-4">
                <div class="card info-card customers-card">
                  <div class="card-body">
                    <h5 class="card-title">
                      <a href="#" class="text-decoration-none" data-bs-toggle="modal" data-bs-target="#mf"> Funcionários</a>
                    </h5>
                    <div class="d-flex align-items-center">
                      <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                        <i class="bi bi-people"></i>
                      </div>
                      <div class="ps-3">
                        <span><?= $funcionario->contarfuncionarios($BD) ?> Registros</span>
                      </div>
                    </div>
                  </div>
                </div>

              </div><!-- End Customers Card -->
            <?php } else { ?>
              <div class="col-xxl-4 col-md-4">
                <div class="card info-card customers-card">
                  <div class="card-body">
                    <h5 class="card-title text-white">
                      <a href="./funcionarios.php" class="text-decoration-none">Funcionários</a>

                    </h5>
                    <div class="d-flex align-items-center">
                      <div class="card-icon text-white bg-white rounded-circle d-flex align-items-center justify-content-center">
                        <i class="bi bi-people bg-white"></i>
                      </div>
                      <div class="ps-3">
                        <span class="text-white"><?= $funcionario->contarfuncionarios($BD) ?></span>
                      </div>
                    </div>
                  </div>
                </div>

              </div><!-- End Customers Card -->
            <?php } ?>
            <!-- gra´ficos -->
            <div class="row">
              <div class="col-lg-6">
                <div class="card">
                  <div class="card-body">
                    <h5 class="card-title">Estado das Consultas</h5>

                    <!-- Pie Chart -->
                    <div id="pieChart"></div>

                    <script>
                      document.addEventListener("DOMContentLoaded", () => {
                        new ApexCharts(document.querySelector("#pieChart"), {
                          series: [<?= contaDadosconsultas($BD, $funcionario->getId()) ?>],
                          chart: {
                            height: 350,
                            type: 'pie',
                            toolbar: {
                              show: true
                            }
                          },
                          labels: ['Pendentes', 'Realazadas', 'Agendadas', 'Cancelados', 'Preescritas', 'Marcadas']
                        }).render();
                      });
                    </script>
                    <!-- End Pie Chart -->

                  </div>
                </div>
              </div>
              <?php
              if ($_SESSION['categoria_funcionario'] == 'Admnistrador') { ?>
                <div class="col-lg-6">
                  <div class="card">
                    <div class="card-body">
                      <h5 class="card-title">Categorias de funcionários</h5>

                      <!-- Radial Bar Chart -->
                      <div id="radialBarChart"></div>
                      <canvas id="barChart"></canvas>
                      <script>
                        document.addEventListener("DOMContentLoaded", () => {
                          new Chart(document.querySelector('#barChart'), {
                            type: 'bar',
                            data: {
                              labels: ['Médicos', 'Secretárias', 'Administradores'],
                              datasets: [{
                                label: 'Total de elementos',
                                data: [<?= contaDadosFuncionarios($BD) ?>],
                                backgroundColor: [
                                  /*  'rgba(255, 99, 132, 0.2)',
                                   'rgba(255, 159, 64, 0.2)',
                                   'rgba(255, 205, 86, 0.2)',
                                   'rgba(75, 192, 192, 0.2)', */
                                  'rgba(54, 162, 235, 0.2)',
                                  'rgba(153, 102, 255, 0.2)',
                                  'rgba(201, 103, 20, 0.2)'
                                ],
                                borderColor: [
                                  /*  'rgb(255, 99, 132)',
                                   'rgb(255, 159, 64)',
                                   'rgb(255, 205, 86)',
                                   'rgb(75, 192, 192)', */
                                  'rgb(54, 162, 235)',
                                  'rgb(153, 102, 255)',
                                  'rgb(201, 203, 207)'
                                ],
                                borderWidth: 1
                              }]
                            },
                            options: {
                              scales: {
                                y: {
                                  beginAtZero: true
                                }
                              }
                            }
                          });
                        });
                      </script>

                    </div>
                  </div>
                </div>
              <?php } ?>
            </div>

            <!-- Recent Sales -->
            <div class="col-6">
              <div class="card recent-sales overflow-auto">
                <div class="card-body">
                  <h5 class="card-title">Consultas <span>| recentes</span></h5>

                  <table class="table table-borderless datatable">
                    <thead>
                      <tr>

                        <th scope="col">Paciente</th>
                        <th scope="col">Consulta</th>
                        <th scope="col">Estado</th>

                      </tr>
                    </thead>
                    <tbody>

                      <?php

                      $select = $BD->query("SELECT *FROM marcacao_consultas 
                        INNER JOIN especialidades ON especialidades.idespecialidades = marcacao_consultas.id_especialidade
                        INNER JOIN pacientes ON pacientes.idpacientes = marcacao_consultas.id_paciente
                        INNER JOIN clinicas ON clinicas.idclinicas = marcacao_consultas.id_clinica
                        ORDER BY data_solicitação_consulta
                        ");

                      while ($consulta = $select->fetch()) { ?>

                        <tr>

                          <td><?= $consulta->nome_paciente ?></td>
                          <td><?= $consulta->designacao_especialidade ?></td>

                          <td>
                            <?php
                            if ($consulta->estado == 1) {
                              echo '<span class="badge rounded-pill bg-primary">Pendente</span>';
                            } elseif ($consulta->estado == 0) {
                              echo '<span class="badge rounded-pill bg-danger">Cancelada</span>';
                            } elseif ($consulta->estado == 2) {
                              echo '<span class="badge rounded-pill bg-dark">Preescrito</span>';
                            } else if ($consulta->estado == 3) {
                              echo '<span class="badge rounded-pill bg-info">Marcada</span>';
                            } else {
                              echo '<span class="badge rounded-pill bg-success">Realizada</span>';
                            }
                            ?>
                          </td>
                        </tr>
                      <?php } ?>


                    </tbody>
                  </table>

                </div>

              </div>
            </div><!-- End Recent Sales -->

            <!-- Top Selling -->
            <div class="col-6">
              <div class="card top-selling overflow-auto">
                <div class="card-body pb-0">
                  <h5 class="card-title">Médicos</h5>
                  <table class="table table-borderless datatable">
                    <thead>
                      <tr>
                        <th scope="col">Foto</th>
                        <th scope="col">Nome</th>
                        <th scope="col">Especialidade</th>

                      </tr>
                    </thead>
                    <tbody>

                      <?php
                      $medicos = $BD->query("SELECT *FROM funcionarios
                      INNER JOIN categoria_funcionarios ON categoria_funcionarios.idcategoria_funcionarios = funcionarios.id_categoria_funcionario
                     WHERE id_categoria_funcionario = '1'
                      ");

                      while ($medico = $medicos->fetch()) { ?>
                        <tr>
                          <th scope="row"><img src="assets/img/funcionarios/<?= $medico->foto ?>" style="max-width:100%; width:50px; height:50px; border-radius:100px"></th>
                          <td>
                            <a href="users-profile.php" class="text-dark"><?= $medico->nome_funcionario ?></a>

                          </td>
                          <td><?= $medico->designacao_categoria ?></td>

                        </tr>
                      <?php } ?>
                    </tbody>
                  </table>

                </div>

              </div>
            </div><!-- End Top Selling -->

          </div>
        </div><!-- End Left side columns -->


      </div>
    </section>

  </main><!-- End #main -->
  <?php require './assets/php/modals/mf.php' ?>
  <?php require './assets/php/modals/mc.php' ?>
  <?php require './assets/php/modals/mcc.php' ?>
  <?php require './assets/./php/./modals/./funcionario-add.php'; ?>
  <?php require './assets/./php/./modals/./clinica-add.php'; ?>
  <!-- ======= Footer ======= -->
  <footer id=" footer" class="footer">
    <div class="copyright">
      &copy; Copyright <strong><span>Saúde e sonho</span></strong>. Todos os direitos reservados
    </div>
    <div class="credits">
      <!-- All the links in the footer should remain intact. -->
      <!-- You can delete the links only if you purchased the pro version. -->
      <!-- Licensing information: https://bootstrapmade.com/license/ -->
      <!-- Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/nice-admin-bootstrap-admin-html-template/ -->
      Feito por <a href="#">IOS</a>
    </div>
  </footer><!-- End Footer -->

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/apexcharts/apexcharts.min.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/chart.js/chart.min.js"></script>
  <script src="assets/vendor/echarts/echarts.min.js"></script>
  <script src="assets/vendor/quill/quill.min.js"></script>
  <script src="assets/vendor/simple-datatables/simple-datatables.js"></script>
  <script src="assets/vendor/tinymce/tinymce.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <script src="assets/vendor/jquery/jquery.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

  <input type="hidden" id="d" value="<?= $funcionario->getCategoria() ?>">
  <script>
    var estado = document.querySelector("#d").value
    if (estado == "Secretaria") {
      window.location.href = "./consultas.php"
    }
  </script>
  <!-- REQUESTS JS FILE -->
  <script src="assets/js/requests.js"></script>


</body>

</html>