<?php
session_start();
require './assets/php/env.php';
if (!isset($_SESSION['email_funcionario'])) {
  header("location: ./sair.php");
} else {
  require './assets/php/controllers/pacientes.php';
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Pacientes | Saúde e sonho</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.gstatic.com" rel="preconnect">
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/quill/quill.snow.css" rel="stylesheet">
  <link href="assets/vendor/quill/quill.bubble.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/simple-datatables/style.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  <style>
    .paciente span {
      color: #444;
      font-weight: bold;
      margin-bottom: 4px;
      display: block !important;
      border-bottom: 1px dotted #4154f1;
    }

    .paciente span b {
      color: #4154f1;
      float: right !important;
    }
  </style>
</head>

<body>

  <!-- ======= Header ======= -->
  <!-- End Header -->
  <?php require './assets/./php/./adm-includes/./important/./header.php'; ?>
  <!-- End Header -->

  <!-- ======= Sidebar ======= -->
  <?php require './assets/./php/./adm-includes/./important/./lesft-menu.php'; ?>
  <!-- ======= Sidebar ======= -->

  <!-- End Sidebar-->

  <main id="main" class="main">

    <div class="pagetitle">
      <h1>Dados do paciente </h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="./pacientes.php">Pacientes</a></li>
          <li class="breadcrumb-item">Paciente</li>

        </ol>
      </nav>
    </div><!-- End Page Title -->

    <div class="pagetitle">

      <section class="section">
        <div class="row">
          <div class="col-lg-12">
            <?php
            if (isset($_GET['idPaciente'])) {
              $id_paciente = filter_input(INPUT_GET, 'idPaciente', FILTER_SANITIZE_NUMBER_INT);
              $id_medico = $funcionario->getId();
              function dadosPaciente($BD, $id_paciente, $id_medico)
              {
                if ($_SESSION['categoria_funcionario'] == 'Admnistrador') {

                  $query = $BD->query("SELECT 
                  *FROM marcacao_consultas
                  INNER JOIN especialidades ON marcacao_consultas.id_especialidade = especialidades.idespecialidades
                  INNER JOIN pacientes ON marcacao_consultas.id_paciente = pacientes.idpacientes
                  INNER JOIN clinicas ON marcacao_consultas.id_clinica = clinicas.idclinicas
                  INNER JOIN funcionarios ON marcacao_consultas.id_medico = funcionarios.idfuncionarios");
                } else {
                  $query = $BD->query("SELECT   *FROM marcacao_consultas
                  INNER JOIN especialidades ON marcacao_consultas.id_especialidade = especialidades.idespecialidades
                  INNER JOIN pacientes ON marcacao_consultas.id_paciente = pacientes.idpacientes
                  INNER JOIN clinicas ON marcacao_consultas.id_clinica = clinicas.idclinicas
                  INNER JOIN funcionarios ON marcacao_consultas.id_medico = funcionarios.idfuncionarios
                   WHERE marcacao_consultas.id_paciente = '$id_paciente' AND marcacao_consultas.id_medico = '$id_medico'
                  ");
                }
                $resultado = $query->fetchAll();
                return json_encode($resultado);
                //$paciente['paciente'] = json_encode($resultado);

              }
            }
            ?>
            <div class="card">
              <div class="card-body">
                <?php
                $paciente = json_decode(dadosPaciente($BD, $id_paciente, $id_medico));

                foreach ($paciente as $p) { ?>
                  <!-- <div class="card-title">
                    <h5><?= $p->nome_paciente ?></h5>
                  </div>  <hr>-->


                  <div class="p-3 paciente shadow-lg mt-2">
                    <span>Nome : <b><?= $p->nome_paciente ?></b></span>
                    <span>E-mail: <b><?= $p->email_paciente ?></b></span>
                    <span>Telefone: <b><?= $p->telefone_paciente ?></b></span>
                    <span>Num de B.I: <b><?= $p->BI_paciente ?></b></span>
                  </div>

                  <?php
                  if ($p->estado == 2) { ?>
                    <div class="card-body shadow-sm">
                      <div class="alert alert-dark lead justify-content-center p-4 text-center d-flex">
                        <?= $p->info ?>
                      </div>
                    </div>
                  <?php } elseif ($p->estado == 0) { ?>
                    <div class="card mt-2 border-0">
                      <div class="card-header bg-danger">
                        <div class="card-title text-white">
                          <h5>Consulta Cancelada</h5>
                        </div>
                      </div>

                      <div class="card-body shadow-sm">
                        <div class="card-subtitle">
                          <h5 class="text-danger"><b>Detalhes</b></h5>
                        </div>
                        <div class="card-text text-lead text-dark">

                          <p class="text-dark"><b> Cancelamos a sua solicitação de consulta. Verificamos alguns incumprimentos tais como:</b></p>
                          <p>
                          <ul class="text-danger">
                            <li>Consultas repetidas.</li>
                            <li>Morada não específicado.</li>
                            <li>Tipo de consulta não específicado.</li>
                            <li>Motivo da consulta não específicado.</li>
                          </ul>
                          </p>
                        </div>
                      </div>
                    </div>
                  <?php } elseif ($p->estado == 3) { ?>
                    <div class="card mt-2">
                      <div class="card-header bg-success">
                        <div class="card-title text-white">
                          <h5>Consulta agendada</h5>
                        </div>
                      </div>

                      <div class="card-body shadow-sm mt-3">

                        <div class="card-text text-lead text-dark">
                          <div class="alert alert-success">
                            <b>Área: <?= $p->designacao_especialidade ?></b>
                            <br>
                            <b>Clínica: <?= $p->designacao_clinica ?></b>
                            <p class="mt-2">
                              detalhes:
                              <br>
                              você tem uma consulta agendada com <b><?= $p->nome_paciente ?></b>
                            </p>
                          </div>
                        </div>
                      </div>
                    </div>

                  <?php } elseif ($p->estado == 1) { ?>
                    <!-- <div class="card shadow-sm mt-2">
                      <div class="card-header card-title bg-dark text-white">
                        <h5>Informamos que a sua consulta encontra-se pendente</h5>
                      </div>
                      <div class="card-body shadow-sm">
                        <div class="alert alert-dark">
                          <b>Área: <?= $p->designacao_especialidade ?></b>
                          <br>
                          <b>Clínica: <?= $p->designacao_clinica ?></b>
                          <p class="mt-2">
                            detalhes:
                            <br>
                            <?= $p->motivo ?>
                          </p>
                        </div>
                        <h5 class="text-dark"><b>Detalhes</b></h5>
                        <p class="text-muted">Alguns motivos da pendência da sua consula:</p>
                        <ul class="text-dark">
                          <li>A sua ordem ainda não chegou.</li>
                          <li>A sua consulta está em análise.</li>
                          <li>A sua consulta ainda não chegou no servidor.</li>
                        </ul>
                      </div>
                    </div> -->
                  <?php } else { ?>
                    <div class="card mt-2 shadow-sm mt-2 border-0">
                      <div class="alert card-title bg-info text-white">
                        <h5 class="ms-2">Consulta realizada</h5>
                      </div>
                      <div class="card-body shadow-sm mt-4">
                        <div class="alert alert-info">
                          <b>Área: <?= $p->designacao_especialidade ?></b>
                          <br>
                          <b>Clínica: <?= $p->designacao_clinica ?></b>
                          <p class="mt-2">
                            detalhes:
                            <br>
                            <?= $p->motivo ?>
                          </p>
                        </div>
                        <h5 class="text-dark"><b>Prescrição Médica</b></h5>
                        <p class="text-muted">
                          <b class="text-info"> <?= $p->info ?></b>
                        </p>
                        <div class="text-center mt-2">

                          <b>Por:</b>: <?= $p->nome_funcionario ?>
                          <br>
                          <b>Aos <br> </b> <?= $p->data_solicitação_consulta ?>
                        </div>

                      </div>
                    </div>
                  <?php } ?>

                <?php }
                ?>


              </div>
            </div>
          </div>
        </div>
      </section>

    </div>

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer id="footer" class="footer">
    <div class="copyright">
      &copy; Copyright <strong><span>Saúde e sonho</span></strong>. Todos os direitos reservados
    </div>
    <div class="credits">
      <!-- All the links in the footer should remain intact. -->
      <!-- You can delete the links only if you purchased the pro version. -->
      <!-- Licensing information: https://bootstrapmade.com/license/ -->
      <!-- Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/nice-admin-bootstrap-admin-html-template/ -->
      Feito por <a href="#">IOS</a>
    </div>
  </footer><!-- End Footer -->
  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/apexcharts/apexcharts.min.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/chart.js/chart.min.js"></script>
  <script src="assets/vendor/echarts/echarts.min.js"></script>
  <script src="assets/vendor/quill/quill.min.js"></script>
  <script src="assets/vendor/simple-datatables/simple-datatables.js"></script>
  <script src="assets/vendor/tinymce/tinymce.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>