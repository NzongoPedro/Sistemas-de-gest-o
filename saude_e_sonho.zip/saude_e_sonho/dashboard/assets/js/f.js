var f = document.querySelector('.form-edit-profil')
f.addEventListener('submit', (d, dados) => {
  d.preventDefault()
  dados = new FormData(f)
  fetch('./assets/php/controllers/funcionarios.php', {

      method: 'POST',
      body: dados
    })
    .then(res => res.text())
    .then(data => {
      if (data == 200) {

        document.querySelector('.res').innerHTML = "<div class='alert alert-success'>Dados alterados</div>"
      
        setTimeout(() => {
          window.location.reload()
        }, 1500);
      } else {

        document.querySelector('.res').innerHTML = "<div class='alert alert-danger'>" + data + "</div>"
      }
    })
    .catch((e) => {
      console.log(e)
    })
})