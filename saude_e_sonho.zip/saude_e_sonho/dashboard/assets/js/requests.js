/* 
  @ ARQUIVO PARA TODAS AS REQUISSIÇÕES POST e GET
 */

async function ove(id) {
  const req = await fetch(`./assets/php/controllers/funcionarios.php?id=${id}&acao=drop`)
  const res = req.text()


  document.querySelector(`.linha_${id}`).classList.add('alert-danger')
  setTimeout(() => {
    document.querySelector(`.linha_${id}`).classList.add('d-none')
  }, 1500);
}


$(document).ready(function () {

  $('.barra').click()

  function recarregar(tempo) {
    setTimeout((tempo) => {
      window.location.reload();
    }, tempo);
  }

  var ajax_loader = '<img src="./assets/img/./ajax-loader.gif">';
  const exetensao = ".php";
  var url;
  url = `./assets/php/controllers/localidades${exetensao}`;

  // **********************************************************************
  //                ################ LOCALIDADES ####################

  // SAVE
  var form_localidade = $(".form-nova-localidade"),
    dados_form_localidades;
  form_localidade.submit((e) => {
    e.preventDefault();
    url = `./assets/php/controllers/localidades${exetensao}`;
    dados_form_localidades = form_localidade.serialize();
    $.ajax({
      url: url,
      method: "POST",
      data: dados_form_localidades,
      error: () => {
        $(".response-localidades")
          .addClass("alert")
          .addClass("alert-danger")
          .html("erro 404");
      },
      beforeSend: () => {
        $(".response-localidades").html(ajax_loader);
      },
      success: (data) => {
        if (data == "ok") {
          $(".response-localidades")
            .addClass("alert")
            .addClass("alert-success")
            .html("Dados gravado.");
          form_localidade.trigger("reset");
          $(".response-localidades").fadeOut(10000);
        } else {
          $(".response-localidades")
            .addClass("alert")
            .addClass("alert-danger")
            .html("algo deu errado." + data);
        }
      },
    });
  });

  // VIEW
  /*   setInterval(() => {
      $.ajax({
        url: url,
        method: "POST",
        data: {
          acao: "view",
        },
        success: (data) => {
          $(".data-table-localidades").html(data);
        },
      });
    }, 5000); */

  //                ################ END LOCALIDADES ####################

  //                  #################### FUNCIONARIOS ##################

  // ADD FUNCIONARIOS

  var form_funcionario = $(".form-novo-funcionario"),
    dados_form_funcionario;
  form_funcionario.submit((e) => {
    e.preventDefault();
    dados_form_funcionario = form_funcionario.serialize();
    $.ajax({
      url: `./assets/php/controllers/funcionarios${exetensao}`,
      method: "POST",
      data: dados_form_funcionario,
      error: () => {
        $(".response-funcionario")
          .addClass("alert")
          .addClass("alert")
          .addClass("alert-danger")
          .html("erro 404");
      },
      beforeSend: () => {
        $(".response-funcionario").html(ajax_loader);
      },
      success: (data) => {
        if (data == "ok") {
          $(".response-funcionario")
            .addClass("alert")
            .addClass("alert-success")
            .html("Dados gravado.");
          form_funcionario.trigger("reset");

          // $('.response-funcionario').fadeOut(2000)
          setTimeout(() => {
            $(".mf").click();
            window.location.reload();
          }, 2000);
        } else {
          $(".response-funcionario")
            .addClass("alert")
            .addClass("alert")
            .addClass("alert-danger")
            .html(data);
        }
      },
    });
  });

  // Editar
  var form_edit = $(".form-edita-funcionario"),
    dados_editado;
  form_edit.submit((e) => {
    e.preventDefault();
    dados_editado = form_edit.serialize();
    $.ajax({
      url: `./assets/php/controllers/funcionarios${exetensao}`,
      method: "POST",
      data: dados_editado,
      error: () => {
        $(".response-funcionario")
          .addClass("alert")
          .addClass("alert")
          .addClass("alert-danger")
          .html("erro 404");
      },
      beforeSend: () => {
        $(".response-funcionario").html(ajax_loader);
      },
      success: (data) => {
        if (data == "ok") {
          $(".response-funcionario")
            .addClass("alert")
            .addClass("alert-success")
            .html("Alterações salvas.");
          form_edit.trigger("reset");

          setTimeout(() => {
            window.location.href = "./funcionarios.php#novo";
          }, 3000);
        } else {
          $(".response-funcionario")
            .addClass("alert")
            .addClass("alert")
            .addClass("alert-danger")
            .html(data);
        }
      },
    });
  });

  // APAGAR TODOS funcionários
  $(".trucate-funcionario").click(() => {
    $.ajax({
      url: `./assets/php/controllers/funcionarios${exetensao}`,
      method: "POST",
      data: {
        acao: "truncate",
      },
    });
  });

  // apagar um funcionário
  /*   $(".rem-func").click(function (e) {
      alert(4)
      e.preventDefault();
      var id = $(this).attr("id");
      $.ajax({
        url: `./assets/php/controllers/funcionarios${exetensao}`,
        method: "POST",
        data: {
          acao: "drop",
          id: id,
        },
        success: function (data) {
          if (data == 200) {
            $(".linha_" + id)
              .addClass("alert-danger")
              .fadeOut(3000);
          } else {
            alert(data);
          }
        },
      });
    }); */

  // nova senha
  $(".form-nova-senha").submit(function (p) {
    p.preventDefault();
    var dados = $(".form-nova-senha").serialize();
    $.ajax({
      url: `./assets/php/controllers/funcionarios${exetensao}`,
      method: "POST",
      data: dados,

      success: function (data) {
        if (data == 200) {
          $(".res-senha")
            .removeClass("text-danger")
            .addClass("text-success")
            .html("senha alterada com sucesso");
          setTimeout(() => {
            location.reload();
          }, 3000);
        } else {
          $(".res-senha")
            .removeClass("text-success")
            .addClass("text-danger")
            .html(data);
        }
      },
    });
  });

  // ADD CATEGORIAS
  var form_categoria_funcionario = $(".form-nova-categoria"),
    dados_form_categoria;
  form_categoria_funcionario.submit((e) => {
    e.preventDefault();
    dados_form_categoria = form_categoria_funcionario.serialize();
    url = `./assets/php/controllers/funcionarios${exetensao}`;
    dados_form_localidades = form_localidade.serialize();
    $.ajax({
      url: url,
      method: "POST",
      data: dados_form_categoria,
      error: () => {
        $(".response-categorias")
          .addClass("alert")
          .addClass("alert-danger")
          .html("erro 404");
      },
      beforeSend: () => {
        $(".response-categorias").html(ajax_loader);
      },
      success: (data) => {
        if (data == "ok") {
          $(".response-categorias")
            .addClass("alert")
            .addClass("alert-success")
            .html("Dados gravado.");
          form_categoria_funcionario.trigger("reset");
          $(".response-categorias").fadeOut(5000);
          setTimeout(() => {
            window.location.reload();
          }, 2000);
        } else {
          $(".response-categorias")
            .addClass("alert")
            .addClass("alert")
            .addClass("alert-danger")
            .html(data);
        }
      },
    });
  });

  // VIEW CATEGORIA
  setInterval(() => {
    $.ajax({
      url: `./assets/php/controllers/funcionarios${exetensao}`,
      method: "POST",
      data: {
        acao: "view-categoria",
      },
      success: (data) => {
        $(".data-table-categoria").html(data);
      },
    });
  }, 5000);

  // apagar catwgoria
  $(".rem-categoria").click(function () {
    id = $(this).attr("id");
    $.ajax({
      url: `./assets/php/controllers/funcionarios${exetensao}`,
      method: "POST",
      data: {
        acao: "remover-categoria",
        id: id,
      },
      success: (data) => {
        if (data == 200) {
          $(`.linha-${id}`).addClass("alert-danger").fadeOut(1500);
        } else {
          alert(data);
        }
      },
    });
  });

  // EDITAR CATEGORIA

  $(".btn-edit-categoria").click(function (id, titulo) {
    $(".form-edit-categoria").fadeIn("fast");
    var campo = $(".campo");
    var campo_id = $(".campo-id");
    titulo = $(this).attr("title");
    id = $(this).attr("id");
    campo.val(titulo);
    campo_id.val(id);
  });

  $(".form-edit-categoria").submit((e, dados) => {
    e.preventDefault();
    dados = $(".form-edit-categoria").serialize();
    $.ajax({
      url: `./assets/php/controllers/funcionarios${exetensao}`,
      method: "POST",
      data: dados,
      success: (data) => {
        if (data == 200) {
          $(".btn-edit").html(`<i class="bi-check"> feito</i>`);
          recarregar()
        }
      },
    });
  });

  //                  #################### END FUNCIONARIOS ##################

  //                  ################# Clinicas ##########################

  // SAVE CLINICAS

  var form_nova_clinica = $(".form-nova-clinica");

  form_nova_clinica.submit((e) => {
    e.preventDefault();

    $.ajax({
      url: `./assets/php/controllers/clinicas${exetensao}`,
      method: "POST",
      data: form_nova_clinica.serialize(),
      error: () => {
        $(".response-clinicas")
          .addClass("alert")
          .addClass("alert-danger")
          .html("erro 404");
      },
      beforeSend: () => {
        $(".response-clinicas").html(ajax_loader);
      },
      success: (data) => {
        if (data == 200) {
          $(".response-clinicas")
            .addClass("alert")
            .addClass("alert-success")
            .html("Dados gravados");
          form_nova_clinica.trigger("reset");
          $(".response-clinicas").fadeOut(5000);
          recarregar()
        } else {
          $(".response-clinicas")
            .addClass("alert")
            .addClass("alert")
            .addClass("alert-danger")
            .html(data);
        }
      },
    });
  });

  // VIEW CLINICAS
  setInterval(() => {
    $.ajax({
      url: `./assets/php/controllers/clinicas${exetensao}`,
      method: "POST",
      data: {
        acao: "view-clinicas",
      },
      success: (data) => {
        $(".data-table-clinica").html(data);
      },
    });
  }, 2000);

  // save especiality

  var form_nova_especialidade = $(".form-nova-especialidade");
  form_nova_especialidade.submit((e) => {
    e.preventDefault();
    $.ajax({
      url: `./assets/php/controllers/clinicas${exetensao}`,
      method: "POST",
      data: form_nova_especialidade.serialize(),
      error: () => {
        $(".response-especialidades")
          .addClass("alert")
          .addClass("alert-danger")
          .html("erro 404");
      },
      beforeSend: () => {
        $(".response-especialidades").html(ajax_loader);
      },
      success: (data) => {
        if (data == 200) {
          $(".response-especialidades")
            .addClass("alert")
            .addClass("alert-success")
            .html("Dados gravado.");
          recarregar()
          form_nova_especialidade.trigger("reset");
          $(".response-especialidades").fadeOut(5000);
        } else {
          $(".response-especialidades")
            .addClass("alert")
            .addClass("alert-danger")
            .html(data);
        }
      },
    });
  });

  // remover especialidades
  $(".rem-especialidade").click(function (id) {
    id = $(this).attr("id");
    $.ajax({
      url: `./assets/php/controllers/clinicas${exetensao}`,
      method: "POST",
      data: {
        acao: "remover-especialidade",
        id: id,
      },
      success: (data) => {
        if (data == 200) {
          $(`.linha-${id}`).addClass("alert-danger").fadeOut(2000);
        }
      },
    });

    return false;
  });

  // editar especialidades
  $(".edit-especialidade").click(function (id, titulo) {
    var campo = $(".campo");
    var campo_id = $(".campo-id");
    id = $(this).attr("id");
    titulo = $(this).attr("title");
    $(".form-edit-especialidade").fadeIn("fast");
    campo.val(titulo);
    campo_id.val(id);
    return false;
  });

  $(".form-edit-especialidade").submit((e, dados) => {
    e.preventDefault();
    dados = $(".form-edit-especialidade").serialize();
    $.ajax({
      url: `./assets/php/controllers/clinicas${exetensao}`,
      method: "POST",
      data: dados,
      success: (data) => {
        $(".btn-edit").html(`<i class="bi-check"> Feito</i>`);
        if (data == 200) {
          setTimeout(() => {
            window.location.reload();
          }, 2500);
        } else {
          alert(data);
        }
      },
    });
  });

  // ################## END CLINICAS ##########################

  // ################## MEDICOS #########################

  // Save certificações
  var form_nova_certificacoes = $(".form-nova-certificacao");
  form_nova_certificacoes.submit((e) => {
    e.preventDefault();

    $.ajax({
      url: `./assets/php/controllers/medicos${exetensao}`,
      method: "POST",
      data: form_nova_certificacoes.serialize(),
      error: () => {
        $(".response-certificacoes")
          .addClass("alert")
          .addClass("alert-danger")
          .html("erro 404");
      },
      beforeSend: () => {
        $(".response-certificacoes").html(ajax_loader);
      },
      success: (data) => {
        if (data == "ok") {
          $(".response-certificacoes")
            .addClass("alert")
            .addClass("alert-success")
            .html("Dados gravado");
          recarregar()
        } else {
          $(".response-certificacoes")
            .addClass("alert")
            .addClass("alert-danger")
            .html(data);
        }
      },
    });
  });

  // apagar certificac~çp

  $('.apagarCer').click(function (id) {
    id = $(this).attr('id')
    $.ajax({
      url: `./assets/php/controllers/medicos${exetensao}`,
      method: "POST",
      data: {
        acao: 'rem-certificacao',
        idCertificacao: id
      },

      success: (data) => {
        if (data == 200) {
          $('.rem-linha-' + id).addClass('alert-danger')
          $('.rem-linha-' + id).fadeOut(1500)
        }
      }
    })

    return false
  })

  // editar certificação
  $(".btn-edit-certificacoes").click(function (id, titulo) {
    $(".form-edit-certificacoes").fadeIn("fast");
    var campo = $(".campo");
    var campo_id = $(".campo-id");
    titulo = $(this).attr("title");
    id = $(this).attr("id");
    campo.val(titulo);
    campo_id.val(id);
  });

  $(".form-edit-certificacoes").submit((e, dados) => {
    e.preventDefault();
    dados = $(".form-edit-certificacoes").serialize();
    $.ajax({
      url: `./assets/php/controllers/medicos${exetensao}`,
      method: "POST",
      data: dados,
      success: (data) => {
        $(".btn-edit").html(`<i class="bi-check"> Feito</i>`);
        if (data == 200) {
          setTimeout(() => {
            window.location.reload();
          }, 2500);
        } else {
          alert(data);
        }
      },
    });
  });


  // apagar médico
  $(".apagar-medico").click(function () {
    $.ajax({
      url: `./assets/php/controllers/medicos${exetensao}`,
      method: "POST",
      data: {
        idMedico: $(this).attr("id"),
        fotoMedico: $(this).attr("title"),
        acao: "apagar",
      },
      success: (data) => {
        $("#m" + $(this).attr("id")).fadeOut("slow");
      },
    });
    return false;
  });

  // #################### CONSULTAS ######################

  // viwe
  /*   setInterval(() => {
      $.ajax({
        url: `./assets/php/controllers/consultas${exetensao}`,
        method: "POST",
        data: {
          acao: "show",
          id: $('#ID').val()
        },
        success: (data) => {
          $(".data-consulta").html(data);
        },
      });
    }, 1000); */

  //  cancelar consulta
  const newLocal = ".btn-cancelar-consulta";
  $(newLocal).click(function () {
    idConsulta = $(this).attr("id");
    $.ajax({
      url: `./assets/php/controllers/consultas${exetensao}?idConsulta=${idConsulta}&acao=cancelar`,
      method: "GET",
      data: {
        a: "9",
      },
      success: function (data) {
        if (data == 200) {
          $(".resposta").html(
            '<div class="alert alert-danger">consulta cancelada.</div>'
          );
          setTimeout(() => {
            location.reload();
          }, 3000);
        } else {
          $(".resposta").html(
            '<div class="alert alert-danger">' + data + "</div>"
          );
        }
      },
    });
  });

  // activar consulta
  $(".btn-ativar-consulta").click(function () {
    idConsulta = $(this).attr("id");
    $.ajax({
      url: `./assets/php/controllers/consultas${exetensao}?idConsulta=${idConsulta}&acao=ativar`,
      method: "GET",
      data: {
        a: "9",
      },
      success: function (data) {
        if (data == 200) {
          $(".resposta").html(
            '<div class="alert alert-success">consulta reactivada. (Pendente)</div>'
          );
          setTimeout(() => {
            location.reload();
          }, 3000);
        } else {
          $(".resposta").html(
            '<div class="alert alert-danger">' + data + "</div>"
          );
        }
      },
    });
  });

  // prescrever a consulta

  $(".form-prescricao-consulta").submit(function (e) {
    e.preventDefault();
    $.ajax({
      url: `./assets/php/controllers/consultas${exetensao}`,
      method: "POST",
      data: $(".form-prescricao-consulta").serialize(),
      success: function (data) {
        if (data == 200) {
          $(".res-1").html(
            '<div class="alert alert-success">consulta preescrita</div>'
          );
          setTimeout(() => {
            $(".form-prescricao-consulta").trigger("reset");
            $(".btn-preescricao").click();
            location.reload();
          }, 3000);
        } else {
          $(".res-1").html('<div class="alert alert-danger">' + data + "</div>");
        }
      },
    });
  });

  // agenda a consulta

  $(".form-agenda-consulta").submit(function (e) {
    e.preventDefault();
    $.ajax({
      url: `./assets/php/controllers/consultas${exetensao}`,
      method: "POST",
      data: $(".form-agenda-consulta").serialize(),
      success: function (data) {
        if (data == 200) {
          $(".res-2").html('<div class="alert alert-primary">consulta agendada</div>');
          recarregar(1500);
        } else {
          $(".res-2").html('<div class="alert alert-danger">' + data + "</div>");
        }
      },
    });
  });

  // realizar consulta
  $(".btn-realizar").click(function () {
    idConsulta = $(this).attr("name");
    idEstado = $(this).attr("title");
    $.ajax({
      url: `./assets/php/controllers/consultas${exetensao}?idConsulta=${idConsulta}&acao=realizar`,
      method: "GET",
      data: {
        estado: idEstado,
      },
      success: function (data) {
        if (data == 200) {
          $(".resposta").html(
            '<div class="alert alert-info">Consulta realizada.</div>'
          );
          setTimeout(() => {
            location.reload();
          }, 3000);
        } else {
          $(".resposta").html(
            '<div class="alert alert-danger">' + data + "</div>"
          );
        }
      },
    });
  });

  // Marcar a consulta
  $(".btn-marcar").click(function () {
    idConsulta = $(this).attr("name");
    idEstado = $(this).attr("title");
    $.ajax({
      url: `./assets/php/controllers/consultas${exetensao}?idConsulta=${idConsulta}&acao=marcar`,
      method: "GET",
      data: {
        estado: idEstado,
      },
      success: function (data) {
        if (data == 200) {
          $(".resposta").html(
            '<div class="alert alert-info">Consulta marcada</div>'
          );
          setTimeout(() => {
            location.reload();
          }, 3000);
        } else {
          $(".resposta").html(
            '<div class="alert alert-danger">' + data + "</div>"
          );
        }
      },
    });
  });

  //Mostra o médico que reaizaráa consulta
  $("#local").change(function () {
    var valor = $("#local").val();

    $.ajax({
      url: `./assets/php/controllers/consultas${exetensao}`,
      method: "POST",
      Headers: {
        "Content-Type": "text/json",
      },
      data: {
        local: valor,
        acao: "medico-consulta",
      },
      success: (data) => {
        //const dados = [data]
        // console.log(data)
        $("#m").html(data);
      },
    });
  });

  /**
   * ************************************* MENSAGENS *****************************
   */

  // conta mensagens
  /*   setInterval(() => {
      $.ajax({
        url: `./assets/php/controllers/mensages${exetensao}`,
        method: "POST",
        data: {
          acao: "contar",
        },
        success: function (data) {
          $(".mensagem-num").html(data);
          $(".sms").html(data);
          //alert(data)
        },
      });
    }, 1000); */

  // show mensgaem
  /* setInterval(() => {
    $.ajax({
      url: `./assets/php/controllers/mensages${exetensao}`,
      method: "POST",
      data: {
        acao: "show",
      },
      success: function (data) {
        $(".ver-sms").html(data);
      },
    });
  }, 1000);
 */


  /* ============================= PRODUTOS ========== */

  var btn_produto = $('.btn-produto')
  var div_produto = $('.produtos')

  btn_produto.click(function () {
    div_produto.fadeToggle()
  })

})