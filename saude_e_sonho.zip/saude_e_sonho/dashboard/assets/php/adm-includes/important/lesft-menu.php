  <aside id="sidebar" class="sidebar">

    <ul class="sidebar-nav" id="sidebar-nav">

      <?php

      if ($_SESSION['categoria_funcionario'] == 'Admnistrador') { ?>
        <li class="nav-item">
          <a class="nav-link " href="index.php">
            <i class="bi bi-grid"></i>
            <span>Dashboard</span>
          </a>
        </li><!-- End Dashboard Nav -->

        <li class="nav-item">
          <a class="nav-link collapsed" data-bs-target="#components-nav" data-bs-toggle="collapse" href="#">
            <i class="bi bi-people"></i><span>Funcionários</span><i class="bi bi-chevron-down ms-auto"></i>
          </a>
          <ul id="components-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
            <li>
              <a href="./funcionarios.php#novo">
                <i class="bi bi-circle"></i><span>Lista</span>
              </a>
            </li>
            <li>
              <a href="./funcionarios.php#categorias">
                <i class="bi bi-circle"></i><span>Categorias</span>
              </a>
            </li>


          </ul>
        </li><!-- End Components Nav -->

        <li class="nav-item">
          <a class="nav-link collapsed" data-bs-target="#forms-nav" data-bs-toggle="collapse" href="#">
            <i class="bi bi-heart"></i><span>Clínicas</span><i class="bi bi-chevron-down ms-auto"></i>
          </a>
          <ul id="forms-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
            <li>
              <a href="./clinicas.php">
                <i class="bi bi-circle"></i><span>Listar</span>
              </a>
            </li>
            <li>
              <a href="./clinicas.php#nova-especialidade">
                <i class="bi bi-circle"></i><span>Nova especialidades</span>
              </a>
            </li>


          </ul>
        </li><!-- End Forms Nav -->


        <li class="nav-item">
          <a class="nav-link collapsed" data-bs-target="#icons-nav" data-bs-toggle="collapse" href="#">
            <i class="bi bi-hourglass"></i><span>Médicos</span><i class="bi bi-chevron-down ms-auto"></i>
          </a>
          <ul id="icons-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
            <li>
              <a href="./medicos.php">
                <i class="bi bi-circle"></i><span>Listagem</span>
              </a>
            </li>

            <li>
              <a href="./medicos.php#nova-certificacao">
                <i class="bi bi-circle"></i><span>Adicionar certificações</span>
              </a>
            </li>
          </ul>
        </li><!-- End Icons Nav -->

        <li class="nav-heading">Outros</li>
      <?php } ?>

      <li class="nav-item">
        <a class="nav-link collapsed" href="./pacientes.php">
          <i class="bi bi-person"></i>
          <span>Pacientes</span>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link collapsed" href="./consultas.php">
          <i class="bi bi-thermometer-low"></i>
          <span>Consultas</span>
        </a>
      </li>


      <?php

      if ($_SESSION['categoria_funcionario'] == 'Admnistrador') { ?>

        <li class="nav-item">
          <a class="nav-link collapsed" data-bs-target="#components-loja" data-bs-toggle="collapse" href="#">
            <i class="bi bi-shop"></i><span>Loja</span><i class="bi bi-chevron-down ms-auto"></i>
          </a>
          <ul id="components-loja" class="nav-content collapse " data-bs-parent="#sidebar-nav">
            <li>
              <a href="./produtos.php">
                <i class="bi bi-minecart-loaded"></i><span>Produtos</span>
              </a>
            </li>
            <li>
              <a href="./pedidosCompras.php">
                <i class="bi bi-slack"></i><span>Pedidos</span>
              </a>
            </li>
          </ul>
        </li>
      <?php } ?>
      <!-- End Components Nav -->
      <!--  -->
      <!-- End Profile Page Nav -->

      <!-- <li class="nav-item">
        <a class="nav-link collapsed" href="pages-contact.php">
          <i class="bi bi-envelope"></i>
          <span>Contactos</span>
        </a>
      </li> -->
      <!-- End Contact Page Nav -->
      <!-- 
      <li class="nav-item">
        <a class="nav-link collapsed" href="pages-register.php">
          <i class="bi bi-card-list"></i>
          <span>Registro ADM</span>
        </a>
      </li> -->
      <!-- End Register Page Nav -->

    </ul>

  </aside>