<?php
function estado_0($BD, $idd, $estado)
{
  $select = $BD->query("SELECT *FROM marcacao_consultas 
    INNER JOIN especialidades ON especialidades.idespecialidades = marcacao_consultas.id_especialidade
    INNER JOIN pacientes ON pacientes.idpacientes = marcacao_consultas.id_paciente
    INNER JOIN clinicas ON clinicas.idclinicas = marcacao_consultas.id_clinica
    INNER JOIN funcionarios ON funcionarios.idfuncionarios = marcacao_consultas.id_medico
    WHERE  marcacao_consultas.id_paciente = '" . $idd . "' AND estado = '$estado'
    ");

  while ($de = $select->fetch()) { ?>
    <br>
    <div class="mt-1">
      <div class="text-lead card-header bg-dark text-white card-consultas">
        <?= $de->nome_paciente ?>, solicitou um consulta na área de "<b><?= $de->designacao_especialidade ?></b>". Para a clínica <b><?= $de->designacao_clinica ?></b>
        <br>
        <b>Motivo:</b>
        <?= $de->motivo ?>
        <br>
        <b>Endereço: </b> <?= $de->endereco ?>
      </div>

      <div class="card mt-2 border-0">
        <div class="card-header bg-danger">
          <div class="card-title text-white">
            <h5>Consulta Cancelada</h5>
          </div>
        </div>

        <div class="card-body shadow-sm">
          <div class="card-subtitle">
            <h5 class="text-danger"><b>Detalhes</b></h5>
          </div>
          <div class="card-text text-lead text-dark">

            <p class="text-dark"><b> Cancelamos a sua solicitação de consulta. Verificamos alguns incumprimentos tais como:</b></p>
            <p>
            <ul class="text-danger">
              <li>Consultas repetidas.</li>
              <li>Morada não específicado.</li>
              <li>Tipo de consulta não específicado.</li>
              <li>Motivo da consulta não específicado.</li>
            </ul>
            <span>
              data da solicitação: <?= $de->data_solicitação_consulta ?>
              <br>
              data do cancelamento: <?= $de->data_feedback ?>
            </span>
            </p>
          </div>
        </div>
      </div>
    </div>
  <?php
  }
}
function estado_1($BD, $idd, $estado)
{

  $select = $BD->query("SELECT *FROM marcacao_consultas 
    INNER JOIN especialidades ON especialidades.idespecialidades = marcacao_consultas.id_especialidade
    INNER JOIN pacientes ON pacientes.idpacientes = marcacao_consultas.id_paciente
    INNER JOIN clinicas ON clinicas.idclinicas = marcacao_consultas.id_clinica
    INNER JOIN funcionarios ON funcionarios.idfuncionarios = marcacao_consultas.id_medico
    WHERE  marcacao_consultas.id_paciente = '" . $idd . "' AND estado = '$estado'
    ");

  while ($de = $select->fetch()) { ?>
    <br>
    <div class="mt-1">

      <div class="text-lead card-header bg-dark text-white card-consultas">
        <?= $de->nome_paciente ?>, solicitou um consulta na área de "<b><?= $de->designacao_especialidade ?></b>". Para a clínica <b><?= $de->designacao_clinica ?></b>
        <br>
        <b>Motivo:</b>
        <?= $de->motivo ?>
        <br>
        <b>Endereço: </b> <?= $de->endereco ?>
      </div>

      <div class="card shadow-sm mt-2 border-0">
        <div class="card-header card-title bg-warning text-dark">
          <h5>Consulta pendente</h5>
        </div>
        <div class="card-body shadow-sm bg-light">
          <h5 class="text-dark"><b>Detalhes</b></h5>
          <p class="text-muted">Alguns motivos da pendência da sua consula:</p>
          <ul class="text-dark">
            <li>A sua ordem ainda não chegou.</li>
            <li>A sua consulta está em análise.</li>
            <li>A sua consulta ainda não chegou no servidor.</li>
          </ul>
          <span class="text-dark">
            Data da solicitação: <?= $de->data_solicitação_consulta ?>
          </span>
        </div>
      </div>
    </div>
  <?php
  }
}
function estado_2($BD, $idd, $estado)
{

  $select = $BD->query("SELECT *FROM marcacao_consultas 
    INNER JOIN especialidades ON especialidades.idespecialidades = marcacao_consultas.id_especialidade
    INNER JOIN pacientes ON pacientes.idpacientes = marcacao_consultas.id_paciente
    INNER JOIN clinicas ON clinicas.idclinicas = marcacao_consultas.id_clinica
    INNER JOIN funcionarios ON funcionarios.idfuncionarios = marcacao_consultas.id_medico
    WHERE  marcacao_consultas.id_paciente = '" . $idd . "' AND estado = '$estado'
    ");

  while ($de = $select->fetch()) { ?>
    <br>
    <div class="mt-1">

      <div class="text-lead card-header bg-dark text-white card-consultas">
        <?= $de->nome_paciente ?>, solicitou um consulta na área de "<b><?= $de->designacao_especialidade ?></b>". Para a clínica <b><?= $de->designacao_clinica ?></b>
        <br>
        <b>Motivo:</b>
        <?= $de->motivo ?>
        <br>
        <b>Endereço: </b> <?= $de->endereco ?>
      </div>
      <div class="card mt-2 border-0">
        <div class="card-header bg-info">
          <div class="card-title text-white">
            <h5>Consulta Agendada</h5>
          </div>
        </div>

        <div class="card-body shadow-sm">
          <div class="card-subtitle text-dark">
            <h5><b>Detalhes</b></h5>
          </div>
          <div class="card-text text-lead ">
            <div class="alert text-info"> <?= $de->info ?></div>
            <div class="text-lead">
              <p class="text-center mb-2 text-dark">
                A sua consulta foi agenda com médico <b class="text-info"><?= $de->nome_funcionario ?></b>
                na clínica <b class="text-info"><?= $de->designacao_clinica ?></b>, localizdo em <b class="text-info"><?= $de->id_localidade ?></b>
              </p>
            </div>
            <span class="text-dark">
              <b>Solitado aos:</b> <?= $de->data_solicitação_consulta ?>
              <br>
              <b>Analisado aos:</b> <?= $de->data_feedback ?>
            </span>
            <hr>
            <p class="text-center text-info">Por favor aguarde a marcação</p>
          </div>
        </div>
      </div>
    </div>
  <?php
  }
}

function estado_3($BD, $idd, $estado)
{

  $select = $BD->query("SELECT *FROM marcacao_consultas 
    INNER JOIN especialidades ON especialidades.idespecialidades = marcacao_consultas.id_especialidade
    INNER JOIN pacientes ON pacientes.idpacientes = marcacao_consultas.id_paciente
    INNER JOIN clinicas ON clinicas.idclinicas = marcacao_consultas.id_clinica
    INNER JOIN funcionarios ON funcionarios.idfuncionarios = marcacao_consultas.id_medico
    WHERE  marcacao_consultas.id_paciente = '" . $idd . "' AND estado = '$estado'
    ");

  while ($de = $select->fetch()) { ?>
    <br>
    <div class="mt-1">
      <div class="text-lead card-header bg-dark text-white card-consultas">
        <?= $de->nome_paciente ?>, solicitou um consulta na área de "<b><?= $de->designacao_especialidade ?></b>". Para a clínica <b><?= $de->designacao_clinica ?></b>
        <br>
        <b>Motivo:</b>
        <?= $de->motivo ?>
        <br>
        <b>Endereço: </b> <?= $de->endereco ?>
      </div>

      <div class="card mt-2 border-0">
        <div class="card-header bg-success">
          <div class="card-title text-white">
            <h5>Consulta Marcada</h5>
          </div>
        </div>

        <div class="card-body shadow-sm">
          <div class="card-subtitle text-dark">
            <h5><b>Detalhes</b></h5>
          </div>
          <div class="card-text text-lead ">
            <div class="alert text-success"> <?= $de->info ?></div>
            <div class="text-lead">
              <p class="text-center mb-2 text-dark">
                A sua consulta foi marcada com médico <b class="text-success"><?= $de->nome_funcionario ?></b>
                na clínica <b class="text-success"><?= $de->designacao_clinica ?></b>, localizdo em <b class="text-success"><?= $de->id_localidade ?></b>
              </p>
            </div>
            <span class="text-dark">
              <b>Solitado aos:</b> <?= $de->data_solicitação_consulta ?>
              <br>
              <b>Analisado aos:</b> <?= $de->data_feedback ?>
            </span>

          </div>
        </div>
      </div>

    </div>

  <?php
  }
}

function estado_4($BD, $idd, $estado)
{

  $select = $BD->query("SELECT *FROM marcacao_consultas 
    INNER JOIN especialidades ON especialidades.idespecialidades = marcacao_consultas.id_especialidade
    INNER JOIN pacientes ON pacientes.idpacientes = marcacao_consultas.id_paciente
    INNER JOIN clinicas ON clinicas.idclinicas = marcacao_consultas.id_clinica
    INNER JOIN funcionarios ON funcionarios.idfuncionarios = marcacao_consultas.id_medico
    WHERE  marcacao_consultas.id_paciente = '" . $idd . "' AND estado = '$estado'
    ");

  while ($de = $select->fetch()) { ?>
    <br>
    <div class="mt-1">

      <div class="text-lead card-header bg-dark text-white card-consultas">
        <?= $de->nome_paciente ?>, solicitou um consulta na área de "<b><?= $de->designacao_especialidade ?></b>". Para a clínica <b><?= $de->designacao_clinica ?></b>
        <br>
        <b>Motivo:</b>
        <?= $de->motivo ?>
        <br>
        <b>Endereço: </b> <?= $de->endereco ?>
      </div>
      <div class="card shadow-sm mt-2 border-0 consulta-4">
        <div class="card-header card-title bg-primary text-white">
          <h5>Você realizou esta consulta</h5>
        </div>
        <div class="card-body shadow-sm">
          <h5 class="text-dark"><b>Aguarde ou veja a Prescrição Médica</b></h5>

          <div class="text-dark text-center">
            Data da solicitação: <?= $de->data_solicitação_consulta ?>
            <br>
            Preescrito aos : <?= $de->data_feedback ?>
          </div>
          <p class="text-primary text-center">Clinica: <?= $de->designacao_clinica ?>. Por Médico: <span class="text-dark"><?= $de->nome_funcionario ?></span> </p>
        </div>
      </div>

    </div>

  <?php
  }
}

function estado_5($BD, $idd, $estado)
{

  $select = $BD->query("SELECT *FROM marcacao_consultas 
    INNER JOIN especialidades ON especialidades.idespecialidades = marcacao_consultas.id_especialidade
    INNER JOIN pacientes ON pacientes.idpacientes = marcacao_consultas.id_paciente
    INNER JOIN clinicas ON clinicas.idclinicas = marcacao_consultas.id_clinica
    INNER JOIN funcionarios ON funcionarios.idfuncionarios = marcacao_consultas.id_medico
    WHERE  marcacao_consultas.id_paciente = '" . $idd . "' AND estado = '$estado'
    ");

  while ($de = $select->fetch()) { ?>
    <br>
    <div class="mt-1">

      <div class="text-lead card-header bg-dark text-white card-consultas">
        <?= $de->nome_paciente ?>, solicitou um consulta na área de "<b><?= $de->designacao_especialidade ?></b>". Para a clínica <b><?= $de->designacao_clinica ?></b>
        <br>
        <b>Motivo:</b>
        <?= $de->motivo ?>
        <br>
        <b>Endereço: </b> <?= $de->endereco ?>
      </div>

      <div class="card shadow-sm mt-2 border-0">
        <div class="card-header card-title bg-info text-white">
          <h5>Você realizou esta consulta</h5>
        </div>
        <div class="card-body shadow-sm">
          <h5 class="text-dark"><b>Prescrição Médica</b></h5>
          <p class="text-muted">
            <b class="text-info"> <?= $de->info ?></b>
          </p>
          <div class="text-dark text-center">
            Data da solicitação: <?= $de->data_solicitação_consulta ?>
            <br>
            Realizado aos : <?= $de->data_feedback ?>
          </div>
          <hr>
          <p class="text-center text-info">Por favor aguarde a preescrição.</p>

        </div>
      </div>
    </div>
<?php
  }
}
?>