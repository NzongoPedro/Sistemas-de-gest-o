<div class="modal fade" id="ModalClinica" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <div class="card">
          <div class="card-body">
            <h5 class="card-title">Cadastrar Clínicas</h5>

            <!-- Floating Labels Form -->
            <form class="row g-3 form-nova-clinica">
              <div class="col-md-6">
                <div class="form-floating">
                  <input type="text" name="nome" class="form-control" id="floatingName" placeholder="Designação da clínica">
                  <label for="floatingName">Nome da Clínica</label>
                </div>
              </div>
              <div class="col-md-6">
                <div class="form-floating">
                  <input type="tel" name="telefone" class="form-control" id="floatingName" placeholder="Telefone">
                  <label for="floatingName">Telefone</label>
                </div>
              </div>
              <div class="col-md-6">
                <div class="form-floating">
                  <input type="email" name="email" class="form-control" id="floatingEmail" placeholder="E-mail">
                  <label for="floatingEmail">E-mail</label>
                </div>
              </div>

              <div class="col-md-6">
                <div class="form-floating">
                  <input type="text" name="localizacao" class="form-control" id="floatingLocal" placeholder="Localização">
                  <label for="floatingLocal">Localização</label>
                </div>
              </div>

              <div class="col-md-6">
                <div class="form-floating">
                  <input type="tel" name="nif" class="form-control" id="floatingSenha" placeholder="Nº Fiscal">
                  <label for="floatingSenha">NIF</label>
                </div>
              </div>

              <div class="col-md-6">
                <div class="form-floating">
                  <select name="especialidade" class="form-select" aria-label="Default select example">
                    <option selected>Especialidades</option>
                    <?php

                    $l = $BD->query("SELECT *FROM especialidades ORDER BY designacao_especialidade");
                    while ($local = $l->fetch()) {
                      echo '<option value="' . $local->idespecialidades . '">' . $local->designacao_especialidade
                        . '</option>';
                    }
                    ?>
                  </select>
                </div>
              </div>

              <div class="text-center mt-4 response-clinicas"></div>
              <div class="text-center mt-4">
                <input type="hidden" name="acao" value="save">
                <button type="reset" class="btn btn-light">Limpar</button>
                <button type="submit" class="btn bg-btn">Cadastrar</button>
              </div>
            </form><!-- End floating Labels Form -->

          </div>
        </div>
      </div>
    </div>
  </div>
</div>