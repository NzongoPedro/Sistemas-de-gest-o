<div class="modal fade" id="mf" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="mfLabel" aria-hidden="true">
  <div class="modal-dialog  modal-xl  modal-dialog-scrollable">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body ss">
        <div class="pagetitle">

          <section class="section">
            <div class="row">
              <div class="col-lg-12">

                <div class="card">
                  <div class="card-body">
                    <div class="card-title">
                      Tabela de funcionários
                      <div class="float-end">
                        <button type="button" class="btn btn-sm bg-btn mf" data-bs-toggle="modal" data-bs-target="#staticBackdrop"><i class="bi bi-plus mt-1"></i> Novo</button>
                        <a href="./docs/funcionarios.php?funcionarios" class="btn btn-sm bg-btn" target="_black"><i class="bi bi-file-pdf mt-1"></i> Exportar PDF</a>
                        <!--  <button type="button" class="btn btn-sm bg-btn trucate-funcionario"><i class="bi bi-trash mt-1"></i> Apagar todos</button> -->
                      </div>
                    </div>


                    <!--   <div class="search-bar">
                  <form class="search-form d-flex align-items-center pesquisar-funcionario">
                    <input class="campo-pesquisa-funcionario" type="search" name="query" placeholder="Pesquisar Funcionário" title="pesquisar">
                    <button type="button" title="Search" class="bg-btn"><i class="bi bi-search"></i></button>
                  </form>
                </div> -->
                    <!-- Table with stripped rows -->
                    <table class="table table-striped table-sm datatable">
                      <thead>
                        <tr>
                          <th scope="col">#</th>
                          <th scope="col">Nome</th>
                          <th scope="col">Categoria</th>
                          <th scope="col">Email</th>
                          <th scope="col">Telefone</th>
                          <th scope="col">Opções</th>
                        </tr>
                      </thead>
                      <tbody class="data-table-funcionari">
                        <?= $funcionario->viewFuncionario($BD) ?>
                      </tbody>

                    </table>
                    <!-- End Table with stripped rows -->

                  </div>
                </div>

              </div>
            </div>
          </section>
          <section class="section">
            <div class="row">

              <div class="col-lg-6" id="categorias">
                <div class="card">
                  <div class="card-body">
                    <h5 class="card-title">Adicionar categoria de funcionário </h5>

                    <!-- Multi Columns Form -->
                    <form class="row g-3 form-nova-categoria">
                      <div class="col-md-12">
                        <label for="inputName5" class="form-label">Designação da categoria</label>
                        <input type="text" class="form-control" name="categoria" required>
                      </div>
                      <div class="text-center response-categorias mt-4 mb-2"></div>
                      <div class="text-center mt-4">
                        <input type="hidden" name="acao" value="save-categoria">
                        <button type="submit" class="btn btn-sm bg-btn">Adicionar</button>
                      </div>
                    </form><!-- End Multi Columns Form -->

                  </div>
                </div>
              </div>

              <div class="col-lg-6">

                <div class="card">
                  <div class="card-body">
                    <h5 class="card-title">Todas as categorias</h5>
                    <form action="" class="row form-edit-categoria" style="display:none">
                      <div class="form-group col-8 mb-3">
                        <input type="text" name="designacao" class="form-control form-control-sm campo" placeholder=" Categoria" required minlength="3">
                      </div>
                      <div class="mb-3 col-auto">
                        <button type="submit" class="btn btn-sm bg-btn btn-edit">salvar</button>
                        <input type="hidden" name="id" class="campo-id">
                        <input type="hidden" name="acao" value="update-categoria">
                      </div>
                    </form>
                    <!-- Vertical Form -->
                    <div class="ss" tabindex="0" style="max-height: 155px; overflow:hidden; overflow-y: scroll;">

                      <table class="table table-borderless table-striped table-hover">
                        <thead>
                          <tr>
                            <th scope="col">#</th>
                            <th scope="col">Desginação</th>
                            <th scope="col">Ação</th>

                          </tr>
                        </thead>
                        <tbody class="data-table-categoriaa">
                          <?= $funcionario->viewcategoria($BD) ?>
                        </tbody>
                      </table>
                    </div>

                  </div>
                </div>

              </div>
            </div>
          </section>
        </div>
      </div>

    </div>
  </div>
</div>