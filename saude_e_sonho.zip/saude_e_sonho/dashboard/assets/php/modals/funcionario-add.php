<div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <div class="card">
          <div class="card-body">
            <h5 class="card-title">Cadastrar Funcionários</h5>

            <!-- Floating Labels Form -->
            <form class="row g-3 form-novo-funcionario">
              <div class="col-md-6">
                <div class="form-floating">
                  <input type="text" name="nome" class="form-control" id="floatingName" placeholder="Nome">
                  <label for="floatingName">Nome do funcionário</label>
                </div>
              </div>
              <div class="col-md-6">
                <div class="form-floating">
                  <input type="tel" name="telefone" class="form-control" id="floatingNam" placeholder="Telefone">
                  <label for="floatingNam">Telefone</label>
                </div>
              </div>
              <div class="col-md-6">
                <div class="form-floating">
                  <input type="email" name="email" class="form-control" id="floatingEmail" placeholder="E-mail">
                  <label for="floatingEmail">E-mail</label>
                </div>
              </div>

              <div class="col-md-6">
                <div class="form-floating">
                  <select name="id-categoria" class="form-select" aria-label="Default select example">
                    <option selected>Categoria</option>
                    <?= $funcionario->listaCategorias($BD) ?>
                  </select>
                </div>
              </div>
              <div class="col-md-6">
                <div class="form-floating">
                  <input type="password" name="senha" class="form-control" id="floatingSenha" placeholder="Palavra-passe">
                  <label for="floatingSenha">Palavra-passe</label>
                </div>
              </div>
              <div class="col-md-6">
                <div class="form-floating">
                  <textarea class="form-control" id="floatingMorada" name="morada" cols="30" required></textarea>
                  <label for="floatingMorada">morada</label>
                </div>
              </div>
              <div class="text-center mt-4 response-funcionario"></div>
              <div class="text-center mt-4">
                <input type="hidden" name="acao" value="save">
                <button type="reset" class="btn btn-light">Limpar</button>
                <button type="submit" class="btn bg-btn">Cadastrar</button>
              </div>
            </form><!-- End floating Labels Form -->

          </div>
        </div>
      </div>
    </div>
  </div>
</div>