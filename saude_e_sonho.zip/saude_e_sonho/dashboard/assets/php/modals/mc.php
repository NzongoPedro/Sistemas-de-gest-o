<div class="modal fade" id="mc" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="mcLabel" aria-hidden="true">
  <div class="modal-dialog  modal-xl  modal-dialog-scrollable">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body ss">
        <div class="pagetitle">

          <section class="section">
            <div class="row">
              <div class="col-lg-12">

                <div class="card">
                  <div class="card-body">
                    <div class="card-title">
                      Todas as clínicas
                      <div class="float-end">
                        <button type="button" class="btn bg-btn mf" data-bs-toggle="modal" data-bs-target="#ModalClinica"><i class="bi bi-plus mt-1"></i> Nova</button>
                      </div>
                    </div>



                    <!-- Table with stripped rows -->
                    <table class="table">

                      <thead>
                        <tr>

                          <th scope="col">Designação</th>
                          <th scope="col">Email</th>
                          <th scope="col">NIF</th>
                          <th scope="col">Telefone</th>
                          <th scope="col">Especialidade</th>
                          <th scope="col">Localidade</th>
                        </tr>
                      </thead>
                      <tbody class="data-table-clinica">

                      </tbody>
                    </table>
                    <!-- End Table with stripped rows -->

                  </div>
                </div>

              </div>
            </div>
          </section>
          <section class="section">
            <div class="row">
              <div class="col-lg-5" id="nova-especialidade">


                <div class="card">
                  <div class="card-body">
                    <h5 class="card-title">Adicionar especialidade </h5>

                    <!-- Multi Columns Form -->
                    <form class="row g-3 form-nova-especialidade">
                      <div class="col-md-12">
                        <label for="inputName5" class="form-label">Designação da especialidade</label>
                        <input type="text" class="form-control" name="nome" required>
                      </div>
                      <div class="text-center mt-4 response-especialidades"></div>
                      <div class="text-center">
                        <input type="hidden" name="acao" value="save-categoria">
                        <button type="submit" class="btn bg-btn">Adicionar</button>
                      </div>
                    </form><!-- End Multi Columns Form -->

                  </div>
                </div>

              </div>

              <div class="col-lg-7">

                <div class="card">
                  <div class="card-body">

                    <h5 class="card-title">Todas as especialidades</h5>
                    <form action="" class="row form-edit-especialidade" style="display:none">
                      <div class="form-group col-8 mb-3">
                        <input type="text" name="especialidade" class="form-control form-control-sm campo" placeholder=" Especialidade" required minlength="3">
                      </div>
                      <div class="mb-3 col-auto">
                        <button type="submit" class="btn btn-sm bg-btn btn-edit">salvar</button>
                        <input type="hidden" name="id" class="campo-id">
                        <input type="hidden" name="acao" value="update-categoria">
                      </div>
                    </form>

                    <!-- Vertical Form -->

                    <table class="table table-borderless table-striped table-borderless datatable">
                      <thead>
                        <tr>
                          <th scope="col">#</th>
                          <th scope="col">Desginação</th>
                          <th scope="col">Ação</th>

                        </tr>
                      </thead>
                      <tbody>

                        <?= $clinica->viewEspecialidadess($BD) ?>

                      </tbody>
                    </table>
                  </div>



                </div>
              </div>

            </div>


        </div>

      </div>

    </div>
  </div>
</div>