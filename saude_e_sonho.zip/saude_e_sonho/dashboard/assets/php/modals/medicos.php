<div class="modal fade" id="ModalMedico" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <div class="card">
          <div class="card-body">
            <h5 class="card-title">Cadastrar Medico</h5>

            <!-- Floating Labels Form -->
            <form class="row g-3 form-novo-medico">

              <div class="col-md-6">
                <div class="form-floating">
                  <input type="text" name="nome" class="form-control" id="floatingName" required placeholder="Nome médico">
                  <label for="floatingName">Nome do médico</label>
                </div>
              </div>

              <div class="col-md-6">
                <div class="form-floating">
                  <input type="tel" name="telefone" class="form-control" id="floatingName" required placeholder="Telefone">
                  <label for="floatingName">Telefone</label>
                </div>
              </div>

              <div class="col-md-4">
                <div class="form-floating">
                  <input type="text" name="bi" class="form-control" id="floatingName" required placeholder="Nº BI">
                  <label for="floatingName">Nº BI</label>
                </div>
              </div>

              <div class="col-md-4">
                <div class="form-floating">
                  <input type="date" name="data" class="form-control" id="floatingName" required placeholder="Nº BI">
                  <label for="floatingName">Data de nascimento</label>
                </div>
              </div>

              <div class="col-md-4">
                <div class="form-floating">
                  <input type="email" name="email" class="form-control" id="floatingEmail" required placeholder="E-mail">
                  <label for="floatingEmail">E-mail</label>
                </div>
              </div>

              <div class="col-md-6">
                <div class="form-floating">
                  <input type="text" name="localizacao" class="form-control" id="floatingLocal" required placeholder="Morada">
                  <label for="floatingLocal">Morada</label>
                </div>
              </div>

              <div class="col-md-6">
                <div class="form-floating">
                  <select name="certificacoes" class="form-select" aria-label="Default select example">
                    <option selected>Certificacoes</option>
                    <?php

                    $l = $BD->query("SELECT *FROM certificacoes ORDER BY idcertificacoes");
                    while ($local = $l->fetch()) {
                      echo '<option value="' . $local->idcertificacoes . '">' . $local->designacao_certificacao
                        . '</option>';
                    }
                    ?>
                  </select>
                </div>
              </div>

              <div class="col-md-6">
                <div class="form-floating">
                  <select name="especialidade" class="form-select" aria-label="Default select example">
                    <option selected>Especialidades</option>
                    <?php

                    $l = $BD->query("SELECT *FROM especialidades ORDER BY designacao_especialidade");
                    while ($local = $l->fetch()) {
                      echo '<option value="' . $local->idespecialidades . '">' . $local->designacao_especialidade
                        . '</option>';
                    }
                    ?>
                  </select>
                </div>
              </div>

              <div class="col-md-6">
                <div class="form-floating">
                  <select name="clinica" class="form-select" aria-label="Default select example">
                    <option selected>Clínicas</option>
                    <?php

                    $l = $BD->query("SELECT *FROM clinicas ORDER BY designacao_clinica");
                    while ($local = $l->fetch()) {
                      echo '<option value="' . $local->idclinicas . '">' . $local->designacao_clinica
                        . '</option>';
                    }
                    ?>
                  </select>
                </div>
              </div>

              <div class="col-4 mb-3">
                <div class="form-floating">
                  <input type="text" name="numero" class="form-control" id="floatingN" required placeholder="Nº de ordem">
                  <label for="floatingN">Número de ordem</label>
                </div>

              </div>
              <div class="col-8 mb-3">
                <div class="form-floating">
                  <input class="form-control" type="file" id="floatingF" name="foto" required>
                  <label for="floatingF">Foto do médico</label>
                </div>
              </div>

              <div class="col-12">
                <textarea name="descricao" id="" cols="30" rows="2" placeholder="Descrição do médico" class="form-control"></textarea>
              </div>

              <div class="text-center mt-4 response-medicos"></div>
              <div class="text-center mt-4">
                <input type="hidden" name="acao" value="save">
                <button type="reset" class="btn btn-light">Limpar</button>
                <button type="submit" class="btn bg-btn">Cadastrar</button>
              </div>
            </form><!-- End floating Labels Form -->

          </div>
        </div>
      </div>
    </div>
  </div>
</div>