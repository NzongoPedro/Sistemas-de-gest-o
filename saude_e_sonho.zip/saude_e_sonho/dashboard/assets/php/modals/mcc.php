<div class="modal fade" id="mcc" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="mccLabel" aria-hidden="true">
  <div class="modal-dialog  modal-xl  modal-dialog-scrollable">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body ss">

        <div class="pagetitle">

          <section class="section">
            <div class="row">
              <div class="col-lg-12">

                <div class="card">
                  <div class="card-body">
                    <div class="card-title">
                      Consultas Solicitadas
                    </div>

                    <!-- Table with stripped rows -->
                    <table class="table datatable">

                      <thead>
                        <tr>
                          <th scope="col">#</th>
                          <th scope="col">Designacção</th>
                          <th scope="col">Paciente</th>
                          <th scope="col">Clínica</th>
                          <th scope="col">Estado</th>
                          <th scope="col">Opções</th>
                        </tr>
                      </thead>

                      <tbody class="data-consuelta">
                        <?= $consultas->show($BD, $funcionario->getId()) ?>
                      </tbody>
                    </table>
                    <!-- End Table with stripped rows -->

                  </div>
                </div>

              </div>
            </div>
          </section>

        </div>

      </div>

    </div>
  </div>
</div>