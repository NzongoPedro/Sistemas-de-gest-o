<?php

function contaCarrinho($BD, $cliente)
{
  $conta = $BD->query("SELECT sum(quantidade) as qtd FROM compras WHERE id_cliente = '$cliente' AND estado_compra = '0'");
  $resultado = $conta->fetch()->qtd;
  if ($resultado >= 100) {
    print '99+';
  } else {
    if ($resultado == 0) {
      $resultado = 0;
    }
    print $resultado;
  }
}

function listaCompras($BD)
{
  try {
    $query = "SELECT *FROM compras
    INNER JOIN pacientes ON compras.id_cliente = pacientes.idpacientes
    INNER JOIN produtos ON compras.id_produto = produtos.idproduto
    WHERE estado_compra !=  '0'
    ORDER BY idcompra DESC";
    $executar = $BD->query($query);
    if ($executar) {
      return json_encode($executar->fetchAll());
    }
  } catch (\Throwable $th) {
    return $th->getMessage();
  }
}

function estadoCompra($BD, $produto, $cliente, $estado)
{
  try {
    $query = "UPDATE compras SET estado_compra = '$estado', data_venda = '" . date('y-m-d') . "' WHERE idcompra = '$produto' AND id_cliente = '$cliente'";
    $update = $BD->query($query);
    if ($update) {
      print 200;
    }
  } catch (\Throwable $th) {
    print  $th->getMessage();
  }
}

function listarVendidos($BD, $cliente, $data_venda)
{
  try {
    $total = 0;
    $query =
      "SELECT *FROM compras
      INNER JOIN pacientes ON compras.id_cliente = pacientes.idpacientes
      INNER JOIN produtos ON compras.id_produto = produtos.idproduto
      WHERE id_cliente ='$cliente' AND data_venda = '$data_venda'";
    $executar = $BD->query($query);
    if ($executar) {
      while ($vendio = $executar->fetch()) {
        $total = $total + $vendio->preco_produto;
?>
        <div class="alert alert-light shadow-sm rounded-0 shadow-sm">
          <div class="float-right">
            <a href="#!" class="btn-sm text-success rounded-3" style="font-size: 25px;">
              <b class="bi-check"></b>
            </a>
          </div>
          <span><?= $vendio->nome_produto ?></span>
          <br>
          <span>
            <b class="ms-2">Preço: <?= number_format($vendio->preco_produto, 2, ',', '.') ?> Kzs</b>
          </span>
        </div>
<?php }
    }
    echo '<div class="text-right">
    <span class="btn badge rounded-pill bg-dark text-white">Total: ' . number_format($total, 2, ',', '.') . ' kzs </span>
    </div>';
  } catch (\Throwable $th) {
    return $th->getMessage();
  }
}

function menosNoCarrinho($BD, $idcompra)
{

  $qtd = $BD->query("SELECT quantidade as q FROM compras WHERE idcompra = '$idcompra'");
  $ttl = $BD->query("SELECT preco as t FROM compras WHERE idcompra = '$idcompra'");
  $Q = --$qtd->fetch()->q;
  if ($Q < 1) {
    $Q = 0;
  }
  $T =  ($ttl->fetch()->t * $Q);
  $T = number_format($T, 2, ',', '.');

  $update = $BD->query("UPDATE compras SET quantidade = '$Q', total ='$T' WHERE idcompra = '$idcompra'");
  if ($update) {
    print 200;
  }
}

function removePedido($BD, $idcompra)
{
  $DELETE = $BD->query("DELETE FROM compras WHERE idcompra ='$idcompra'");
  if ($DELETE) {
    print 200;
  }
}

function enviarPedido($BD, $idpaciente)
{
  try {
    $UP = $BD->query("UPDATE compras SET estado_compra = '1' WHERE id_cliente = '$idpaciente' AND estado_compra = '0'");
    if ($UP) {
      print 200;
    }
  } catch (\Throwable $th) {
    print $th->getMessage();
  }
}

if (isset($_GET['acao']) && $_GET['acao'] == 'count') {
  require '../env.php';
  $cliente = $_GET['idcliente'];
  contaCarrinho($BD, $cliente);
}
if (isset($_GET['acao']) && $_GET['acao'] == 'estado') {
  require '../env.php';
  $estado = filter_input(INPUT_GET, 'estado', FILTER_SANITIZE_NUMBER_INT);
  $produto = filter_input(INPUT_GET, 'produto', FILTER_SANITIZE_NUMBER_INT);
  $cliente = filter_input(INPUT_GET, 'cliente', FILTER_SANITIZE_NUMBER_INT);
  estadoCompra($BD, $produto, $cliente, $estado);
} else if (isset($_GET['acao']) && $_GET['acao'] == 'listar-vendidos') {
  require '../env.php';
  $cliente = filter_input(INPUT_GET, 'cliente', FILTER_SANITIZE_NUMBER_INT);
  $data_venda = filter_input(INPUT_GET, 'data');
  listarVendidos($BD, $cliente, $data_venda);
} else if (isset($_GET['acao']) && $_GET['acao'] == 'menos-no-carrinho') {
  require '../env.php';
  $idcompra = filter_input(INPUT_GET, 'idcompra', FILTER_SANITIZE_NUMBER_INT);
  menosNoCarrinho($BD, $idcompra);
} else if (isset($_GET['acao']) && $_GET['acao'] == 'remover-pedido') {
  require '../env.php';
  $idcompra = filter_input(INPUT_GET, 'idcompra', FILTER_SANITIZE_NUMBER_INT);
  removePedido($BD, $idcompra);
} else if (isset($_GET['acao']) && $_GET['acao'] == 'enviar-pedido') {
  require '../env.php';
  $idpaciente = filter_input(INPUT_GET, 'idpaciente', FILTER_SANITIZE_NUMBER_INT);
  enviarPedido($BD, $idpaciente);
}
/* require '../env.php';
print listaCompras($BD); */
