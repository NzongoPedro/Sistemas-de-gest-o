<?php
class localidades
{

  private $provincia;
  private $bairro;
  private $municipio;
  private $distrito;
  private $rua;
  private $table = 'localidades';
  public  $erros = null;

  # ############### GETT E SETT 
  public function setProvincia($d)
  {
    $this->provincia = $d;
  }
  public function setBairro($d)
  {
    $this->bairro = $d;
  }
  public function setMunicipio($d)
  {
    $this->municipio = $d;
  }
  public function setDistrito($d)
  {
    $this->distrito = $d;
  }
  public function setRua($d)
  {
    $this->rua = $d;
  }
  public function setTabela($d = 'localidades')
  {
    $this->table = $d;
  }


  public function getProvincia()
  {
    return $this->provincia;
  }
  public function getBairro()
  {
    return $this->bairro;
  }
  public function getMunicipio()
  {
    return $this->municipio;
  }
  public function getDistrito()
  {
    return $this->distrito;
  }
  public function getRua()
  {
    return $this->rua;
  }
  public function getTabela()
  {
    return $this->table;
  }

  ### Save IN BD

  public function save($BD)
  {
    try {
      $enviar = $BD->prepare("INSERT INTO {$this->table}(provincia, bairro, municipio, distrito, rua)
    VALUES(?,?,?,?,?)");

      $enviar->bindValue(1, $this->getProvincia());
      $enviar->bindValue(2, $this->getBairro());
      $enviar->bindValue(3, $this->getMunicipio());
      $enviar->bindValue(4, $this->getDistrito());
      $enviar->bindValue(5, $this->getRua());

      if ($enviar->execute()) {
        print 'ok';
      } else {
        print 'fail';
      }
    } catch (PDOException $erro) {
      print $erro->getMessage();
    }
  }

  ## View 
  public function view($BD)
  {
    try {
      $busca = $BD->query("SELECT *FROM {$this->table} ORDER BY idlocalidades DESC");
      while ($localidade = $busca->fetch()) : ?>

        <tr>
          <td><?= $localidade->idlocalidades ?></td>
          <td><?= $localidade->provincia ?></td>
          <td><?= $localidade->bairro ?></td>
          <td><?= $localidade->municipio ?></td>
          <td><?= $localidade->distrito ?></td>
          <td><?= $localidade->rua ?></td>
          <td scope="col">rem</td>
        </tr>
<?php endwhile;
    } catch (PDOException $erro) {
      print $erro->getMessage();
    }
  }
}

### instância

$local = new localidades;

if (isset($_POST['acao'])) {

  require '../env.php';
  $acao = $_POST['acao'];

  switch ($acao) {
    case 'save':
      $local->setProvincia(htmlspecialchars(filter_input(INPUT_POST, 'provincia')));
      $local->setBairro(htmlspecialchars(filter_input(INPUT_POST, 'bairro')));
      $local->setMunicipio(htmlspecialchars(filter_input(INPUT_POST, 'municipio')));
      $local->setDistrito(htmlspecialchars(filter_input(INPUT_POST, 'distrito')));
      $local->setRua(htmlspecialchars(filter_input(INPUT_POST, 'rua')));
      $local->save($BD);
      break;

    case 'view':
      $local->view($BD);
      break;
  }
}
