<?php

// contar consultas para o gráfico
function contaDadosconsultas($BD, $id)
{

  if ($_SESSION['categoria_funcionario'] == 'Médico') {
  $preescritos = $BD->query("SELECT *FROM marcacao_consultas WHERE estado = '5'");
  $prescrito = $preescritos->rowCount();
  $realizados = $BD->query("SELECT *FROM marcacao_consultas WHERE id_medico = '$id' AND estado = '4'")->rowCount();
  $cancelados = $BD->query("SELECT *FROM marcacao_consultas WHERE id_medico = '$id' AND estado = '0'")->rowCount();
  $pendentes = $BD->query("SELECT *FROM marcacao_consultas WHERE id_medico = '$id' AND estado = '1'")->rowCount();
  $agendados = $BD->query("SELECT *FROM marcacao_consultas WHERE id_medico = '$id' AND estado = '2'")->rowCount();
  $marcados = $BD->query("SELECT *FROM marcacao_consultas WHERE id_medico = '$id' AND estado = '3'")->rowCount();
  }else{
    $preescritos = $BD->query("SELECT *FROM marcacao_consultas WHERE estado = '5'");
    $prescrito = $preescritos->rowCount();
    $realizados = $BD->query("SELECT *FROM marcacao_consultas WHERE estado = '4'")->rowCount();
    $cancelados = $BD->query("SELECT *FROM marcacao_consultas WHERE estado = '0'")->rowCount();
    $pendentes = $BD->query("SELECT *FROM marcacao_consultas WHERE estado = '1'")->rowCount();
    $agendados = $BD->query("SELECT *FROM marcacao_consultas WHERE estado = '2'")->rowCount();
    $marcados = $BD->query("SELECT *FROM marcacao_consultas WHERE id_medico = '$id' AND estado = '3'")->rowCount();
  }

  
  $dados = array(
    '1' => $pendentes,
    '2' => $realizados,
    '3' => $agendados,
    '4' => $cancelados,
    '5' => $prescrito,
    '6' => $marcados,
  );

  return implode(',', $dados);
}
function contaDadosFuncionarios($BD)
{

  $_1 = $BD->query("SELECT *FROM funcionarios WHERE id_categoria_funcionario = '3'")->rowCount();
  $_2 = $BD->query("SELECT *FROM funcionarios WHERE id_categoria_funcionario = '2'")->rowCount();
  $_3 = $BD->query("SELECT *FROM funcionarios WHERE id_categoria_funcionario = '1'")->rowCount();

  $dados = array(
    '1' => $_1,
    '2' => $_2,
    '3' => $_3,
  );

  return implode(',', $dados);
}
