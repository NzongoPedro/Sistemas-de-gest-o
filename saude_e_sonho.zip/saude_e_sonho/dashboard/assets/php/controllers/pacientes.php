<?php

class pacientes
{
  private $id, $nome, $senha, $email, $telefone, $bi, $table = 'pacientes';
  public $erros = null;



  /**
   * Get the value of nome
   */
  public function getNome()
  {
    return $this->nome;
  }

  /**
   * Set the value of nome
   *
   * @return  self
   */
  public function setNome($nome)
  {
    $this->nome = $nome;

    return $this;
  }

  /**
   * Get the value of senha
   */
  public function getSenha()
  {
    return $this->senha;
  }

  /**
   * Set the value of senha
   *
   * @return  self
   */
  public function setSenha($senha)
  {
    $this->senha = $senha;

    return $this;
  }

  /**
   * Get the value of email
   */
  public function getEmail()
  {
    return $this->email;
  }

  /**
   * Set the value of email
   *
   * @return  self
   */
  public function setEmail($email)
  {
    $this->email = $email;

    return $this;
  }

  /**
   * Get the value of telefone
   */
  public function getTelefone()
  {
    return $this->telefone;
  }

  /**
   * Set the value of telefone
   *
   * @return  self
   */
  public function setTelefone($telefone)
  {
    $this->telefone = $telefone;

    return $this;
  }

  /**
   * Get the value of bi
   */
  public function getBi()
  {
    return $this->bi;
  }

  /**
   * Set the value of bi
   *
   * @return  self
   */
  public function setBi($bi)
  {
    $this->bi = $bi;

    return $this;
  }


  /**
   * Get the value of id
   */
  public function getId()
  {
    return $this->id;
  }

  /**
   * Set the value of id
   *
   * @return  self
   */
  public function setId($id)
  {
    $this->id = $id;

    return $this;
  }

  # Valida nome
  public function nomeValidate()
  {
    if (!preg_match("/^[a-zA-ZáÁéÉíÍóÓúÚàÀèÈìÌòÒùÙãÃõÕâÂêÊîÎôÔûÛçÇ ]*$/", $this->getNome()) || ltrim(strlen($this->getnome()) < 8) || $this->getnome() ==  "" || $this->getnome() == null || empty($this->getnome())) {
      $this->erros = 'O nome inserido não é válido.';
    }
  }

  # Validar Número de telefone
  public function telefoneValidate()
  {
    if (!is_numeric($this->getTelefone()) || !preg_match("/^[0-9]*$/", $this->getTelefone()) || 9 > strlen($this->getTelefone()) || 9 < strlen($this->getTelefone()) || $this->getTelefone()[0] != 9) {
      $this->erros = 'Número de  telefone inválido.';
    }
  }

  # Validdar E-mail
  public function emailValidate()
  {
    if (!filter_var($this->getEmail(), FILTER_VALIDATE_EMAIL)) {
      $this->erros = 'O E-mail inserido não é válido';
    }
  }

  // VERIFICA SE O USUARIO OU EMAIL JA EXISTE

  public function checkLogin($BD)
  {
    $check = $BD->query("SELECT *FROM {$this->table} WHERE email_paciente = '" . $this->getEmail() . "'");
    if ($check->rowCount() > 0) {
      $this->erros = 'O email inserido já está cadastrado.';
    }
  }

  public function checkFone($BD)
  {
    $check = $BD->query("SELECT *FROM {$this->table} WHERE telefone_paciente = '" . $this->getTelefone() . "'");
    if ($check->rowCount() > 0) {
      $this->erros = 'O Telefone inserido já está cadastrado.';
    }
  }

  public function checkBi($BD)
  {
    $check = $BD->query("SELECT *FROM {$this->table} WHERE BI_paciente = '" . $this->getBi() . "'");
    if ($check->rowCount() > 0) {
      $this->erros = 'O BI inserido já está cadastrado.';
    }
  }

  # savepaciente

  public function save($BD)
  {
    if ($this->erros == null) {
      try {
        $query = "INSERT INTO {$this->table}  
        (nome_paciente, telefone_paciente, BI_paciente, email_paciente, senha)
				VALUES(?,?,?,?,?)";

        $save = $BD->prepare($query);

        $save->bindValue(1, $this->getNome());
        $save->bindValue(2, $this->getTelefone());
        $save->bindValue(3, $this->getBi());
        $save->bindValue(4, $this->getEmail());
        $save->bindValue(5, md5($this->getSenha()));


        if ($save->execute()) {
          print 200;
        }
      } catch (PDOException $th) {
        print
          $th->getMessage();
      }
    } else {
      print $this->erros;
    }
  }

  #login 
  public function login($BD)
  {
    try {
      ## verfica seo emailexiste 
      $checkEmail = $BD->query("SELECT email_paciente FROM {$this->table} WHERE email_paciente = '" . $this->getEmail() . "'");
      if ($checkEmail->rowCount() > 0) {
        // Caso exista, verifica a senha
        $checkSenha = $BD->query("SELECT senha FROM {$this->table} WHERE senha = '" . $this->getSenha() . "'");
        if ($checkSenha->rowCount() > 0) {
        } else {
          $this->erros = 'A senha inserida está incorreta.';
        }
      } else {
        $this->erros = 'O e-mail inserido está incorreto.';
      }
    } catch (PDOException $err) {
      print $err->getMessage();
    }

    if ($this->erros == null) {
      $_SESSION['email_paciente'] = $this->getEmail();
      print 200;
    } else {
      print $this->erros;
    }
  }

  #dados
  public function dadosPacientes($BD)
  {

    $select = $BD->query("SELECT *FROM {$this->table} WHERE email_paciente = '" . $_SESSION['email_paciente'] . "'");
    while ($d = $select->fetch()) {
      $this->nome = $d->nome_paciente;
      $this->email = $d->email_paciente;
      $this->telefone = $d->telefone_paciente;
      $this->bi = $d->BI_paciente;
      $this->id = $d->idpacientes;
    }
  }

  #ver na dashboard
  public function show($BD)
  {
    $ver = $BD->query("SELECT *FROM pacientes ORDER BY nome_paciente ASC");

    // if ($_SESSION['categoria_funcionario'] == 'Admnistrador' || $_SESSION['categoria_funcionario'] == 'Médico') {
    while ($paciente = $ver->fetch()) { ?>

      <tr class="linha-<?= $paciente->idpacientes ?>">
        <td><?= $paciente->idpacientes ?></td>
        <td>
          <a href="./pacienteDetalhe.php?idPaciente=<?= $paciente->idpacientes ?>" class="text-dark">
            <?= $paciente->nome_paciente ?>
          </a>
        </td>
        <td><?= $paciente->BI_paciente ?></td>
        <td><?= $paciente->email_paciente ?></td>
        <td>

          <a href="#" class="text-danger" class="apagarP" id="<?= $paciente->idpacientes ?>" onclick="k('<?= $paciente->idpacientes ?>')">
            <i class="bi-trash"></i>
          </a>
        </td>
      </tr>
<?php
      //  }
    }
  }

  # delete 
  public function delete($BD, $id_paciente)
  {
    try {
      if ($BD->query("DELETE FROM pacientes WHERE idpacientes = '$id_paciente'")) {

        print 2010;
      } else {
        echo ('algo deu errado');
      }
    } catch (PDOException $th) {
      print $th->getMessage();
    }
  }

  // função para editar dados do paciente
  public function editar($BD, $ema)
  {
    $n = $this->getNome();
    $e = $this->getEmail();
    $t = $this->getTelefone();
    $b = $this->getBi();

    if ($this->erros == null) {
      try {
        $up = $BD->query("UPDATE pacientes SET nome_paciente = '$n', telefone_paciente = '$t', BI_paciente = '$b', email_paciente = '$e' WHERE email_paciente = '$ema'");
        if ($up) {
          print 200;
        }
      } catch (\Throwable $th) {
        print $th->getMessage();
      }
    } else {
      print $this->erros;
    }
  }
}

$paciente = new pacientes;

if (isset($_POST['acao'])) {

  require '../env.php';

  $acao = $_POST['acao'];

  switch ($acao) {

    case 'save':
      session_start();

      $paciente->setNome(filter_input(INPUT_POST, 'nome'));
      $paciente->setEmail(filter_input(INPUT_POST, 'email'));
      $paciente->setTelefone(filter_input(INPUT_POST, 'telefone'));
      $paciente->setBi(filter_input(INPUT_POST, 'bi'));
      $paciente->setSenha(filter_input(INPUT_POST, 'password'));


      # invocando Validações

      $paciente->nomeValidate($paciente->getNome());
      $paciente->telefoneValidate($paciente->getTelefone());
      $paciente->emailValidate($paciente->getEmail());

      $paciente->checkBi($BD);
      $paciente->checkFone($BD);
      $paciente->checkLogin($BD);

      $paciente->save($BD);
      $_SESSION['email_paciente'] = $paciente->getEmail();

      break;

    case 'editar':

      session_start();

      $paciente->setNome(filter_input(INPUT_POST, 'nome'));
      $paciente->setEmail(filter_input(INPUT_POST, 'email'));
      $ema = filter_input(INPUT_POST, 'emaill');
      $paciente->setTelefone(filter_input(INPUT_POST, 'telefone'));
      $paciente->setBi(filter_input(INPUT_POST, 'bi'));

      $paciente->nomeValidate($paciente->getNome());
      $paciente->telefoneValidate($paciente->getTelefone());
      $paciente->emailValidate($paciente->getEmail());

      $paciente->editar($BD, $ema);

      break;

    case 'login':

      session_start();
      $paciente->setEmail(filter_input(INPUT_POST, 'email'));
      $paciente->setSenha(md5(filter_input(INPUT_POST, 'password')));

      $paciente->login($BD);
      break;
  }
} else if (isset($_GET['acao']) && $_GET['acao'] == 'delete') {
  require '../env.php';
  session_start();
  $id_paciente = filter_input(INPUT_GET, 'id');
  $paciente->delete($BD, $id_paciente);
}
