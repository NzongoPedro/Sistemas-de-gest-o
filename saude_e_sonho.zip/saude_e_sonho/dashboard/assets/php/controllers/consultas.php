<?php

class consultas
{
  private $id, $nome, $clinica, $area, $motivo, $endereco, $table = 'marcacao_consultas';
  public $erros = null;

  /**
   * Get the value of nome
   */
  public function getNome()
  {
    return $this->nome;
  }

  /**
   * Set the value of nome
   *
   * @return  self
   */
  public function setNome($nome)
  {
    $this->nome = $nome;

    return $this;
  }

  /**
   * Get the value of clinica
   */
  public function getClinica()
  {
    return $this->clinica;
  }

  /**
   * Set the value of clinica
   *
   * @return  self
   */
  public function setClinica($clinica)
  {
    $this->clinica = $clinica;

    return $this;
  }

  /**
   * Get the value of area
   */
  public function getArea()
  {
    return $this->area;
  }

  /**
   * Set the value of area
   *
   * @return  self
   */
  public function setArea($area)
  {
    $this->area = $area;

    return $this;
  }

  /**
   * Get the value of motivo
   */
  public function getMotivo()
  {
    return $this->motivo;
  }

  /**
   * Set the value of motivo
   *
   * @return  self
   */
  public function setMotivo($motivo)
  {
    $this->motivo = $motivo;

    return $this;
  }

  /**
   * Get the value of endereco
   */
  public function getEndereco()
  {
    return $this->endereco;
  }

  /**
   * Set the value of endereco
   *
   * @return  self
   */
  public function setEndereco($endereco)
  {
    $this->endereco = $endereco;

    return $this;
  }

  # Valida 
  public function clinicaValidate()
  {
    if ($this->getClinica() ==  "Clínica") {
      $this->erros = 'Por favor selecione uma clínica.';
    }
  }
  public function areaValidate()
  {
    if ($this->getArea() ==  "Área") {
      $this->erros = 'Por favor selecione uma área.';
    }
  }

  # verifica se ja existe uma consulta deste paciente
  public function checConsulta($BD)
  {
    $check = $BD->query("SELECT *FROM {$this->table} WHERE id_especialidade = '" . $this->getArea() . "' AND id_clinica = '" . $this->getClinica() . "' AND id_paciente = '" . $this->getNome() . "' ");
    if ($check->rowCount() > 0) {
      $this->erros = 'Verficamos que já tens uma consulta marcada nesta clínica e na área escolhida';
    }
  }

  # save consulta

  public function save($BD)
  {


    if ($this->erros == null) {
      try {
        $query = "INSERT INTO {$this->table}  
        (id_especialidade, id_paciente, id_clinica, motivo, endereco, data_solicitação_consulta)
				VALUES(?,?,?,?,?,?)";

        $save = $BD->prepare($query);

        $save->bindValue(1, $this->getArea());
        $save->bindValue(2, $this->getNome());
        $save->bindValue(3, $this->getClinica());
        $save->bindValue(4, $this->getMotivo());
        $save->bindValue(5, $this->getEndereco());
        $save->bindValue(6, date('d-m-y H:i:s'));

        if ($save->execute()) {
          print 200;
        }
      } catch (PDOException $th) {
        print
          $th->getMessage();
      }
    } else {
      print $this->erros;
    }
  }

  # show consultas
  public function show($BD, $id)
  {
    if ($_SESSION['categoria_funcionario'] == 'Médico') {
      $select = $BD->query("SELECT *FROM {$this->table} 
        
        INNER JOIN especialidades ON especialidades.idespecialidades = {$this->table}.id_especialidade
        INNER JOIN pacientes ON pacientes.idpacientes = {$this->table}.id_paciente
        INNER JOIN clinicas ON clinicas.idclinicas = {$this->table}.id_clinica
        WHERE id_medico = '$id' AND estado > 0
        ORDER BY data_solicitação_consulta
        ");
    } else {

      $select = $BD->query("SELECT *FROM {$this->table} 
     
      INNER JOIN especialidades ON especialidades.idespecialidades = {$this->table}.id_especialidade
      INNER JOIN pacientes ON pacientes.idpacientes = {$this->table}.id_paciente
      INNER JOIN clinicas ON clinicas.idclinicas = {$this->table}.id_clinica
      ORDER BY data_solicitação_consulta
      ");
    }


    while ($consulta = $select->fetch()) { ?>

      <tr>
        <td><?= $consulta->idmarcacaoconsultaa ?></td>
        <td><?= $consulta->designacao_especialidade ?></td>
        <td><?= $consulta->nome_paciente ?></td>
        <td><?= $consulta->designacao_clinica ?></td>
        <td>
          <?php
          if ($consulta->estado == 1) {
            echo '<span class="badge rounded-pill bg-primary">Pendente</span>';
          } elseif ($consulta->estado == 0) {
            echo '<span class="badge rounded-pill bg-danger">Cancelada</span>';
          } elseif ($consulta->estado == 2) {
            echo '<span class="badge rounded-pill bg-dark">Preescrito</span>';
          } else if ($consulta->estado == 3) {
            echo '<span class="badge rounded-pill bg-info">Marcada</span>';
          } else {
            echo '<span class="badge rounded-pill bg-success">Realizada</span>';
          }
          ?>
        </td>
        <td>
          <a href="./consultasInfo.php?paciente=<?= $consulta->idpacientes ?>&consulta=<?= $consulta->idmarcacaoconsultaa ?>" class="text-primary">
            <i class=" bi-plus-circle-fill"></i> Infomações
          </a>

        </td>
      </tr>

    <?php

    }
  }

  ## show detalhes consultas
  public function showDetalhes($BD, $id_paciente, $id_consulta)
  {
    $select = $BD->query("SELECT *FROM {$this->table} 
    INNER JOIN especialidades ON especialidades.idespecialidades = {$this->table}.id_especialidade
    INNER JOIN pacientes ON pacientes.idpacientes = {$this->table}.id_paciente
    INNER JOIN clinicas ON clinicas.idclinicas = {$this->table}.id_clinica
    WHERE  {$this->table}.id_paciente = '$id_paciente' AND {$this->table}.idmarcacaoconsultaa = '$id_consulta'
    ");

    while ($de = $select->fetch()) { ?>
      <div class="card-title">
        Solicitação Consulta de <b><?= $de->nome_paciente ?></b>
        <hr>
      </div>
      <div class="mt-4 p-2 alert alert-light">
        <div class="text-lead card-text">
          <?= $de->nome_paciente ?>, solicitou um consulta na área de "<b><?= $de->designacao_especialidade ?></b>". Para a clínica <b><?= $de->designacao_clinica ?></b>
          <br>
          <b>Motivo:</b>
          <br>
          <?= $de->motivo ?>
          <br>
          <b>Endereço: </b> <?= $de->endereco ?>

          <div class="text-center mt-1">
            <b>

              Estado:
              <?php

              if ($de->estado == 0) {
                print 'Cancelada';
              } else if ($de->estado == 1) {
                print 'Pendente';
              } else if ($de->estado == 2) {
                print 'Agendada';
              } else if ($de->estado == 3) {
                print 'Marcada';
              } else if ($de->estado == 4) {
                print 'Realizada';
              } else {
                print "Preescrita e realizada";
              }

              ?>

            </b>
          </div>

          <div class="text-center mt-2">
            <b>Aos <br> </b> <?= $de->data_solicitação_consulta ?>
          </div>
        </div>
        <div class="card-footer">
          <div class="d-flex justify-content-center">
            <div class="mt-4 mb-4 text-center resposta" style="width: 25rem;"></div>
          </div>


          <div class="text-center mt-4 mb-4">


            <div class="d-flex justify-content-center align-content-cente align-items-center align-center">

              <!-- PREESCRIÇÃO -->
              <div class="card consulta-prescrever" style="width: 25rem; display:none">
                <div class="card-body">
                  <form action="" class="form-prescricao-consulta">
                    <div class="mb-1 mt-5">
                      <div class="res-1 mt-2 mb-2"></div>
                      <textarea class="form-control rounded-0" placeholder="Escreva aqui a preescrição médica." required minlength="50" name="info"></textarea>
                      <div class="d-grid gap-2 mt-1">
                        <input type="hidden" name="idConsulta" value="<?= $de->idmarcacaoconsultaa ?>">
                        <input type="hidden" name="estado" value="<?= $de->estado ?>">
                        <input type="hidden" name="acao" value="preescrever">
                        <button class="btn btn-sm rounded rounded-1 btn-dark rounded-0" type="submit">finalizar</button>
                      </div>
                    </div>
                  </form>
                </div>
              </div>
              <!-- END PREESCRIÇÃO -->

              <!-- AGENDAR A CONSULTA -->
              <div class="card consulta-marcar" style="width: 25rem; display:none">
                <div class="card-body">
                  <form action="" class="form-agenda-consulta">
                    <div class="mb-1 mt-5">
                      <div class="res-2 mt-2 mb-2"></div>
                      <textarea class="form-control rounded-0" placeholder="Dê detalhes Agendamento, hora, data, local etc..." required minlength="10" name="info"></textarea>
                      <div class="row mt-2">
                        <div class="form-group col">
                          <select id="local" class="form-select">
                            <option disabled selected>Local</option>
                            <?php
                            $query = $BD->query("SELECT morada,  count(idfuncionarios) FROM funcionarios where idfuncionarios !=0 GROUP BY morada HAVING COUNT(morada)>0");
                            while ($localidade = $query->fetch()) {
                              echo '<option>' . $localidade->morada . '</option>';
                            }

                            ?>
                          </select>
                        </div>
                        <div class="form-group col">
                          <select name="medico" id="m" class="form-select">
                            <option selected disabled>Médico</option>
                          </select>
                        </div>
                      </div>
                      <div class="d-grid gap-2 mt-1">
                        <input type="hidden" name="idConsulta" value="<?= $de->idmarcacaoconsultaa ?>">
                        <input type="hidden" name="acao" value="agenda">
                        <button class="btn btn-sm rounded rounded-1 bg-btn rounded-0" type="submit">FINALIZAR</button>
                      </div>
                    </div>

                  </form>
                </div>
              </div>
              <!-- END AGENDA -->
            </div>

            <?php

            //botões de ações para consultas

            if ($de->estado == 0) { ?>
              <button class="btn btn-sm rounded rounded-1 bg-btn rounded-0 btn-ativar-consulta" id="<?= $de->idmarcacaoconsultaa ?>">
                <i class="bi bi-check"></i>
                <span class="ms-1">Activar</span>
              </button>
            <?php
            } else { ?>

              <?php
              if ($_SESSION['categoria_funcionario'] != 'Médico') { ?>

                <button class="btn btn-sm rounded rounded-1 btn-danger rounded-0 btn-cancelar-consulta" id="<?= $de->idmarcacaoconsultaa ?>">
                  <i class="bi bi-trash"></i>
                  <span class="ms-1">Cancelar</span>
                </button>
              <?php } ?>

              <!--  botão agendar a consulta -->


              <!-- Botão marcar consulta -->
            <?php }
            if ($_SESSION['categoria_funcionario'] != 'Médico') { ?>

              <button class="btn btn-sm rounded rounded-1 bg-btn btn-marca rounded-0">
                <i class="bi bi-calendar-check-fill"></i>
                <span class="ms-1">Agendar</span>
              </button>

              <button class="btn btn-sm rounded rounded-1 btn-info btn-marcar rounded-0 text-white" name="<?= $de->idmarcacaoconsultaa ?>" title="<?= $de->estado ?>">
                <i class="bi bi-check-circle"></i>
                <span class="ms-1">Marcar</span>
              </button>
              <?php ?>


            <?php }
            if ($_SESSION['categoria_funcionario'] == 'Médico') { ?>

              <button class="btn btn-sm rounded rounded-1 btn-dark rounded-0 btn-preescricao">
                <i class="bi bi-pencil"></i>
                <span class="ms-1">Preescrever</span>
              </button>

              <button class="btn btn-sm rounded rounded-1 btn-success btn-realizar rounded-0" name="<?= $de->idmarcacaoconsultaa ?>" title="<?= $de->estado ?>">
                <i class="bi bi-check2-circle"></i>
                <span class="ms-1">Realizar</span>
              </button>

            <?php

            }
            ?>
          </div>
        </div>

      </div>


<?php
    }
  }

  # Cancelar consulta
  public function cancelarConsulta($BD, $id_consulta)
  {
    try {

      if (
        $_SESSION['categoria_funcionario'] == 'Médico'
      ) {
        $this->erros = "Não tem permissão para cancelar uma consulta.";
      }

      $data = date("Y-m-d H:m:s");
      if ($this->erros == null) {
        $update = $BD->query("UPDATE {$this->table} SET visto = '0', estado = '0', data_feedback = '$data' WHERE idmarcacaoconsultaa = '$id_consulta'");
        print 200;
      } else {
        print $this->erros;
      }
    } catch (PDOException $e) {
      print $e->getMessage();
    }
  }

  # preescrever consulta
  public function preescreverConsulta($BD, $id_consulta, $id_estado, $info)
  {
    try {

      if ($_SESSION['categoria_funcionario'] == 'Médico') {
        if ($id_estado == 5) {
          $this->erros = "Esta consulta já foi preescrita e realizada.";
        } elseif ($id_estado < 4) {
          $this->erros = "Esta consulta não pode ser preescrita porque ainda não foi agendada, marcada ou realizada.";
        }
      } else {
        $this->erros = "Não tem permissão para preescrever uma consulta.";
      }

      $data = date("Y-m-d H:m:s");

      if ($this->erros == null) {
        $update = $BD->query("UPDATE {$this->table} SET visto = '0', estado = '5', data_feedback = '$data', info = '$info' WHERE idmarcacaoconsultaa = '$id_consulta'");
        print 200;
      } else {
        print $this->erros;
      }
    } catch (PDOException $e) {
      print $e->getMessage();
    }
  }

  # marcar consulta
  public function agendaConsulta($BD, $id_consulta,  $id_medico, $info)
  {
    try {

      if ($_SESSION['categoria_funcionario'] == 'Médico') {
        $this->erros = "Não tem permissão para agendar esta consulta.";
      }

      $data = date("Y-m-d H:i:s");
      if ($this->erros == null) {
        $update = $BD->query("UPDATE {$this->table} SET visto = '0', estado = '2', data_feedback = '$data', info = '$info', id_medico = '$id_medico' WHERE idmarcacaoconsultaa = '$id_consulta'");
        print 200;
      } else {
        print $this->erros;
      }
    } catch (PDOException $e) {
      print $e->getMessage();
    }
  }


  # activar consulta
  public function ativarConsulta($BD, $id_consulta)
  {
    try {

      if ($_SESSION['categoria_funcionario'] == 'Médico') {
        $this->erros = "Não tem permissão para reactivar uma consulta.";
      }

      $data = date("Y-m-d H:m:s");
      if ($this->erros == null) {
        $BD->query("UPDATE {$this->table} SET visto = '0', estado = '1', data_feedback = '$data' WHERE idmarcacaoconsultaa = '$id_consulta'");
        print 200;
      } else {
        print $this->erros;
      }
    } catch (PDOException $e) {
      print $e->getMessage();
    }
  }
  # Realiza consulta
  public function realizarConsulta($BD, $id_consulta, $id_estado)
  {
    try {

      if ($id_estado == 4) {
        $this->erros = "Esta consulta já foi realizada. Por favor faça a preescrição.";
      } elseif ($id_estado < 3) {
        $this->erros = "Esta consulta não pode ser realizada porque não foi agenda ou marcada.";
      }

      $data = date("Y-m-d H:m:s");
      if ($this->erros == null) {
        $BD->query("UPDATE {$this->table} SET visto = '0', estado = '4', data_feedback = '$data' WHERE idmarcacaoconsultaa = '$id_consulta'");
        print 200;
      } else {
        print $this->erros;
      }
    } catch (PDOException $e) {
      print $e->getMessage();
    }
  }
  # Marca a consultada
  public function marcarConsulta($BD, $id_consulta, $id_estado)
  {
    try {

      if ($_SESSION['categoria_funcionario'] == 'Médico') {
        $this->erros = "Não tem permissão para marcar uma consulta.";
      }

      if ($id_estado == 3) {
        $this->erros = "Esta consulta já esta marcada.";
      } elseif ($id_estado < 2) {
        $this->erros = "Esta consulta não pode se marcada porque foi cancelada, ou n]ao foi agendada.";
      }

      $data = date("Y-m-d H:m:s");
      if ($this->erros == null) {
        $BD->query("UPDATE {$this->table} SET visto = '0', estado = '3', data_feedback = '$data' WHERE idmarcacaoconsultaa = '$id_consulta'");
        print 200;
      } else {
        print $this->erros;
      }
    } catch (PDOException $e) {
      print $e->getMessage();
    }
  }

  # mostra médico para consulta
  public function medico_consulta($BD)
  {
    $query = $BD->query("SELECT *FROM funcionarios WHERE id_categoria_funcionario = 1 and morada = '" . $this->getEndereco() . "' ORDER BY nome_funcionario");
    echo ' <option disabled>Médico</option>';
    while ($resultado =  $query->fetch()) :
      echo '<option value="' . $resultado->idfuncionarios . '">' . $resultado->nome_funcionario . '</option>';
    endwhile;
  }

  //  contarConsultas
  public function contarConsultas($BD, $id)
  {
    if ($_SESSION['categoria_funcionario'] == 'Admnistrador') {

      $conta = $BD->query("SELECT *FROM {$this->table} ");
    } else {

      $conta = $BD->query("SELECT *FROM {$this->table} WHERE id_medico = '$id'");
    }

    return $conta->rowCount();
  }

  // Contar canceleados não lidos
  public static function getCountCancelados($BD, $id)
  {
    $UP = $BD->query("SELECT *FROM marcacao_consultas WHERE id_paciente = '$id' AND estado = '0' AND visto = '0' ")->rowCount();
    return $UP;
  }

  // Contar pendentes não lidos
  public static function getCountPendentes($BD, $id)
  {
    $UP = $BD->query("SELECT *FROM marcacao_consultas WHERE id_paciente = '$id' AND estado = '1' AND visto = '0' ")->rowCount();
    return $UP;
  }

  // Contar agendados não lidos
  public static function getCountAgendadas($BD, $id)
  {
    $UP = $BD->query("SELECT *FROM marcacao_consultas WHERE id_paciente = '$id' AND estado = '2' AND visto = '0' ")->rowCount();
    return $UP;
  }
  // Contar marcadas não lidos
  public static function getCountMarcadas($BD, $id)
  {
    $UP = $BD->query("SELECT *FROM marcacao_consultas WHERE id_paciente = '$id' AND estado = '3' AND visto = '0' ")->rowCount();
    return $UP;
  }
  // Contar realizadas não lidos
  public static function getCountRealizadas($BD, $id)
  {
    $UP = $BD->query("SELECT *FROM marcacao_consultas WHERE  estado = '4' AND  id_paciente = '$id' AND visto = '0' ")->rowCount();
    return $UP;
  }
  // Contar preescritas não lidos
  public static function getCountPreescritas($BD, $id)
  {
    $UP = $BD->query("SELECT *FROM marcacao_consultas WHERE id_paciente = '$id' AND estado = '5' AND visto = '0' ")->rowCount();
    return $UP;
  }
  // Contartodos
  public static function getCountAll($BD, $id)
  {
    $UP = $BD->query("SELECT *FROM marcacao_consultas WHERE id_paciente = '$id' AND visto = '0'")->rowCount();
    return $UP;
  }
  // vizualizar
  public static function visualizarConsultas($BD, $id, $estado)
  {
    $BD->query("UPDATE marcacao_consultas SET visto = '1' WHERE id_paciente = '$id' AND estado = '$estado'");
  }


  public static function estado($BD, $idd, $estado)
  {
    $msg = ['Nenhuma consulta cancelada', 'Nenhuma consulta em pedente', 'Nenhuma consulta foi agenda', 'Nenhuma consulta marcada', 'Nenhuma consulta realizada', 'Sem nenhuma preescrição médica'];

    $select = $BD->query("SELECT *FROM marcacao_consultas 
      INNER JOIN especialidades ON especialidades.idespecialidades = marcacao_consultas.id_especialidade
      INNER JOIN pacientes ON pacientes.idpacientes = marcacao_consultas.id_paciente
      INNER JOIN clinicas ON clinicas.idclinicas = marcacao_consultas.id_clinica
      INNER JOIN funcionarios ON funcionarios.idfuncionarios = marcacao_consultas.id_medico
      WHERE  marcacao_consultas.id_paciente = '" . $idd . "' AND estado = '$estado'
      ");

    if ($select->rowCount() <= 0) {
      echo '<div class="alert alert-danger mt-2 rounded-0">
        <h5 class="text-center"><b>' . $msg[$estado] . '</b></h5>
        <div class="card-img">
          <img src="404.svg">
        </div>
      </div>';
    } else {
      require '../adm-includes/important/consultas/estados.php';
      while ($de = $select->fetch()) {
        switch ($estado) {
          case 0:
            estado_0($BD, $idd, $estado);
            break;
          case 1:
            estado_1($BD, $idd, $estado);
            break;
          case 2:
            estado_2($BD, $idd, $estado);
            break;
          case 3:
            estado_3($BD, $idd, $estado);
            break;
          case 4:
            estado_4($BD, $idd, $estado);
            break;
          default:
            estado_5($BD, $idd, $estado);
            break;
        }
      }
    }
  }
}

$consultas = new consultas;

if (isset($_POST['acao'])) {

  require '../env.php';

  $acao = $_POST['acao'];

  switch ($acao) {

    case 'save':

      $consultas->setNome(filter_input(INPUT_POST, 'nome'));
      $consultas->setArea(filter_input(INPUT_POST, 'area'));
      $consultas->setClinica(filter_input(INPUT_POST, 'clinica'));
      $consultas->setEndereco(filter_input(INPUT_POST, 'endereco'));
      $consultas->setMotivo(filter_input(INPUT_POST, 'motivo'));

      # invocando Validações

      $consultas->clinicaValidate($consultas->getClinica());
      $consultas->areaValidate($consultas->getArea());

      $consultas->checConsulta($BD);
      $consultas->save($BD);

      break;


    case 'show':
      session_start();
      $id = filter_input(INPUT_POST, 'id');
      $consultas->show($BD, $id);
      break;

    case 'preescrever':
      session_start();
      $id_consulta = filter_input(INPUT_POST, 'idConsulta', FILTER_SANITIZE_NUMBER_INT);
      $info = nl2br(htmlspecialchars(filter_input(INPUT_POST, 'info')));
      $id_estado = filter_input(INPUT_POST, 'estado', FILTER_SANITIZE_NUMBER_INT);
      $consultas->preescreverConsulta($BD, $id_consulta, $id_estado, $info);
      break;

    case 'agenda':

      session_start();
      $id_consulta = filter_input(INPUT_POST, 'idConsulta', FILTER_SANITIZE_NUMBER_INT);
      $id_medico = filter_input(INPUT_POST, 'medico', FILTER_SANITIZE_NUMBER_INT);
      $info = nl2br(htmlspecialchars(filter_input(INPUT_POST, 'info')));
      $consultas->agendaConsulta($BD, $id_consulta,  $id_medico, $info);
      break;
    case 'medico-consulta':
      $consultas->setEndereco(filter_input(INPUT_POST, 'local'));
      $consultas->medico_consulta($BD);
      break;
  }
} elseif (isset($_GET['acao'])) {

  session_start();

  require '../env.php';

  $acao = $_GET['acao'];

  switch ($acao) {
    case 'cancelar':
      $id_consulta = filter_input(INPUT_GET, 'idConsulta', FILTER_SANITIZE_NUMBER_INT);
      $consultas->cancelarConsulta($BD, $id_consulta);
      break;

    case 'ativar':
      $id_consulta = filter_input(INPUT_GET, 'idConsulta', FILTER_SANITIZE_NUMBER_INT);
      $consultas->ativarConsulta($BD, $id_consulta);
      break;

    case 'realizar':
      $id_consulta = filter_input(INPUT_GET, 'idConsulta', FILTER_SANITIZE_NUMBER_INT);
      $id_estado = filter_input(INPUT_GET, 'estado', FILTER_SANITIZE_NUMBER_INT);
      $consultas->realizarConsulta($BD, $id_consulta, $id_estado);
      break;

    case 'marcar':
      $id_consulta = filter_input(INPUT_GET, 'idConsulta', FILTER_SANITIZE_NUMBER_INT);
      $id_estado = filter_input(INPUT_GET, 'estado', FILTER_SANITIZE_NUMBER_INT);
      $consultas->marcarConsulta($BD, $id_consulta, $id_estado);
      break;

    case 'cancelados-nao-lidos':
      $id = filter_input(INPUT_GET, 'idpaciente', FILTER_SANITIZE_NUMBER_INT);
      print  $consultas::getCountCancelados($BD, $id);
      break;
    case 'pendentes-nao-lidos':
      $id = filter_input(INPUT_GET, 'idpaciente', FILTER_SANITIZE_NUMBER_INT);
      print  $consultas::getCountPendentes($BD, $id);
      break;
    case 'agendadas-nao-lidos':
      $id = filter_input(INPUT_GET, 'idpaciente', FILTER_SANITIZE_NUMBER_INT);
      print  $consultas::getCountAgendadas($BD, $id);
      break;
    case 'marcadas-nao-lidos':
      $id = filter_input(INPUT_GET, 'idpaciente', FILTER_SANITIZE_NUMBER_INT);
      print  $consultas::getCountMarcadas($BD, $id);
      break;
    case 'realizadas-nao-lidos':
      $id = filter_input(INPUT_GET, 'idpaciente', FILTER_SANITIZE_NUMBER_INT);
      print  $consultas::getCountRealizadas($BD, $id);
      break;
    case 'preescritas-nao-lidos':
      $id = filter_input(INPUT_GET, 'idpaciente', FILTER_SANITIZE_NUMBER_INT);
      print  $consultas::getCountPreescritas($BD, $id);
      break;
    case 'todas':
      $id = filter_input(INPUT_GET, 'idpaciente', FILTER_SANITIZE_NUMBER_INT);
      print  $consultas::getCountAll($BD, $id);
      break;
    case 'estados':
      $id = filter_input(INPUT_GET, 'idpaciente', FILTER_SANITIZE_NUMBER_INT);
      $estado = filter_input(INPUT_GET, 'estado', FILTER_SANITIZE_NUMBER_INT);
      print  $consultas::estado($BD, $id, $estado);
      break;
    default:
      $id = filter_input(INPUT_GET, 'idpaciente', FILTER_SANITIZE_NUMBER_INT);
      $estado = filter_input(INPUT_GET, 'estado', FILTER_SANITIZE_NUMBER_INT);
      print  $consultas::visualizarConsultas($BD, $id, $estado);
      break;
      var_dump($_REQUEST);
  }
}
