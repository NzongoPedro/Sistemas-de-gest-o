<?php

class clinicas
{
    private $designacao;
    private $nif;
    private $telefone;
    private $email;
    private $localidade;
    private $especialidade;
    private $table = 'clinicas';
    public $erros = null;




    /**
     * Get the value of designacao
     */
    public function getDesignacao()
    {
        return $this->designacao;
    }

    /**
     * Set the value of designacao
     *
     * @return  self
     */
    public function setDesignacao($designacao)
    {
        $this->designacao = $designacao;

        return $this;
    }

    /**
     * Get the value of nif
     */
    public function getNif()
    {
        return $this->nif;
    }

    /**
     * Set the value of nif
     *
     * @return  self
     */
    public function setNif($nif)
    {
        $this->nif = $nif;

        return $this;
    }

    /**
     * Get the value of telefone
     */
    public function getTelefone()
    {
        return $this->telefone;
    }

    /**
     * Set the value of telefone
     *
     * @return  self
     */
    public function setTelefone($telefone)
    {
        $this->telefone = $telefone;

        return $this;
    }

    /**
     * Get the value of email
     */
    public function getEmail()
    {
        return $this->email;
    }

    /**
     * Set the value of email
     *
     * @return  self
     */
    public function setEmail($email)
    {
        $this->email = $email;

        return $this;
    }

    /**
     * Get the value of localidade
     */
    public function getLocalidade()
    {
        return $this->localidade;
    }

    /**
     * Set the value of localidade
     *
     * @return  self
     */
    public function setLocalidade($localidade)
    {
        $this->localidade = $localidade;

        return $this;
    }

    /**
     * Get the value of especialidade
     */
    public function getEspecialidade()
    {
        return $this->especialidade;
    }

    /**
     * Set the value of especialidade
     *
     * @return  self
     */
    public function setEspecialidade($especialidade)
    {
        $this->especialidade = $especialidade;

        return $this;
    }

    # save
    public function save($BD)
    {
        try {
            $salvar = $BD->prepare("INSERT INTO clinicas 
            (designacao_clinica, id_localidade,	NIF, email_clinica,	telefone_clinica, id_especialidade)
            VALUES(?,?,?,?,?,?)");

            $salvar->bindValue(1, $this->getDesignacao());
            $salvar->bindValue(2, $this->getLocalidade());
            $salvar->bindValue(3, $this->getNif());
            $salvar->bindValue(4, $this->getEmail());
            $salvar->bindValue(5, $this->getTelefone());
            $salvar->bindValue(6, $this->getEspecialidade());

            if ($_SESSION['categoria_funcionario'] != 'Admnistrador') {
                $this->erros = "Apenas administradores podem realizar esta actividade.";
            }

            if ($this->erros == null) {
                $salvar->execute();
                print 200;
            } else {
                print $this->erros;
            }
        } catch (PDOException $err) {
            print $err->getMessage();
        }
    }

    ## save especialidade
    public function salvarEspecialidade($BD)
    {
        try {
            $salvar = $BD->prepare("INSERT INTO especialidades
            (designacao_especialidade)
            VALUES(?)");

            $salvar->bindValue(1, $this->getDesignacao());

            if ($_SESSION['categoria_funcionario'] != 'Admnistrador') {
                $this->erros = "Apenas administradores podem realizar esta actividade.";
            }


            if ($this->erros == null) {
                $salvar->execute();
                print 200;
            } else {
                die($this->erros);
            }
        } catch (PDOException $err) {
            print $err->getMessage();
        }
    }


    public function viewClinicas($BD)
    {
        try {
            if ($_SESSION['categoria_funcionario'] == 'Admnistrador') {
                $busca = $BD->query("SELECT *FROM {$this->table} 
      INNER JOIN especialidades
      ON especialidades.idespecialidades = {$this->table}.id_especialidade
      ORDER BY {$this->table}.designacao_clinica");
                while ($clinica = $busca->fetch()) : ?>
                    <tr>
                        <td><?= $clinica->designacao_clinica ?></td>
                        <td><?= $clinica->email_clinica ?></td>
                        <td><?= $clinica->NIF ?></td>
                        <td><?= $clinica->telefone_clinica ?></td>
                        <td><?= $clinica->designacao_especialidade ?></td>
                        <td scope="row"><?= $clinica->id_localidade ?></td>
                    </tr>
                <?php endwhile;
            }
        } catch (PDOException $erro) {
            print $erro->getMessage();
        }
    }


    # view especialidades
    public function viewEspecialidadess($BD)
    {
        try {
            if ($_SESSION['categoria_funcionario'] == 'Admnistrador') {
                $busca = $BD->query("SELECT *FROM especialidades ORDER BY designacao_especialidade ASC");
                while ($clinica = $busca->fetch()) : ?>
                    <tr class="linha-<?= $clinica->idespecialidades ?>">
                        <td><?= $clinica->idespecialidades ?></td>
                        <td><?= $clinica->designacao_especialidade ?></td>
                        <td>
                            <a href="#!" class="btn btn-sm border-0 badge text-danger rem-especialidade" id="<?= $clinica->idespecialidades ?>">
                                <i class="bi-trash"></i>
                            </a>
                            <a href="#" class="btn btn-sm border-0 badge text-dark edit-especialidade" title="<?= $clinica->designacao_especialidade ?>" id="<?= $clinica->idespecialidades ?>">
                                <i class="bi-pen"></i>
                            </a>
                        </td>
                    </tr>
<?php endwhile;
            }
        } catch (PDOException $erro) {
            print $erro->getMessage();
        }
    }


    # Remover especialidades
    public function removerEspecialidade($BD, $id)
    {
        if ($_SESSION['categoria_funcionario'] != 'Admnistrador') {
            $this->erros = "Apenas administradores podem realizar esta actividade.";
        } else {
            $BD->query("DELETE FROM especialidades WHERE idespecialidades ='$id'");
            print 200;
        }
    }

    # Update especialidades
    public function updateEspecialidade($BD, $id)
    {
        if ($_SESSION['categoria_funcionario'] != 'Admnistrador') {
            $this->erros = "Apenas administradores podem realizar esta actividade.";
        } else {
            $BD->query("UPDATE especialidades 
            SET designacao_especialidade = '" . $this->getEspecialidade() . "'
             WHERE idespecialidades = '$id'");
            print 200;
        }
    }


    //  contar clinicas
    public function contarClinicas($BD)
    {
        $conta = $BD->query("SELECT *FROM {$this->table}");
        return $conta->rowCount();
    }
}


$clinica = new clinicas;

if (isset($_POST['acao'])) {
    require '../env.php';
    $acao = $_POST['acao'];

    switch ($acao) {
        case 'save':
            session_start();

            $clinica->setDesignacao(htmlspecialchars(filter_input(INPUT_POST, 'nome')));
            $clinica->setTelefone(htmlspecialchars(filter_input(INPUT_POST, 'telefone')));
            $clinica->setEmail(htmlspecialchars(filter_input(INPUT_POST, 'email')));
            $clinica->setNif(htmlspecialchars(filter_input(INPUT_POST, 'nif')));
            $clinica->setLocalidade(htmlspecialchars(filter_input(INPUT_POST, 'localizacao')));
            $clinica->setEspecialidade(htmlspecialchars(filter_input(INPUT_POST, 'especialidade')));

            $clinica->save($BD);

            break;

        case 'save-categoria':
            session_start();
            $clinica->setDesignacao(htmlspecialchars(filter_input(INPUT_POST, 'nome')));
            $clinica->salvarEspecialidade($BD);

            break;

        case 'view-clinicas':
            session_start();
            $clinica->viewClinicas($BD);
            break;

        case 'remover-especialidade':
            session_start();
            $id = filter_input(INPUT_POST, 'id', FILTER_SANITIZE_NUMBER_INT);
            $clinica->removerEspecialidade($BD, $id);
            break;

        case 'update-categoria':
            session_start();
            $id = filter_input(INPUT_POST, 'id', FILTER_SANITIZE_NUMBER_INT);
            $clinica->setEspecialidade(htmlspecialchars(filter_input(INPUT_POST, 'especialidade')));
            $clinica->updateEspecialidade($BD, $id);
            break;
    }
}
