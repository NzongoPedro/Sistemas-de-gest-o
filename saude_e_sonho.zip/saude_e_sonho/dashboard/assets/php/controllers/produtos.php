<?php

class Produtos
{

  private $nome;
  private $preco;
  private $foto;
  private $descricao;
  private $tabela = "produtos";
  public $erros = false;



  /**
   * Get the value of nome
   */
  public function getNome()
  {
    return $this->nome;
  }

  /**
   * Set the value of nome
   *
   * @return  self
   */
  public function setNome($nome)
  {
    $this->nome = $nome;

    return $this;
  }

  /**
   * Get the value of preco
   */
  public function getPreco()
  {
    return $this->preco;
  }

  /**
   * Set the value of preco
   *
   * @return  self
   */
  public function setPreco($preco)
  {
    $this->preco = $preco;

    return $this;
  }

  /**
   * Get the value of foto
   */
  public function getFoto()
  {
    return $this->foto;
  }

  /**
   * Set the value of foto
   *
   * @return  self
   */
  public function setFoto($foto)
  {
    $this->foto = $foto;

    return $this;
  }

  /**
   * Get the value of descricao
   */
  public function getDescricao()
  {
    return $this->descricao;
  }

  /**
   * Set the value of descricao
   *
   * @return  self
   */
  public function setDescricao($descricao)
  {
    $this->descricao = $descricao;

    return $this;
  }

  # FOTO

  public function uploadFoto()
  {

    $arquivo = array(
      'arquivo'  => $this->getFoto()['name'],
      'temporal' => $this->getFoto()['tmp_name'],
      'tipo' => strtolower($this->getFoto()['type']),
      'formato'  => strtolower(pathinfo($this->getFoto()['name'], PATHINFO_EXTENSION)),
      'nome' => time() . '.' . strtolower(pathinfo($this->getFoto()['name'], PATHINFO_EXTENSION)),
      'diretorio' => '../../img/produtos/'
    );

    $formatos_permitidos = array('image/jpg', 'image/png', 'image/jpeg', 'image/gif');

    # =========================== VERIFICA OS FORMATOS PERMITIDOS =====================
    if (in_array($arquivo['tipo'], $formatos_permitidos)) {

      # ========================= VERIFICA O DIRECTORIO =====================
      if (is_dir($arquivo['diretorio'])) {

        # ===================================== TENTA O UPLOAD ==================
        if (move_uploaded_file($arquivo['temporal'], $arquivo['diretorio'] . $arquivo['nome'])) {
          $this->foto = $arquivo['nome'];
        } else {
          $this->erros = 'Falha no upload.';
        }
      } else {
        mkdir($arquivo['diretorio']);
        move_uploaded_file($arquivo['temporal'], $arquivo['diretorio'] . $arquivo['nome']);
        $this->foto = $arquivo['nome'];
      }
    } else {
      $this->foto = null;
      $this->erros = 'Formato .' . $arquivo['formato'] . ' não é válido';
    }
  }

  public function save($BD)
  {
    try {
      $query = $BD->prepare("INSERT INTO {$this->tabela}
      (nome_produto, preco_produto, foto_produto, descricao)
      VALUES(?,?,?,?)");

      $query->bindValue(1, $this->getNome());
      $query->bindValue(2, $this->getPreco());
      $query->bindValue(3, $this->getFoto());
      $query->bindValue(4, $this->getDescricao());

      if ($this->erros) {
        print $this->erros;
      } else {
        $query->execute();
        print 200;
      }
    } catch (PDOException $th) {
      echo $th->getMessage();
    }
  }

  public function show($BD)
  {
    try {
      $query = "SELECT *FROM {$this->tabela} ORDER BY nome_produto";
      $linha = $BD->query($query);
      return $linha->fetchAll();
    } catch (\Throwable $th) {
      //throw $th;
    }
  }

  public function btnPlus($BD, $idcliente, $qtd)
  {
    try {

      $precoProduto = $BD->query("SELECT preco_produto FROM {$this->tabela} WHERE idproduto = '" . $this->getNome() . "'");
      $preco = $precoProduto->fetch()->preco_produto;

      if ($qtd == 0) {
        $qtd = 0;
      }

      $total = number_format(($preco * $qtd), 2, ",", ".");

      // Insere ta tabela compra

      $compra = $BD->prepare("INSERT INTO compras (id_cliente, id_produto, quantidade, local_entrega, data_compra, preco, total)
      VALUES(?,?,?,?,?,?,?)");

      $compra->bindValue(1, $idcliente);
      $compra->bindValue(2, $this->getNome());
      $compra->bindValue(3, $qtd);
      $compra->bindValue(4, 'Local fictício');
      $compra->bindValue(5, date('y-m-d'));
      $compra->bindValue(6, $preco);
      $compra->bindValue(7, $total);

      // verifica se o mesmo produto já existe nesta data

      $verifica = $BD->query("SELECT data_compra, id_cliente, id_produto, estado_compra FROM compras
      WHERE id_cliente = '$idcliente' AND data_compra = '" . date('y-m-d') . "' AND id_produto = '" . $this->getNome() . "' AND estado_compra = '0'");

      $qtdAntiga = $BD->query("SELECT quantidade FROM compras  WHERE id_cliente = '$idcliente' AND data_compra = '" . date('y-m-d') . "' AND id_produto = '" . $this->getNome() . "'");

      if ($verifica->rowcount() > 0) {

        // atualiza os dados caso já tiver o mesmo produto para o mesmo user nesta data
        $novaQuantida =  $qtdAntiga->fetch()->quantidade + 1;

        if ($qtd == 0) {
          $novaQuantida = 0;
        }

        $total = number_format(($preco * $novaQuantida), 2, ",", ".");
        $update = $BD->query("UPDATE compras SET quantidade = '$novaQuantida', total = '$total'  WHERE id_cliente = '$idcliente' AND data_compra = '" . date('y-m-d') . "' AND id_produto = '" . $this->getNome() . "'");

        if ($update) {
          print 200;
        }
      } else {

        if ($compra->execute()) {
          print 200;
        }
      }
    } catch (PDOException $th) {
      print $th->getMessage();
    }
  }

  public function btnMinus($BD, $idcliente, $qtd)
  {
    try {

      $precoProduto = $BD->query("SELECT preco_produto FROM {$this->tabela} WHERE idproduto = '" . $this->getNome() . "'");
      $preco = $precoProduto->fetch()->preco_produto;


      // verifica se o mesmo produto já existe nesta data

      // $verifica = $BD->query("SELECT data_compra, id_cliente, id_produto FROM compras
      // WHERE id_cliente = '$idcliente' AND data_compra = '" . date('y-m-d') . "' AND id_produto = '" . $this->getNome() . "'");

      $qtdAntiga = $BD->query("SELECT quantidade FROM compras  WHERE id_cliente = '$idcliente' AND data_compra = '" . date('y-m-d') . "' AND id_produto = '" . $this->getNome() . "'");

      // if ($verifica->rowcount() > 0) {

      // atualiza os dados caso já tiver o mesmo produto para o mesmo user nesta data
      $novaQuantida = $qtdAntiga->fetch()->quantidade - 1;

      if ($novaQuantida <= 0) {
        $novaQuantida = 0;
      }


      if ($qtd == 0) {
        $novaQuantida = 0;
      }

      $total = number_format(($preco * $novaQuantida), 2, ",", ".");

      $update = $BD->query("UPDATE compras SET quantidade = '$novaQuantida', total = '$total'  WHERE id_cliente = '$idcliente' AND data_compra = '" . date('y-m-d') . "' AND id_produto = '" . $this->getNome() . "'");

      if ($update) {
        print 200;
      }
      // }
    } catch (PDOException $th) {
      print $th->getMessage();
    }
  }

  public function remover($BD)
  {
    try {
      $query = $BD->query("DELETE FROM {$this->tabela} WHERE idproduto = '" . $this->getNome() . "'");
      if ($query) {
       // unlink('../../img//produtos/' . $this->getFoto());
        print 200;
      }
    } catch (\Throwable $th) {
      print $th->getMessage();
    }
  }
}

$produtos = new Produtos;


if (isset($_POST['acao'])) {

  session_start();

  $acao = filter_input(INPUT_POST, 'acao');

  require '../env.php';

  switch ($acao) {
    case 'save':
      $produtos->setNome(filter_input(INPUT_POST, 'nome'));
      $produtos->setPreco(filter_input(INPUT_POST, 'preco'));
      $produtos->setDescricao(filter_input(INPUT_POST, 'descricao'));
      $produtos->setFoto($_FILES['foto']);
      $produtos->uploadFoto();
      $produtos->save($BD);
      break;
    case 'plus':

      $produtos->setNome(filter_input(INPUT_POST, 'produto', FILTER_SANITIZE_NUMBER_INT));
      $idcliente = filter_input(INPUT_POST, 'cliente', FILTER_SANITIZE_NUMBER_INT);
      $quantidade = filter_input(INPUT_POST, 'quantidade', FILTER_SANITIZE_NUMBER_INT);
      $produtos->btnPlus($BD, $idcliente, $quantidade);

      break;
    case 'minus':

      $produtos->setNome(filter_input(INPUT_POST, 'produto', FILTER_SANITIZE_NUMBER_INT));
      $idcliente = filter_input(INPUT_POST, 'cliente', FILTER_SANITIZE_NUMBER_INT);
      $quantidade = filter_input(INPUT_POST, 'quantidade', FILTER_SANITIZE_NUMBER_INT);
      $produtos->btnMinus($BD, $idcliente, $quantidade);

      break;

    default:
      # code...
      break;
  }
} elseif (isset($_GET['acao'])) {
  session_start();

  $acao = filter_input(INPUT_GET, 'acao');

  require '../env.php';

  switch ($acao) {
    case 'remover':
      $produtos->setNome(filter_input(INPUT_GET, 'idproduto'));
      $produtos->setFoto(filter_input(INPUT_GET, 'foto'));
      $produtos->remover($BD);
      break;

    default:
      # code...
      break;
  }
}
