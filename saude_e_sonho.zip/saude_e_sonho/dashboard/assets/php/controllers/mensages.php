<?php

class mensages
{

    private $remetente, $email, $assunto, $mensagem;
    public $erros = null;



    /**
     * Get the value of remetente
     */
    public function getRemetente()
    {
        return $this->remetente;
    }

    /**
     * Set the value of remetente
     *
     * @return  self
     */
    public function setRemetente($remetente)
    {
        $this->remetente = $remetente;

        return $this;
    }

    /**
     * Get the value of email
     */
    public function getEmail()
    {
        return $this->email;
    }

    /**
     * Set the value of email
     *
     * @return  self
     */
    public function setEmail($email)
    {
        $this->email = $email;

        return $this;
    }

    /**
     * Get the value of assunto
     */
    public function getAssunto()
    {
        return $this->assunto;
    }

    /**
     * Set the value of assunto
     *
     * @return  self
     */
    public function setAssunto($assunto)
    {
        $this->assunto = $assunto;

        return $this;
    }

    /**
     * Get the value of mensagem
     */
    public function getMensagem()
    {
        return $this->mensagem;
    }

    /**
     * Set the value of mensagem
     *
     * @return  self
     */
    public function setMensagem($mensagem)
    {
        $this->mensagem = $mensagem;

        return $this;
    }

    public function emailValidate()
    {
        if (!filter_var($this->getEmail(), FILTER_VALIDATE_EMAIL)) {
            $this->erros = 'O E-mail inserido não é válido';
        }
    }

    # Valida nome
    public function nomeValidate()
    {
        if (!preg_match("/^[a-zA-ZáÁéÉíÍóÓúÚàÀèÈìÌòÒùÙãÃõÕâÂêÊîÎôÔûÛçÇ ]*$/", $this->getRemetente()) || ltrim(strlen($this->getRemetente()) < 8) || $this->getRemetente() ==  "" || $this->getRemetente() == null || empty($this->getRemetente())) {
            $this->erros = 'O nome inserido não é válido.';
        }
    }

    # show
    public function show($BD)
    {
        try {
            $ver = $BD->query("SELECT *FROM mensagens ORDER BY idmensagens DESC");
            while ($sms = $ver->fetch()) { ?>

                <li class="message-item">
                    <a href="#">
                        <img src="assets/img/logo.png">
                        <div>
                            <h4><?= $sms->nome_remetente ?></h4>
                            <p><?= substr($sms->mensagens, 0, 50) ?></p>
                            <p><?= $sms->data_envio ?></p>
                        </div>
                    </a>
                </li>
                <li>
                    <hr class="dropdown-divider">
                </li>



<?php
            }
        } catch (PDOException $th) {
           print $th->getMessage();
        }
    }

    public function save($BD)
    {
        try {
            $enviar = $BD->prepare("INSERT INTO mensagens 
            (nome_remetente, email_remetente, assunto, mensagens, data_envio)
            VALUES(?,?,?,?,?)
            ");

            $enviar->bindValue(1, $this->getRemetente());
            $enviar->bindValue(2, $this->getEmail());
            $enviar->bindValue(3, $this->getAssunto());
            $enviar->bindValue(4, $this->getMensagem());
            $enviar->bindValue(5, date('d/m/Y'));

            if ($this->erros == null) {

                $enviar->execute();
                print 200;
            } else {
                print $this->erros;
            }
        } catch (PDOException $e) {
            print $e->getMessage();
        }
    }

    # contar
    public function contarMensagem($BD)
    {
        $conta = $BD->query("SELECT idmensagens FROM mensagens WHERE estado = '0'");
        print $conta->rowCount();
    }
}


## INSTâNCIA

$sms = new mensages;

if (isset($_POST['acao'])) {

    $acao = $_POST['acao'];

    require '../env.php';

    switch ($acao) {

        case 'enviar':

            $sms->setRemetente(filter_input(INPUT_POST, 'remetente'));
            $sms->setEmail(filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL));
            $sms->setAssunto(filter_input(INPUT_POST, 'assunto'));
            $sms->setMensagem(nl2br(htmlspecialchars(filter_input(INPUT_POST, 'mensagem'))));

            $sms->emailValidate();
            $sms->nomeValidate();

            $sms->save($BD);

            break;

        case 'contar':

            $sms->contarMensagem($BD);

            break;
        case 'show':
            $sms->show($BD);

        default:
            # code...
            break;
    }
}
