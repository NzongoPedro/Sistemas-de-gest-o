<?php
class funcionarios
{

  private $nome, $senha, $email, $telefone, $id_conta, $foto, $categoria, $morada, $table = 'funcionarios';
  public $erros = null;

  public function setnome($n)
  {
    $this->nome = $n;
  }
  public function setemail($n)
  {
    $this->email = $n;
  }
  public function setcategoria($n)
  {
    $this->categoria = $n;
  }
  public function settelefone($n)
  {
    $this->telefone = $n;
  }
  public function settesenha($n)
  {
    $this->senha = $n;
  }
  public function setFoto($n)
  {
    $this->foto = $n;
  }


  public function getFoto()
  {
    return $this->foto;
  }

  public function gettelefone()
  {
    return $this->telefone;
  }
  public function getnome()
  {
    return $this->nome;
  }
  public function getemail()
  {
    return $this->email;
  }
  public function getId()
  {
    return $this->id_conta;
  }
  public function getcategoria()
  {
    return $this->categoria;
  }
  public function getsenha()
  {
    return $this->senha;
  }


  /**
   * Get the value of morada
   */
  public function getMorada()
  {
    return $this->morada;
  }

  /**
   * Set the value of morada
   *
   * @return  self
   */
  public function setMorada($morada)
  {
    $this->morada = $morada;

    return $this;
  }

  # Valida nome
  public function nomeValidate()
  {
    if (!preg_match("/^[a-zA-ZáÁéÉíÍóÓúÚàÀèÈìÌòÒùÙãÃõÕâÂêÊîÎôÔûÛçÇ ]*$/", $this->getnome()) || ltrim(strlen($this->getnome()) < 8) || $this->getnome() ==  "" || $this->getnome() == null || empty($this->getnome())) {
      $this->erros = 'O nome inserido não é válido.';
    }
  }

  # Validar Número de telefone
  public function telefoneValidate()
  {
    if (!is_numeric($this->gettelefone()) || !preg_match("/^[0-9]*$/", $this->gettelefone()) || 9 > strlen($this->gettelefone()) || 9 < strlen($this->gettelefone()) || $this->gettelefone()[0] != 9) {
      $this->erros = 'Número de  telefone inválido.';
    }
  }

  # Validdar E-mail
  public function emailValidate()
  {
    if (!filter_var($this->getemail(), FILTER_VALIDATE_EMAIL)) {
      $this->erros = 'O E-mail inserido não é válido';
    }
  }

  # valida categoria
  public function validaCategoria()
  {
    if ($this->getcategoria() == 'Categoria') {
      $this->erros = 'Selecione uma categoria válida.';
    }
  }

  # FOTO

  public function uploadFoto()
  {

    $arquivo = array(
      'arquivo'  => $this->getFoto()['name'],
      'temporal' => $this->getFoto()['tmp_name'],
      'tipo' => strtolower($this->getFoto()['type']),
      'formato'  => strtolower(pathinfo($this->getFoto()['name'], PATHINFO_EXTENSION)),
      'nome' => time() . '.' . strtolower(pathinfo($this->getFoto()['name'], PATHINFO_EXTENSION)),
      'diretorio' => '../../img/funcionarios/'
    );

    $formatos_permitidos = array('image/jpg', 'image/png', 'image/jpeg', 'image/gif');

    # =========================== VERIFICA OS FORMATOS PERMITIDOS =====================
    if (in_array($arquivo['tipo'], $formatos_permitidos)) {

      # ========================= VERIFICA O DIRECTORIO =====================
      if (is_dir($arquivo['diretorio'])) {

        # ===================================== TENTA O UPLOAD ==================
        if (move_uploaded_file($arquivo['temporal'], $arquivo['diretorio'] . $arquivo['nome'])) {
          $this->foto = $arquivo['nome'];
        } else {
          $this->erros = 'Falha no upload.';
        }
      } else {
        mkdir($arquivo['diretorio']);
        move_uploaded_file($arquivo['temporal'], $arquivo['diretorio'] . $arquivo['nome']);
        $this->foto = $arquivo['nome'];
      }
    } else {
      $this->foto = null;
      $this->erros = 'Formato .' . $arquivo['formato'] . ' não é válido';
    }
  }

  # save categoria
  public function saveCategoria($BD)
  {
    $save = $BD->prepare("INSERT INTO categoria_funcionarios (designacao_categoria)
    VALUES(?)");
    $save->bindValue(1, $this->getcategoria());

    if ($_SESSION['categoria_funcionario'] != 'Admnistrador') {
      $this->erros = "Apenas administradores podem realizar esta actividade.";
    }



    if ($this->erros == null) {
      $save->execute();
      print 'ok';
    } else {
      print $this->erros;
    }
  }


  ### VALIDATE DATA
  public function checkMail($BD)
  {
    $check = $BD->query("SELECT *FROM {$this->table} WHERE email_funcionario = '" . $this->getemail() . "'");
    if ($check->rowCount() > 0) {
      $this->erros = 'O email inserido já está cadastrado. ' . $this->getemail();
    }
  }
  public function checkPhone($BD)
  {
    $check = $BD->query("SELECT *FROM {$this->table} WHERE telefone_funcionario = '" . $this->gettelefone() . "'");
    if ($check->rowCount() > 0) {
      $this->erros = 'O telefone inserido já está cadastrado.';
    }
  }

  # ### SAVE FUNCIONARIOS TO DATA BASE 
  public function save($BD)
  {
    try {
      $query = "INSERT INTO {$this->table} (nome_funcionario, id_categoria_funcionario,	email_funcionario, telefone_funcionario, senha, morada)
      VALUES(?,?,?,?,?,?)";
      $inserir = $BD->prepare($query);
      $inserir->bindValue(1, $this->getnome());
      $inserir->bindValue(2, $this->getcategoria());
      $inserir->bindValue(3, $this->getemail());
      $inserir->bindValue(4, $this->gettelefone());
      $inserir->bindValue(5, $this->getsenha());
      $inserir->bindValue(6, $this->getMorada());

      if ($_SESSION['categoria_funcionario'] != 'Admnistrador') {
        $this->erros = "Apenas administradores podem realizar esta actividade.";
      }

      if ($this->erros == null) {

        $inserir->execute();
        print 'ok';
      } else {
        print $this->erros;
      }
    } catch (PDOException $e) {
      echo $e->getMessage();
    }
  }
  # ### UPDATE FUNCIONARIOS TO DATA BASE 
  public function editar($BD, $id)
  {
    try {
      $this->id_conta = $id;
      $query = "UPDATE {$this->table} 
      SET 
      nome_funcionario = '" . $this->getNome() . "', 
      email_funcionario = '" . $this->getemail() . "', 
      telefone_funcionario = '" . $this->gettelefone() . "', 
      foto = '" . $this->getFoto() . "'
      WHERE idfuncionarios = '" . $id . "'";
      $inserir = $BD->prepare($query);


      if ($this->erros == null) {

        $inserir->execute();
        print 200;
      } else {
        print $this->erros;
      }
    } catch (PDOException $e) {
      echo $e->getMessage();
    }
  }
  # ### UPDATE FUNCIONARIOS TO DATA BASE 
  public function update($BD, $id)
  {
    try {
      $this->id_conta = $id;
      $query = "UPDATE {$this->table} 
      SET 
      nome_funcionario = '" . $this->getNome() . "', 
      id_categoria_funcionario = '" . $this->getcategoria() . "', 
      email_funcionario = '" . $this->getemail() . "', 
      telefone_funcionario = '" . $this->gettelefone() . "', 
      senha = '" . $this->getsenha() . "'
      WHERE idfuncionarios = '" . $id . "'";
      $inserir = $BD->prepare($query);


      if ($_SESSION['categoria_funcionario'] != 'Admnistrador') {
        $this->erros = "Apenas administradores podem realizar esta actividade.";
      }

      if ($this->erros == null) {

        $inserir->execute();
        print 'ok';
      } else {
        print $this->erros;
      }
    } catch (PDOException $e) {
      echo $e->getMessage();
    }
  }

  // UPDATE CATEGORIA
  public function updateCategoria($BD, $id)
  {
    try {

      $query = "UPDATE categoria_funcionarios 
      SET 
      designacao_categoria = '" . $this->getNome() . "' 
      WHERE idcategoria_funcionarios = '$id' ";

      $inserir = $BD->prepare($query);


      if ($_SESSION['categoria_funcionario'] != 'Admnistrador') {
        $this->erros = "Apenas administradores podem realizar esta actividade.";
      }

      if ($this->erros == null) {

        $inserir->execute();
        print 200;
      } else {
        print $this->erros;
      }
    } catch (PDOException $e) {
      echo $e->getMessage();
    }
  }

  # lista funcionários form
  
  public function listaFuncionarios($BD)
  {
    $lista = $BD->query("SELECT *FROM {$this->table} 
      INNER JOIN categoria_funcionarios
      ON categoria_funcionarios.idcategoria_funcionarios = {$this->table}.id_categoria_funcionario
      ORDER BY {$this->table}.nome_funcionario");
    while ($categoria = $lista->fetch()) {
      echo '<option value="' . $categoria->idfuncionarios . '">
      ' . $categoria->nome_funcionario . '
      </option>';
    }
  }
  # lista categoria form
  public function listaCategorias($BD)
  {
    $lista = $BD->query("SELECT *FROM categoria_funcionarios ORDER BY designacao_categoria");
    while ($categoria = $lista->fetch()) {
      echo '<option value="' . $categoria->idcategoria_funcionarios . '">
      ' . $categoria->designacao_categoria . '
      </option>';
    }
  }

  public function viewCategoria($BD)
  {
    try {
      if ($_SESSION['categoria_funcionario'] == 'Admnistrador') {
        $busca = $BD->query("SELECT *FROM categoria_funcionarios ORDER BY designacao_categoria ASC");
        while ($categoria = $busca->fetch()) : ?>

          <tr class="linha-<?= $categoria->idcategoria_funcionarios ?>">
            <th scope="row"><?= $categoria->idcategoria_funcionarios ?></th>
            <td><?= $categoria->designacao_categoria ?></td>
            <td>
              <button class="rem-categoria btn btn-sm border-0 text-danger" id="<?= $categoria->idcategoria_funcionarios ?>">
                <i class="bi-trash"></i>
              </button>
              <a href="#" class="text-dark btn-edit-categoria" title="<?= $categoria->designacao_categoria ?>" id="<?= $categoria->idcategoria_funcionarios ?>">
                <i class="bi-pen"></i>
              </a>
            </td>
          </tr>
        <?php endwhile;
      }
    } catch (PDOException $erro) {
      print $erro->getMessage();
    }
  }

  public function deleteCategoria($BD, $id)
  {

    if ($_SESSION['categoria_funcionario'] == 'Admnistrador') {
      $BD->query("DELETE FROM categoria_funcionarios WHERE idcategoria_funcionarios = '$id'");
      print 200;
    }
  }

  public function viewFuncionario($BD)
  {
    try {

      if ($_SESSION['categoria_funcionario'] == 'Admnistrador') {

        $busca = $BD->query("SELECT *FROM {$this->table}
     
      INNER JOIN categoria_funcionarios
      ON categoria_funcionarios.idcategoria_funcionarios = {$this->table}.id_categoria_funcionario
      WHERE email_funcionario !=  '" . $_SESSION['email_funcionario'] . "'
      ORDER BY {$this->table}.nome_funcionario");
        while ($funcionario = $busca->fetch()) : ?>
          <tr class="linha_<?= $funcionario->idfuncionarios ?>">
            <td scope="row"><?= $funcionario->idfuncionarios ?></td>
            <td><?= $funcionario->nome_funcionario ?></td>
            <td><?= $funcionario->designacao_categoria ?></td>
            <td><?= $funcionario->email_funcionario ?></td>
            <td><?= $funcionario->telefone_funcionario ?></td>
            <td>
              <a href="#!" class="btn-sm border-0 text-danger" id="<?= $funcionario->idfuncionarios ?>" onclick="ove(<?= $funcionario->idfuncionarios ?>)">
                <i class="bi-trash"></i>
              </a>
              <a href="./editarFuncionario.php?id=<?= $funcionario->idfuncionarios ?>&&acao=edit" class=btn-sm border-0 text-dark" id="<?= $funcionario->idfuncionarios ?>">
                <i class="bi-pen"></i>
              </a>
            </td>
          </tr>
<?php endwhile;
      }
    } catch (PDOException $erro) {
      print $erro->getMessage();
    }
  }


  public function viewFuncionarioEdit($BD, $id)
  {
    try {

      if ($_SESSION['categoria_funcionario'] == 'Admnistrador') {

        $busca = $BD->query("SELECT *FROM {$this->table}
     
        INNER JOIN categoria_funcionarios
        ON categoria_funcionarios.idcategoria_funcionarios = {$this->table}.id_categoria_funcionario
        WHERE idfuncionarios =  '$id'
        ");
        $resultaldo = $busca->fetch();
        return $resultaldo;
      }
    } catch (PDOException $erro) {
      print $erro->getMessage();
    }
  }



  # truncate funcionário
  public function truncatefuncionarios($BD)
  {
    if ($_SESSION['categoria_funcionario'] == 'Admnistrador') {
      $BD->query("SET FOREIGN_KEY_CHECKS=0");
      $BD->query("TRUNCATE TABLE {$this->table} ");
      $BD->query("SET FOREIGN_KEY_CHECKS=1");
    }
  }
  # drop funcionário
  public function dropfuncionarios($BD, $id)
  {
    if ($_SESSION['categoria_funcionario'] != 'Admnistrador') {
      $this->erros = "Não tem permissão para realizar esta actividade.";
    }

    if ($this->erros == null) {
      $BD->query("SET FOREIGN_KEY_CHECKS=0");
      $BD->query("DELETE FROM {$this->table} WHERE idfuncionarios = '$id'");
      $BD->query("SET FOREIGN_KEY_CHECKS=1");
      print 200;
    } else {
      print $this->erros;
    }
  }

  #login 
  public function login($BD)
  {
    try {
      ## verfica seo emailexiste 
      $checkEmail = $BD->query("SELECT email_funcionario FROM {$this->table} WHERE email_funcionario = '" . $this->getemail() . "'");
      if ($checkEmail->rowCount() > 0) {
        // Caso exista, verifica a senha
        $checkSenha = $BD->query("SELECT senha FROM {$this->table} WHERE senha = '" . $this->getsenha() . "'");
        if ($checkSenha->rowCount() > 0) {
        } else {
          $this->erros = 'A senha inserida está incorreta.';
        }
      } else {
        $this->erros = 'O e-mail inserido está incorreto.';
      }
    } catch (PDOException $err) {
      print $err->getMessage();
    }

    if ($this->erros == null) {
      $_SESSION['email_funcionario'] = $this->getemail();
      print 200;
    } else {
      print $this->erros;
    }
  }

  # alterar senha
  public function alterarSenha($BD, $senha_1, $senha_2)
  {
    try {
      if ($senha_1 == $senha_2) {
        // seleciona a senha na BD e verifica com a senha digitada
        $senha = $BD->query("SELECT *FROM {$this->table} WHERE email_funcionario = '" . $this->getemail() . "'");
        $s = $senha->fetch()->senha;
        if ($s != $this->getsenha()) {
          $this->erros = 'A senha atual está incorreta';
        }
      } else {
        $this->erros = 'As senhas não correspodem uma da outra';
      }

      $senha_1 = md5($senha_2);

      // Altera a senha caso tudo esteje ok
      if ($this->erros == null) {
        $BD->query("UPDATE {$this->table} SET senha = '$senha_1' WHERE email_funcionario = '" . $this->getemail() . "'");
        print 200;
      } else {
        echo $this->erros;
      }
    } catch (PDOException $e) {
      print $e->getMessage();
    }
  }

  #dados
  public function dadosConta($BD)
  {

    $select = $BD->query("SELECT *FROM {$this->table} 
    INNER JOIN categoria_funcionarios ON categoria_funcionarios.idcategoria_funcionarios = {$this->table}.id_categoria_funcionario
    WHERE email_funcionario = '" . $_SESSION['email_funcionario'] . "'");
    while ($d = $select->fetch()) {
      $this->nome = $d->nome_funcionario;
      $this->email = $d->email_funcionario;
      $this->telefone = $d->telefone_funcionario;
      $this->categoria = $d->designacao_categoria;
      $this->id_conta = $d->idfuncionarios;
      $this->foto = $d->foto;
      if ($this->foto == "") {
        $this->foto =  'profile-img.jpg';
      } else {
        $this->foto = $d->foto;
      }

      $_SESSION['categoria_funcionario'] = $this->categoria;
    }
  }

  // contar usuarios
  public function contarfuncionarios($BD)
  {
    $conta = $BD->query("SELECT *FROM {$this->table}");
    return $conta->rowCount();
  }
}


### instância

$funcionario = new funcionarios;

if (isset($_POST['acao'])) {

  require '../env.php';
  $acao = $_POST['acao'];

  switch ($acao) {
    case 'save':

      session_start();
      $funcionario->setnome(htmlspecialchars(filter_input(INPUT_POST, 'nome')));
      $funcionario->setcategoria(htmlspecialchars(filter_input(INPUT_POST, 'id-categoria')));
      $funcionario->setemail(htmlspecialchars(filter_input(INPUT_POST, 'email')));
      $funcionario->settelefone(htmlspecialchars(filter_input(INPUT_POST, 'telefone')));
      $funcionario->setMorada(htmlspecialchars(filter_input(INPUT_POST, 'morada')));
      $funcionario->settesenha(md5(htmlspecialchars(filter_input(INPUT_POST, 'senha'))));

      $funcionario->telefoneValidate();
      $funcionario->nomeValidate();
      $funcionario->emailValidate();
      $funcionario->emailValidate();
      $funcionario->validaCategoria();

      $funcionario->checkMail($BD);
      $funcionario->checkPhone($BD);

      $funcionario->save($BD);
      break;

    case 'update-categoria':

      session_start();
      $funcionario->setnome(htmlspecialchars(filter_input(INPUT_POST, 'designacao')));
      $id = filter_input(INPUT_POST, 'id', FILTER_VALIDATE_INT);
      $funcionario->updateCategoria($BD, $id);
      break;

    case 'update':

      session_start();
      $funcionario->setnome(htmlspecialchars(filter_input(INPUT_POST, 'nome')));
      $funcionario->setcategoria(htmlspecialchars(filter_input(INPUT_POST, 'id-categoria')));
      $funcionario->setemail(htmlspecialchars(filter_input(INPUT_POST, 'email')));
      $funcionario->settelefone(htmlspecialchars(filter_input(INPUT_POST, 'telefone')));
      $funcionario->settesenha(md5(htmlspecialchars(filter_input(INPUT_POST, 'senha'))));
      $id = filter_input(INPUT_POST, 'id', FILTER_VALIDATE_INT);

      $funcionario->telefoneValidate();
      $funcionario->nomeValidate();
      $funcionario->emailValidate();
      $funcionario->validaCategoria();

      $funcionario->update($BD, $id);
      break;

    case 'editar':

      session_start();
      $funcionario->setnome(htmlspecialchars(filter_input(INPUT_POST, 'nome')));
      $funcionario->setemail(htmlspecialchars(filter_input(INPUT_POST, 'email')));
      $funcionario->settelefone(htmlspecialchars(filter_input(INPUT_POST, 'telefone')));
      $funcionario->setFoto($_FILES['foto']);

      $id = filter_input(INPUT_POST, 'id', FILTER_VALIDATE_INT);

      $funcionario->telefoneValidate();
      $funcionario->nomeValidate();
      $funcionario->emailValidate();

      $funcionario->uploadFoto();

      $funcionario->editar($BD, $id);
      break;

    case 'view-categoria':
      $funcionario->viewcategoria($BD);
      break;
    case 'save-categoria':
      session_start();
      $funcionario->setcategoria(htmlspecialchars(filter_input(INPUT_POST, 'categoria')));
      $funcionario->validaCategoria();
      $funcionario->saveCategoria($BD);
      break;

    case 'remover-categoria':
      session_start();
      $id = filter_input(INPUT_POST, 'id', FILTER_VALIDATE_INT);
      $funcionario->deleteCategoria($BD, $id);
      break;

    case 'truncate':
      $funcionario->truncateFuncionarios($BD);
      break;

    case 'login':

      session_start();
      $funcionario->setemail(htmlspecialchars(filter_input(INPUT_POST, 'email')));
      $funcionario->settesenha(md5(filter_input(INPUT_POST, 'senha')));

      $funcionario->login($BD);

      break;

    case 'nova-senha':

      session_start();
      $funcionario->setemail(htmlspecialchars(filter_input(INPUT_POST, 'email')));
      $funcionario->settesenha(md5(filter_input(INPUT_POST, 'password')));

      $senha_1 = filter_input(INPUT_POST, 'newpassword');
      $senha_2 = filter_input(INPUT_POST, 'renewpassword');

      $funcionario->alterarSenha($BD, $senha_1, $senha_2);

      break;
  }
} elseif (isset($_GET['acao']) && $_GET['acao'] == 'drop') {
  require '../env.php';
  session_start();
  $id = filter_input(INPUT_GET, 'id', FILTER_SANITIZE_NUMBER_INT);
  $funcionario->dropFuncionarios($BD, $id);
}
