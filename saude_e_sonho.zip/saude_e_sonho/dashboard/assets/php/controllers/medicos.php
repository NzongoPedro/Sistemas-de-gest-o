<?php

class medicos
{

  private $nome, $telefone, $email, $bi, $especialidade, $localidade, $certificacoes, $clinica, $descricao, $data, $foto;
  public $erros = null;
  private $table = 'medicos';
  private $numeroOrdem;


  /**
   * Get the value of nome
   */
  public function getNome()
  {
    return $this->nome;
  }

  /**
   * Set the value of nome
   *
   * @return  self
   */
  public function setNome($nome)
  {
    $this->nome = $nome;

    return $this;
  }

  /**
   * Get the value of telefone
   */
  public function getTelefone()
  {
    return $this->telefone;
  }

  /**
   * Set the value of telefone
   *
   * @return  self
   */
  public function setTelefone($telefone)
  {
    $this->telefone = $telefone;

    return $this;
  }

  /**
   * Get the value of email
   */
  public function getEmail()
  {
    return $this->email;
  }

  /**
   * Set the value of email
   *
   * @return  self
   */
  public function setEmail($email)
  {
    $this->email = $email;

    return $this;
  }

  /**
   * Get the value of bi
   */
  public function getBi()
  {
    return $this->bi;
  }

  /**
   * Set the value of bi
   *
   * @return  self
   */
  public function setBi($bi)
  {
    $this->bi = $bi;

    return $this;
  }

  /**
   * Get the value of especialidade
   */
  public function getEspecialidade()
  {
    return $this->especialidade;
  }

  /**
   * Set the value of especialidade
   *
   * @return  self
   */
  public function setEspecialidade($especialidade)
  {
    $this->especialidade = $especialidade;

    return $this;
  }

  /**
   * Get the value of localidade
   */
  public function getLocalidade()
  {
    return $this->localidade;
  }

  /**
   * Set the value of localidade
   *
   * @return  self
   */
  public function setLocalidade($localidade)
  {
    $this->localidade = $localidade;

    return $this;
  }

  /**
   * Get the value of certificacoes
   */
  public function getCertificacoes()
  {
    return $this->certificacoes;
  }

  /**
   * Set the value of certificacoes
   *
   * @return  self
   */
  public function setCertificacoes($certificacoes)
  {
    $this->certificacoes = $certificacoes;

    return $this;
  }

  /**
   * Get the value of clinica
   */
  public function getClinica()
  {
    return $this->clinica;
  }

  /**
   * Set the value of clinica
   *
   * @return  self
   */
  public function setClinica($clinica)
  {
    $this->clinica = $clinica;

    return $this;
  }

  /**
   * Get the value of descricao
   */
  public function getDescricao()
  {
    return $this->descricao;
  }

  /**
   * Set the value of descricao
   *
   * @return  self
   */
  public function setDescricao($descricao)
  {
    $this->descricao = $descricao;

    return $this;
  }

  /**
   * Get the value of data
   */
  public function getData()
  {
    return $this->data;
  }

  /**
   * Set the value of data
   *
   * @return  self
   */
  public function setData($data)
  {
    $this->data = $data;

    return $this;
  }

  /**
   * Get the value of foto
   */
  public function getFoto()
  {
    return $this->foto;
  }

  /**
   * Set the value of foto
   *
   * @return  self
   */
  public function setFoto($foto)
  {
    $this->foto = $foto;

    return $this;
  }

  /**
   * Get the value of numeroOrdem
   */
  public function getNumeroOrdem()
  {
    return $this->numeroOrdem;
  }

  /**
   * Set the value of numeroOrdem
   *
   * @return  self
   */
  public function setNumeroOrdem($numeroOrdem)
  {
    $this->numeroOrdem = $numeroOrdem;

    return $this;
  }

  # Valida nome
  public function nomeValidate()
  {
    if (!preg_match("/^[a-zA-ZáÁéÉíÍóÓúÚàÀèÈìÌòÒùÙãÃõÕâÂêÊîÎôÔûÛçÇ. ]*$/", $this->getNome()) || ltrim(strlen($this->getnome()) < 8) || $this->getnome() ==  "" || $this->getnome() == null || empty($this->getnome())) {
      $this->erros = 'O nome inserido não é válido.';
    }
  }

  # Validar Número de telefone
  public function telefoneValidate()
  {
    if (!is_numeric($this->getTelefone()) || !preg_match("/^[0-9]*$/", $this->getTelefone()) || 9 > strlen($this->getTelefone()) || 9 < strlen($this->getTelefone()) || $this->getTelefone()[0] != 9) {
      $this->erros = 'Número de  telefone inválido.';
    }
  }

  # Validdar E-mail
  public function emailValidate()
  {
    if (!filter_var($this->getEmail(), FILTER_VALIDATE_EMAIL)) {
      $this->erros = 'O E-mail inserido não é válido';
    }
  }

  // VERIFICA SE O USUARIO OU EMAIL JA EXISTE

  public function checkLogin($BD)
  {
    $check = $BD->query("SELECT *FROM {$this->table} WHERE email_medico = '" . $this->getEmail() . "'");
    if ($check->rowCount() > 0) {
      $this->erros = 'O email inserido já está cadastrado.';
    }
  }

  public function checkFone($BD)
  {
    $check = $BD->query("SELECT *FROM {$this->table} WHERE telefone_medico = '" . $this->getTelefone() . "'");
    if ($check->rowCount() > 0) {
      $this->erros = 'O Telefone inserido já está cadastrado.';
    }
  }

  public function checkBi($BD)
  {
    $check = $BD->query("SELECT *FROM {$this->table} WHERE BI_medico = '" . $this->getBi() . "'");
    if ($check->rowCount() > 0) {
      $this->erros = 'O BI inserido já está cadastrado.';
    }
  }


  # FOTO

  public function uploadFoto()
  {

    $arquivo = array(
      'arquivo'  => $this->getFoto()['name'],
      'temporal' => $this->getFoto()['tmp_name'],
      'tipo' => strtolower($this->getFoto()['type']),
      'formato'  => strtolower(pathinfo($this->getFoto()['name'], PATHINFO_EXTENSION)),
      'nome' => time() . '.' . strtolower(pathinfo($this->getFoto()['name'], PATHINFO_EXTENSION)),
      'diretorio' => '../../img/medicos/'
    );

    $formatos_permitidos = array('image/jpg', 'image/png', 'image/jpeg', 'image/gif');

    # =========================== VERIFICA OS FORMATOS PERMITIDOS =====================
    if (in_array($arquivo['tipo'], $formatos_permitidos)) {

      # ========================= VERIFICA O DIRECTORIO =====================
      if (is_dir($arquivo['diretorio'])) {

        # ===================================== TENTA O UPLOAD ==================
        if (move_uploaded_file($arquivo['temporal'], $arquivo['diretorio'] . $arquivo['nome'])) {
          $this->foto = $arquivo['nome'];
        } else {
          $this->erros = 'Falha no upload.';
        }
      } else {
        mkdir($arquivo['diretorio']);
        move_uploaded_file($arquivo['temporal'], $arquivo['diretorio'] . $arquivo['nome']);
        $this->foto = $arquivo['nome'];
      }
    } else {
      $this->foto = null;
      $this->erros = 'Formato .' . $arquivo['formato'] . ' não é válido';
    }
  }

  # save Medicos
  public function save($BD)
  {

    if ($_SESSION['categoria_funcionario'] != 'Admnistrador') {
      $this->erros = "Apenas administradores podem realizar esta actividade.";
    }

    if ($this->erros == null) {
      try {
        $query = "INSERT INTO {$this->table}  
        (nome_medico, email_medico, BI_medico, telefone_medico, id_especialidade, localidade, id_certificacoes, id_clinica, descricao, foto, data_nascimento, numero_ordem)
				VALUES(?,?,?,?,?,?,?,?,?,?,?,?)";

        $save = $BD->prepare($query);

        $save->bindValue(1, $this->getNome());
        $save->bindValue(2, $this->getEmail());
        $save->bindValue(3, $this->getBi());
        $save->bindValue(4, $this->getTelefone());
        $save->bindValue(5, $this->getEspecialidade());
        $save->bindValue(6, $this->getLocalidade());
        $save->bindValue(7, $this->getCertificacoes());
        $save->bindValue(8, $this->getClinica());
        $save->bindValue(9, $this->getDescricao());
        $save->bindValue(10, $this->getFoto());
        $save->bindValue(11, $this->getData());
        $save->bindValue(12, $this->getNumeroOrdem());

        if ($save->execute()) {
          print 200;
        }
      } catch (PDOException $th) {
        print
          $th->getMessage();
      }
    } else {
      print $this->erros;
    }
  }

  # save Especialidades
  public function saveCertificacoes($BD)
  {
    $save = $BD->prepare("INSERT INTO certificacoes (designacao_certificacao)
    VALUES(?)");
    $save->bindValue(1, $this->getCertificacoes());

    if ($_SESSION['categoria_funcionario'] != 'Admnistrador') {
      $this->erros = "Apenas administradores podem realizar esta actividade.";
    }


    if ($this->erros == null) {
      $save->execute();
      print 'ok';
    } else {
      print $this->erros;
    }
  }

  ## ver medicos 
  public function viewMedicos($BD)
  {
    $medicos = $BD->query("SELECT *FROM {$this->table} 
    INNER JOIN especialidades ON especialidades.idespecialidades = {$this->table}.id_especialidade
    INNER JOIN certificacoes ON certificacoes.idcertificacoes = {$this->table}.id_certificacoes
    INNER JOIN clinicas ON clinicas.idclinicas = {$this->table}.id_clinica
    ORDER BY {$this->table}.nome_medico
    ");
    if ($_SESSION['categoria_funcionario'] == 'Admnistrador') {


      while ($medico = $medicos->fetch()) { ?>

        <div class="col-3" id="m<?= $medico->idmedicos ?>">
          <div class="card shadow border">
            <div class="card-image">
              <img src="./assets/./img/./medicos/<?= $medico->foto ?>" alt="" class="img-fluid" style="max-width: 100%; width:400px;height:200px;object-fit:cover ">
              <div class="card-title">
                <h5 class="text-center"> <?= $medico->nome_medico ?></h5>
                <!--  <div class="text-center">
                <span class="card-subtitle text-center"> <?= $medico->designacao_especialidade ?> <br> <?= $medico->designacao_clinica ?></span>
              </div> -->
              </div>
            </div>
            <div class="card-text mb-3">
              <div class="text-center">
                <a href="tel:<?= $medico->telefone_medico ?>" class="btn btn-ms">
                  <i class="bi-telephone"></i>
                </a>
                <a href="mailto:<?= $medico->email_medico ?>" class="btn btn-ms">
                  <i class="bi-envelope"></i>
                </a>
                <!-- <a href="./editarMedico.php" class="btn btn-ms editar-medico" title="<?= $medico->foto ?>" id="<?= $medico->idmedicos ?>">
                  <i class="bi-pencil"></i>
                </a> -->
                <a href="#" class="btn btn-ms apagar-medico" title="<?= $medico->foto ?>" id="<?= $medico->idmedicos ?>">
                  <i class="bi-trash"></i>
                </a>
              </div>
            </div>
          </div>
        </div>

        <?php

      }
    }
  }

  # apagar médico
  public function apagarMedico($BD, $idMedico, $foto)
  {
    $apaga = $BD->prepare("DELETE FROM {$this->table} WHERE idmedicos = '$idMedico'");
    if ($_SESSION['categoria_funcionario'] == 'Admnistrador') {
      if ($apaga->execute()) {
        unlink('../../img/medicos/' . $foto);
        print 200;
      }
    }
  }

  # view especialidades
  public function viewCertificacoes($BD)
  {
    try {
      $busca = $BD->query("SELECT *FROM certificacoes ORDER BY designacao_certificacao ASC");
      if ($_SESSION['categoria_funcionario'] == 'Admnistrador') {
        while ($clinica = $busca->fetch()) : ?>
          <tr class="rem-linha-<?= $clinica->idcertificacoes ?>">
            <td><?= $clinica->idcertificacoes ?></td>
            <td><?= $clinica->designacao_certificacao ?></td>
            <td>
              <a href="#" class="text-dark editarCer btn-edit-certificacoes" title="<?= $clinica->designacao_certificacao ?>" id="<?= $clinica->idcertificacoes ?>">
                <i class=" bi-pencil"></i>
              </a>
              <a href="#" class="text-danger apagarCer" id="<?= $clinica->idcertificacoes ?>">
                <i class=" bi-trash"></i>
              </a>
            </td>
          </tr>
<?php endwhile;
      }
    } catch (PDOException $erro) {
      print $erro->getMessage();
    }
  }

  # Remover especialidades
  public function removerCertificacao($BD, $id)
  {
    if ($_SESSION['categoria_funcionario'] != 'Admnistrador') {
      $this->erros = "Apenas administradores podem realizar esta actividade.";
    } else {
      $BD->query("DELETE FROM certificacoes WHERE idcertificacoes ='$id'");
      print 200;
    }
  }

  // UPDATE CATEGORIA
  public function updateCategoria($BD, $id)
  {
    try {

      $query = "UPDATE certificacoes 
      SET 
      designacao_certificacao = '" . $this->getNome() . "' 
      WHERE idcertificacoes = '$id' ";

      $inserir = $BD->prepare($query);


      if ($_SESSION['categoria_funcionario'] != 'Admnistrador') {
        $this->erros = "Apenas administradores podem realizar esta actividade.";
      }

      if ($this->erros == null) {

        $inserir->execute();
        print 200;
      } else {
        print $this->erros;
      }
    } catch (PDOException $e) {
      echo $e->getMessage();
    }
  }
}

$medico = new medicos;

if (isset($_POST['acao'])) {

  require '../env.php';

  $acao = $_POST['acao'];

  switch ($acao) {

    case 'save':

      session_start();
      $medico->setNome(filter_input(INPUT_POST, 'nome'));
      $medico->setEmail(filter_input(INPUT_POST, 'email'));
      $medico->setTelefone(filter_input(INPUT_POST, 'telefone'));
      $medico->setBi(filter_input(INPUT_POST, 'bi'));
      $medico->setEspecialidade(filter_input(INPUT_POST, 'especialidade'));
      $medico->setDescricao(filter_input(INPUT_POST, 'descricao'));
      $medico->setCertificacoes(filter_input(INPUT_POST, 'certificacoes'));
      $medico->setClinica(filter_input(INPUT_POST, 'clinica'));
      $medico->setData(filter_input(INPUT_POST, 'data'));
      $medico->setLocalidade(filter_input(INPUT_POST, 'localizacao'));
      $medico->setNumeroOrdem(filter_input(INPUT_POST, 'numero'));
      $medico->setFoto($_FILES['foto']);

      # invocando Validações

      $medico->nomeValidate($medico->getNome());
      $medico->telefoneValidate($medico->getTelefone());
      $medico->emailValidate($medico->getEmail());

      $medico->checkBi($BD);
      $medico->checkFone($BD);
      $medico->checkLogin($BD);
      $medico->uploadFoto();
      $medico->save($BD);

      break;

    case 'save-certificacoes':
      session_start();
      $medico->setCertificacoes(filter_input(INPUT_POST, 'certificacoes'));
      $medico->saveCertificacoes($BD);

      break;
    case 'apagar':
      session_start();
      $idMedico = $_POST['idMedico'];
      $fotoMedico = $_POST['fotoMedico'];
      $medico->apagarMedico($BD, $idMedico, $fotoMedico);

      break;

    case 'rem-certificacao':
      session_start();
      $id = $_POST['idCertificacao'];
      $medico->removerCertificacao($BD, $id);
      break;

    case 'update-certificacoes':

      session_start();
      $medico->setnome(htmlspecialchars(filter_input(INPUT_POST, 'designacao')));
      $id = filter_input(INPUT_POST, 'id', FILTER_VALIDATE_INT);
      $medico->updateCategoria($BD, $id);
      break;
  }
}
