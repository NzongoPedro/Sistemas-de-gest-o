<?php
session_start();

if (!isset($_SESSION['email_funcionario'])) {
  header("location: ./sair.php");
}
require './assets/php/env.php';
require './assets/php/controllers/clinicas.php';
require './assets/php/controllers/produtos.php';
$produto = $produtos->show($BD);
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Médicos | Saúde e sonho</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.gstatic.com" rel="preconnect">
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/quill/quill.snow.css" rel="stylesheet">
  <link href="assets/vendor/quill/quill.bubble.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/simple-datatables/style.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: NiceAdmin - v2.2.2
  * Template URL: https://bootstrapmade.com/nice-admin-bootstrap-admin-html-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>

  <!-- ======= Header ======= -->
  <!-- End Header -->
  <?php require './assets/./php/./adm-includes/./important/./header.php'; ?>
  <!-- End Header -->

  <!-- ======= Sidebar ======= -->
  <?php require './assets/./php/./adm-includes/./important/./lesft-menu.php'; ?>
  <!-- ======= Sidebar ======= -->

  <!-- End Sidebar-->

  <main id="main" class="main">

    <div class="pagetitle">
      <h1>Produtos </h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="index.php">Home</a></li>
          <li class="breadcrumb-item">Produtos</li>

        </ol>
      </nav>
    </div><!-- End Page Title -->

    <!-- Form produtos -->
    <div class="pagetitle mt-2 mb-2 produtos" style="display:none;">
      <section class="section">
        <div class="row">
          <div class="collg-12">
            <div class="card">
              <div class="card-body">
                <div class="card-title">
                  <h5>Cadastrar produtos</h5>
                </div>

                <div class="response-produtos text-center mb-2 mt-2"></div>

                <form class="form-novo-produto">
                  <div class="row mb-3">
                    <label for="inputEmail3" class="col-sm-2 col-form-label">Nome do produto</label>
                    <div class="col-sm-10">
                      <input type="text" class="form-control" id="inputEmail3" name="nome" required>
                    </div>
                  </div>

                  <div class="row mb-3">
                    <label for="inputPassword3" class="col-sm-2 col-form-label">Preço do produto</label>
                    <div class="col-sm-10">
                      <input type="text" class="form-control" id="inputPassword3" name="preco" required>
                    </div>
                  </div>

                  <fieldset class="row mb-3">
                    <legend class="col-form-label col-sm-2 pt-0"> Imagem do produto</legend>
                    <div class="col-sm-10">
                      <div class="form-group">
                        <label for="foto" class="bg-btn">
                          <i class="bi-camera-fill"></i>
                          <span class="ms-2"></span>FOTO</span>
                        </label>
                        <input type="file" class="up-foto" name="foto" id="foto" required>
                      </div>
                    </div>
                  </fieldset>

                  <div class="row mb-3">
                    <label for="inputPassword" class="col-sm-2 col-form-label">Descrição do produto</label>
                    <div class="col-sm-10">
                      <input type="text" class="form-control" id="inputPassword" name="descricao" required>
                    </div>
                  </div>
                  <div class="text-end">

                    <input type="hidden" name="acao" value="save">
                    <button type="submit" class="btn bg-btn">Adicionar</button>
                  </div>

                </form>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>

    <div class="pagetitle">
      <section class="section">
        <div class="row">
          <div class="col-lg-12">

            <div class="card">
              <div class="card-body">
                <div class="card-title">
                  <div class="float-end">
                    <button type="button" class="btn bg-btn btn-produto"><i class="bi bi-plus mt-1"></i> Novo</button>
                  </div>
                </div>
              </div>
            </div>

          </div>
        </div>

        <div class="row  row-cols-1 row-cols-md-4 g-4">
          <?php
          foreach ($produto as $valor) { ?>
            <div class="col">
              <div class="card h-100">
                <img src="./assets/img/produtos/<?= $valor->foto_produto ?>" class="card-img-top" alt="...">
                <div class="card-body">
                  <h5 class="card-title text-center"><?= $valor->nome_produto ?></h5>
                  <div class="text-center">
                    <span class="badge rounded-pill bg-dark"><?= number_format($valor->preco_produto, 2, ',', '.') ?> kzs</span>
                  </div>
                  <p class="card-text text-center mt-4"><?= $valor->descricao ?></p>
                  <div class="text-center mt-2 mb-2">
                    <a href="#!" class="btn btn-sm bi-trash btn-danger rounded rounded-3 remover-produto" id="<?= $valor->idproduto ?>" title="<?= $valor->foto_produto ?>" onclick="removerProduto('<?= $valor->idproduto ?>','<?= $valor->foto_produto ?>')">
                      <span class="ms-2">eliminar</span>
                    </a>
                  </div>
                </div>
              </div>
            </div>
          <?php }
          ?>
        </div>
      </section>



  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer id="footer" class="footer">
    <div class="copyright">
      &copy; Copyright <strong><span>Saúde e sonho</span></strong>. Todos os direitos reservados
    </div>
    <div class="credits">
      <!-- All the links in the footer should remain intact. -->
      <!-- You can delete the links only if you purchased the pro version. -->
      <!-- Licensing information: https://bootstrapmade.com/license/ -->
      <!-- Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/nice-admin-bootstrap-admin-html-template/ -->
      Feito por <a href="#">IOS</a>
    </div>
  </footer><!-- End Footer -->

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>


  <script>
    // cadastar médicos
    var form_produto = document.querySelector('.form-novo-produto')
    form_produto.addEventListener('submit', (e) => {
      e.preventDefault()
      var dados = new FormData(form_produto)
      fetch('./assets/php/controllers/produtos.php', {

          method: 'POST',
          body: dados
        })
        .then(res => res.text())
        .then(data => {
          if (data == 200) {

            document.querySelector('.response-produtos').innerHTML = "<div class='alert alert-success'>Dados salvos.</div>"
            form_produto.reset()
            setTimeout(() => {
              window.location.reload()
            }, 1500);
          } else {

            document.querySelector('.response-produtos').innerHTML = "<div class='alert alert-danger'>" + data + "</div>"
          }
        })
        .catch((e) => {
          console.log(e)
        })
    })

    // remover produtos
    function removerProduto(id, foto) {
      fetch(`./assets/php/controllers/produtos.php?idproduto=${id}&foto=${foto}&acao=remover`)
        .then(res => res.text())
        .then((data) => {
          if (data == 200) {
            setTimeout(() => {
              window.location.reload()
            }, 1500);
          } else {
            alert(data)
          }
        })
    }
  </script>
  <!-- Vendor JS Files -->
  <script src="assets/vendor/apexcharts/apexcharts.min.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/chart.js/chart.min.js"></script>
  <script src="assets/vendor/echarts/echarts.min.js"></script>
  <script src="assets/vendor/quill/quill.min.js"></script>
  <script src="assets/vendor/simple-datatables/simple-datatables.js"></script>
  <script src="assets/vendor/tinymce/tinymce.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
  <script src="assets/vendor/jquery/jquery.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

  <!-- REQUESTS JS FILE -->
  <script src="assets/js/requests.js"></script>




</body>

</html>