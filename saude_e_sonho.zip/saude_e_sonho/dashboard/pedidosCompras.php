<?php
session_start();

if (!isset($_SESSION['email_funcionario'])) {
  header("location: ./sair.php");
}
require './assets/php/env.php';
require './assets/php/controllers/compras.php';

$compras = listaCompras($BD);

?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Pedidos de compras | Saúde e sonho</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.gstatic.com" rel="preconnect">
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/quill/quill.snow.css" rel="stylesheet">
  <link href="assets/vendor/quill/quill.bubble.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/simple-datatables/style.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: NiceAdmin - v2.2.2
  * Template URL: https://bootstrapmade.com/nice-admin-bootstrap-admin-html-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>

  <!-- ======= Header ======= -->
  <!-- End Header -->
  <?php require './assets/./php/./adm-includes/./important/./header.php'; ?>
  <!-- End Header -->

  <!-- ======= Sidebar ======= -->
  <?php require './assets/./php/./adm-includes/./important/./lesft-menu.php'; ?>
  <!-- ======= Sidebar ======= -->

  <!-- End Sidebar-->

  <main id="main" class="main">

    <div class="pagetitle">
      <h1>Pedidos de compras</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="./produtos.php">Produtos</a></li>
          <li class="breadcrumb-item"> compras</li>
        </ol>
      </nav>
    </div><!-- End Page Title -->

    <section class="section">
      <div class="container shadow-sm bg-white">
        <div class="row">
          <div class="card border-0"></div>
          <div class="card-header bg-white">
            <div class="card-title">
              <h5>Lista de pedidos</h5>
            </div>
          </div>
          <div class="card-body">
            <table class="table table-sm datatable table-borderless table-striped table-hover table-striped">
              <thead class="bg-btn">
                <tr>
                  <th>PRODUTO</th>
                  <th>PRECO</th>
                  <th>QTD</th>
                  <th>CLIENTE</th>
                  <th>ESTADO</th>
                  <th>TOTAL</th>
                  <th>AÇÃO</th>
                </tr>
              </thead>
              <tbody>
                <?php
                $estado = "";
                $fundo = "";
                $acao = "";
                $dados = json_decode($compras);
                foreach ($dados as $value) :
                  switch ($value->estado_compra) {
                    case '1':
                      $estado = '<span class="badge rounded-pill bg-warning text-dark bi-exclamation-triangle"> PEDENTE</span>';
                      $fundo = 'alert-warning';
                      $acao = '<a href="#!" class="bi-cart-check-fill text-success" onClick="estadoCompra(' . $value->idcompra . ', ' . $value->id_cliente . ', 2)"></a>
                               <a href="#!" class="bi-cart-x-fill text-danger remover-pedido" title="Remover pedido" onClick="removerPedido(' . $value->idcompra . ')"></a>';
                      break;
                    default:
                      $estado = '<span class="badge rounded-pill bg-success bi-check"> VENDIDO</span>';
                      $fundo = 'alert-success';
                      $acao = '<a href="#!" class="bi-cart-dash-fill text-dark"  onClick="estadoCompra(' . $value->idcompra . ', ' . $value->id_cliente . ', 1)"></a>
                      <a href="#!" class="bi-cart-x-fill text-danger remover-pedido" title="Remover pedido" onClick="removerPedido(' . $value->idcompra . ')"></a>';
                      break;
                  }
                ?>
                  <tr class="<?= $fundo ?> linha-<?= $value->idcompra ?>">
                    <td><?= $value->nome_produto ?></td>
                    <td><?= number_format($value->preco, 2, ',', '.') ?> kzs </td>
                    <td><?= $value->quantidade ?></td>
                    <td><?= $value->nome_paciente ?></td>
                    <td><?= $estado ?></td>
                    <td><?= $value->total ?> kzs</td>
                    <td><?= $acao ?></td>
                  </tr>
                <?php endforeach; ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
      </div>
    </section>



  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer id="footer" class="footer">
    <div class="copyright">
      &copy; Copyright <strong><span>Saúde e sonho</span></strong>. Todos os direitos reservados
    </div>
    <div class="credits">
      <!-- All the links in the footer should remain intact. -->
      <!-- You can delete the links only if you purchased the pro version. -->
      <!-- Licensing information: https://bootstrapmade.com/license/ -->
      <!-- Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/nice-admin-bootstrap-admin-html-template/ -->
      Feito por <a href="#">IOS</a>
    </div>
  </footer><!-- End Footer -->

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <script>
    async function estadoCompra(produto, cliente, estado, e) {
      await fetch(`./assets/php/controllers/compras.php?produto=${produto}&cliente=${cliente}&estado=${estado}&acao=estado`)
        .then(res => res.text())
        .then((value) => {
          if (value == 200) {
            setTimeout(() => {
              window.location.reload()
            }, 2500);
          } else {
            alert(value)
          }
        })
      return false
    }

    async function removerPedido(idCompra) {
      $(`.linha-${idCompra}`).addClass('alert-danger').fadeOut(1000)
      await fetch(`./assets/php/controllers/compras.php?idcompra=${idCompra}&acao=remover-pedido`)
        .then(res => res.text())
        .then((value) => {
          if (value == 200) {
            $(`.linha${idCompra}`).addClass('alert-danger').fadeOut(1000)
          } else {
            //alert(value)
          }
        })
      return false
    }
  </script>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/apexcharts/apexcharts.min.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/chart.js/chart.min.js"></script>
  <script src="assets/vendor/echarts/echarts.min.js"></script>
  <script src="assets/vendor/quill/quill.min.js"></script>
  <script src="assets/vendor/simple-datatables/simple-datatables.js"></script>
  <script src="assets/vendor/tinymce/tinymce.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
  <script src="assets/vendor/jquery/jquery.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

  <!-- REQUESTS JS FILE -->
  <script src="assets/js/requests.js"></script>




</body>

</html>